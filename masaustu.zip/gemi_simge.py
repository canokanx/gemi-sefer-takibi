# -*- coding: utf-8 -*-
"""Haritadaki 3 boyutlu gemi imlecleri (pruvasi gidis yonune donuk).

Surum 3:
  * Pruva belirgin sivri (ok gibi) — geminin hangi yone gittigi ilk bakista anlasilir.
  * Govdenin yan yuzu (borda) koyu renkte kalinlik olarak gorunur, ustte parlak guverte.
  * Suya dusen belirgin golge.
  * Seyirdeki gemilerin arkasinda beyaz dumen suyu (iz) — hareket yonunu netlestirir.
  * Kaptan kosku kicta, koyu camli; kucuk simgelerde beyaz blok yok (ters gorunmesin diye).
"""
import threading

from PIL import Image, ImageDraw, ImageFilter, ImageTk

ACI_ADIMI = 10      # simgeler 10 derecelik adimlarla hazirlanir (36 yon)

# tur: (renk, boy_px)
TURLER = {
    "biz":     ("#F2704F", 42),
    "hedef":   ("#E91E63", 48),
    "Kargo":   ("#3BA55C", 24),
    "Tanker":  ("#D0433A", 24),
    "Yolcu":   ("#2F78E0", 24),
    "Römorkör": ("#14A5B3", 19),
    "Pilot":   ("#14A5B3", 19),
    "Balıkçı": ("#9A7A5C", 18),
    "Hızlı tekne": ("#8A63D2", 18),
    "Gezi teknesi": ("#8A63D2", 18),
    "Diğer":   ("#8593A3", 21),
    "":        ("#8593A3", 21),
}

LEJANT = [("Gemilerim", "biz"), ("Aranan", "hedef"), ("Kargo", "Kargo"), ("Tanker", "Tanker"),
          ("Yolcu", "Yolcu"), ("Römorkör/Pilot", "Römorkör"), ("Diğer", "Diğer")]

_S = 4   # buyuk cizip kucultme (yumusak kenar)

# govde (0..1 kutu, pruva YUKARIDA): sivri pruva, genis orta, duz kic
_GOVDE = [(0.50, 0.00), (0.66, 0.12), (0.82, 0.28), (0.92, 0.42), (0.94, 0.52),
          (0.94, 0.92), (0.88, 0.98), (0.76, 1.00), (0.24, 1.00), (0.12, 0.98), (0.06, 0.92),
          (0.06, 0.52), (0.08, 0.42), (0.18, 0.28), (0.34, 0.12)]


def _hex(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _ton(rgb, k):
    if k <= 1:
        return tuple(max(0, int(c * k)) for c in rgb)
    return tuple(min(255, int(c + (255 - c) * (k - 1))) for c in rgb)


def _poly(W, H, nokta, ox=0, oy=0, kucult=0.0):
    """kucult>0: govdeyi merkeze dogru daralt (guverte icin)."""
    cx, cy = 0.5, 0.5
    sonuc = []
    for x, y in nokta:
        x2 = cx + (x - cx) * (1 - kucult)
        y2 = cy + (y - cy) * (1 - kucult * 0.35)
        sonuc.append((ox + x2 * (W - 1), oy + y2 * (H - 1)))
    return sonuc


def _govde_ciz(boy, renk):
    g = max(8, int(boy * 0.42))
    W, H = g * _S, boy * _S
    kal = max(2, int(H * 0.06))            # borda kalinligi (3B)
    rgb = _hex(renk)
    img = Image.new("RGBA", (W + kal, H + kal), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    # 1) borda / yan yuz: koyu, saga-asagi kaydirilmis kopya (kalinlik hissi)
    for i in range(kal, 0, -1):
        d.polygon(_poly(W, H, _GOVDE, i * 0.8, i), fill=_ton(rgb, 0.45 + 0.15 * (1 - i / kal)) + (255,))

    # 2) guverte: soldan aydinlatilmis, ortasi parlak
    dolgu = Image.new("RGBA", (W, H))
    px = dolgu.load()
    for x in range(W):
        u = x / max(1, W - 1)
        k = 0.78 + 0.55 * (1 - abs(2 * u - 1) ** 1.4) + 0.18 * (1 - u)
        c = _ton(rgb, k) + (255,)
        for y in range(H):
            px[x, y] = c
    maske = Image.new("L", (W, H), 0)
    ImageDraw.Draw(maske).polygon(_poly(W, H, _GOVDE), fill=255)
    img.paste(dolgu, (0, 0), maske)
    d.line(_poly(W, H, _GOVDE) + [_poly(W, H, _GOVDE)[0]], fill=_ton(rgb, 0.35) + (255,), width=max(1, _S))

    # 3) pruva vurgusu: sivri uca parlak cizgi
    d.line([(W * 0.5, H * 0.03), (W * 0.5, H * 0.40)], fill=(255, 255, 255, 120), width=max(1, _S))

    # 4) ambar kapaklari (buyuk simgelerde)
    if boy >= 30:
        for i in range(3):
            y0 = H * (0.33 + i * 0.13)
            d.rounded_rectangle([W * 0.28, y0, W * 0.72, y0 + H * 0.09], radius=_S,
                                fill=_ton(rgb, 0.70) + (255,), outline=_ton(rgb, 0.45) + (255,), width=max(1, _S // 2))

    # 5) kaptan kosku (kicta): yan yuz koyu + ust yuz; kucuklerde koyu kabin
    kx0, kx1, ky0, ky1 = W * 0.24, W * 0.76, H * 0.78, H * 0.92
    if boy >= 30:
        d.rounded_rectangle([kx0 + _S, ky0 + _S * 1.5, kx1 + _S, ky1 + _S * 1.5], radius=_S, fill=(70, 80, 88, 255))
        d.rounded_rectangle([kx0, ky0, kx1, ky1], radius=_S, fill=(240, 243, 246, 255),
                            outline=(120, 130, 138, 255), width=max(1, _S // 2))
        d.line([(kx0 + W * 0.05, ky0 + H * 0.025), (kx1 - W * 0.05, ky0 + H * 0.025)],
               fill=(35, 60, 85, 255), width=max(2, _S))
    else:
        d.rounded_rectangle([kx0, ky0, kx1, ky1], radius=_S, fill=_ton(rgb, 0.40) + (255,))
    return img


def _iz_ciz(genislik, yukseklik):
    """Dumen suyu: kicin arkasinda acilan beyaz V (aci 0'da asagi dogru)."""
    W, H = genislik, yukseklik
    iz = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(iz)
    cx = W / 2
    for i in range(8):
        a = int(210 * (1 - i / 8))
        y0 = H * i / 8
        y1 = H * (i + 1) / 8
        w0 = W * (0.10 + 0.40 * i / 8)
        w1 = W * (0.10 + 0.40 * (i + 1) / 8)
        d.polygon([(cx - w0, y0), (cx + w0, y0), (cx + w1, y1), (cx - w1, y1)], fill=(255, 255, 255, a // 3))
        d.line([(cx - w0, y0), (cx - w1, y1)], fill=(255, 255, 255, a), width=max(1, _S))
        d.line([(cx + w0, y0), (cx + w1, y1)], fill=(255, 255, 255, a), width=max(1, _S))
    return iz.filter(ImageFilter.GaussianBlur(_S * 0.6))


class GemiSimgeleri:
    def __init__(self):
        self._onbellek = {}      # anahtar -> PhotoImage (sadece ana is parcaciginda)
        self._pil = {}           # anahtar -> PIL resmi (arka planda hazirlanabilir)
        self._ana = {}
        self._kilit = threading.Lock()

    def _ana_al(self, tur):
        with self._kilit:
            ana = self._ana.get(tur)
            if ana is None:
                renk, boy = TURLER.get(tur, TURLER["Diğer"])
                ana = _govde_ciz(boy, renk)
                self._ana[tur] = ana
            return ana

    @staticmethod
    def anahtar(tur, derece, seyir=False):
        if tur not in TURLER:
            tur = "Diğer"
        aci = int(round((derece or 0) / ACI_ADIMI)) * ACI_ADIMI % 360
        return (tur, aci, bool(seyir))

    def onisit(self, turler=("Kargo", "Tanker", "Yolcu", "Diğer", "Römorkör", "biz", "Balıkçı", "Hızlı tekne")):
        """Sik kullanilan simgeleri arka planda hazirla; harita acilinca gemiler aninda cizilir."""
        def is_():
            for seyir in (True, False):
                for tur in turler:
                    for aci in range(0, 360, ACI_ADIMI):
                        k = (tur, aci, seyir)
                        if k not in self._pil:
                            try:
                                self._pil[k] = self._pil_ciz(*k)
                            except Exception:
                                pass
        threading.Thread(target=is_, daemon=True).start()

    def al(self, tur, derece, seyir=False):
        """seyir=True: arkasinda dumen suyu cizilir."""
        anahtar = self.anahtar(tur, derece, seyir)
        foto = self._onbellek.get(anahtar)
        if foto is not None:
            return foto, anahtar
        img = self._pil.get(anahtar)
        if img is None:
            img = self._pil_ciz(*anahtar)
            self._pil[anahtar] = img
        foto = ImageTk.PhotoImage(img)
        self._onbellek[anahtar] = foto
        return foto, anahtar

    def hazir_mi(self, tur, derece, seyir=False):
        return self.anahtar(tur, derece, seyir) in self._onbellek

    def _pil_ciz(self, tur, aci, seyir):
        ana = self._ana_al(tur)
        # dumen suyunu dik (aci 0) halde govdenin altina ekle, sonra hepsini birlikte dondur
        iz_boy = int(ana.height * 0.75) if seyir else 0
        dik = Image.new("RGBA", (ana.width, ana.height + iz_boy), (0, 0, 0, 0))
        if seyir:
            dik.alpha_composite(_iz_ciz(ana.width, iz_boy), (0, ana.height - _S))
        dik.alpha_composite(ana, (0, 0))
        # donme merkezi geminin ortasi olsun diye ust tarafa da ayni bosluk
        kare = Image.new("RGBA", (dik.width, ana.height + 2 * iz_boy), (0, 0, 0, 0))
        kare.alpha_composite(dik, (0, iz_boy))
        don = kare.rotate(-aci, resample=Image.BICUBIC, expand=True)

        pay = 5 * _S
        kenar = max(don.width, don.height) + 2 * pay if tur == "hedef" else None
        tw, th = (kenar, kenar) if kenar else (don.width + 2 * pay, don.height + 2 * pay)
        tuval = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
        ox, oy = (tw - don.width) // 2, (th - don.height) // 2
        # suya dusen golge (isik sol-ustten): sadece govdeden, belirgin
        govde_don = Image.new("RGBA", kare.size, (0, 0, 0, 0))
        govde_don.alpha_composite(ana, (0, iz_boy))
        govde_don = govde_don.rotate(-aci, resample=Image.BICUBIC, expand=True)
        golge = Image.new("RGBA", govde_don.size, (5, 25, 40, 0))
        golge.putalpha(govde_don.getchannel("A").point(lambda a: int(a * 0.62)))
        golge = golge.filter(ImageFilter.GaussianBlur(_S * 1.4))
        tuval.alpha_composite(golge, (ox + int(_S * 3.0), oy + int(_S * 3.8)))
        if tur == "hedef":
            hd = ImageDraw.Draw(tuval)
            cx, cy = tw / 2, th / 2
            r = ana.height / 2 + _S * 3
            hd.ellipse([cx - r, cy - r, cx + r, cy + r], outline=(233, 30, 99, 170), width=_S * 2)
        tuval.alpha_composite(don, (ox, oy))
        return tuval.resize((max(1, tw // _S), max(1, th // _S)), Image.LANCZOS)

    def lejant(self, tur):
        """Ust seritteki kucuk aciklama simgesi (hale/iz yok, en fazla 22 px)."""
        anahtar = ("lejant", tur)
        if anahtar not in self._onbellek:
            ana = self._ana_al(tur)
            k = min(1.0, 22 * _S / ana.height)
            img = ana.resize((max(1, int(ana.width * k / _S)), max(1, int(ana.height * k / _S))), Image.LANCZOS)
            self._onbellek[anahtar] = ImageTk.PhotoImage(img)
        return self._onbellek[anahtar]
