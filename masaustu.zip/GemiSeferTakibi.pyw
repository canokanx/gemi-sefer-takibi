# -*- coding: utf-8 -*-
"""GEMİ SEFER TAKİBİ
Gemi listesi + bogaz gecis sirasi, VesselFinder haritasi (program icinde), hatirlatmalar.
"""
import os
import sys
import json
import math
import queue
import threading
import shutil
import webbrowser
import urllib.parse
import datetime as dt
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

PROGRAM_KLASOR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROGRAM_KLASOR)
KAYNAK = os.path.join(PROGRAM_KLASOR, "kaynak")
SURUM = "2.4"


def _veri_klasoru():
    """Kullanici verisi program klasorunden AYRI durur; guncelleme/yeniden kurulum veriyi silmez.
    Windows: %APPDATA%\\GemiSeferTakibi  (eski surumlerdeki %APPDATA%\\IRONHULL\\GemiSeferTakibi bir kez kopyalanir)"""
    kok = os.environ.get("APPDATA")
    if not kok:
        yol = os.path.join(PROGRAM_KLASOR, "veri")
        os.makedirs(yol, exist_ok=True)
        return yol
    yol = os.path.join(kok, "GemiSeferTakibi")
    eski = os.path.join(kok, "IRONHULL", "GemiSeferTakibi")
    if not os.path.exists(os.path.join(yol, "ayarlar.json")) and os.path.isdir(eski):
        try:
            import shutil
            shutil.copytree(eski, yol, dirs_exist_ok=True)       # eski klasor yedek olarak kalir
            ayar = os.path.join(yol, "ayarlar.json")
            if os.path.exists(ayar):
                with open(ayar, "r", encoding="utf-8") as f:
                    a = json.load(f)
                vt = a.get("vt_yolu") or ""
                if os.path.normcase(os.path.dirname(os.path.abspath(vt))) == os.path.normcase(os.path.abspath(eski)):
                    a["vt_yolu"] = os.path.join(yol, os.path.basename(vt))
                with open(ayar, "w", encoding="utf-8") as f:
                    json.dump(a, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
    os.makedirs(yol, exist_ok=True)
    return yol


VERI_KLASOR = _veri_klasoru()


def _eski_veriyi_tasi():
    """Eski surumde veriler program klasorundeydi (ayarlar.json + veri/). Yeni yere bir kez kopyalar."""
    import shutil
    if os.path.exists(os.path.join(VERI_KLASOR, "ayarlar.json")):
        return
    adaylar = [PROGRAM_KLASOR]
    ev = os.environ.get("USERPROFILE") or os.path.expanduser("~")
    for masaustu in (os.path.join(ev, "Desktop"), os.path.join(ev, "OneDrive", "Desktop"),
                     os.path.join(ev, "OneDrive", "Masaüstü"), os.path.join(ev, "Masaüstü")):
        adaylar.append(os.path.join(masaustu, "GemiSeferTakibi", "GemiSeferTakibi"))
        adaylar.append(os.path.join(masaustu, "GemiSeferTakibi"))
    for eski in adaylar:
        eski_veri = os.path.join(eski, "veri")
        eski_ayar = os.path.join(eski, "ayarlar.json")
        if not (os.path.exists(eski_ayar) or os.path.exists(os.path.join(eski_veri, "sefer_takip.db"))):
            continue
        try:
            if os.path.isdir(eski_veri):
                for ad in os.listdir(eski_veri):
                    kaynak = os.path.join(eski_veri, ad)
                    if os.path.isfile(kaynak) and not os.path.exists(os.path.join(VERI_KLASOR, ad)):
                        shutil.copy2(kaynak, os.path.join(VERI_KLASOR, ad))
            if os.path.exists(eski_ayar):
                with open(eski_ayar, "r", encoding="utf-8") as f:
                    a = json.load(f)
                vt = a.get("vt_yolu") or ""
                if not vt or os.path.normcase(os.path.dirname(os.path.abspath(vt))) == os.path.normcase(os.path.abspath(eski_veri)):
                    a["vt_yolu"] = os.path.join(VERI_KLASOR, "sefer_takip.db")
                a["eski_konum"] = eski
                with open(os.path.join(VERI_KLASOR, "ayarlar.json"), "w", encoding="utf-8") as f:
                    json.dump(a, f, ensure_ascii=False, indent=2)
        except Exception:
            pass
        return


try:
    _eski_veriyi_tasi()
except Exception:
    pass

from veritabani import (Veritabani, simdi_str, tarih_coz, tr_lower, GemiZatenVar, STANDART_BELGELER)
from ais_takip import AISTakip, NAV_DURUM, gemi_tipi_adi, yon
from gemi_bilgi import Rehber, mmsi_bayrak, imo_gecerli
from bogaz_sirasi import BogazSirasi, BOGAZLAR, YONLER, gecmis_getir, trafik_durumu
from gomulu_web import GomuluWeb
from tepsi import Tepsi, TekKopya, otomatik_baslat_ayarla
import bildirim
import raporlar
import guncelleme
from istatistik import Istatistik, sure_metni
import time

try:
    import winsound
except ImportError:
    winsound = None

AYAR_DOSYA = os.path.join(VERI_KLASOR, "ayarlar.json")
VARSAYILAN_AYAR = {
    "kullanici": "",
    "sirket_adi": "",                 # ilk acilista sorulur; basliklarda ve maillerde gorunur
    "sirket_unvani": "",
    "vt_yolu": os.path.join(VERI_KLASOR, "sefer_takip.db"),
    "ais_anahtar": "",
    "hatirlatma_saat": 24,
    "otomatik_baslat": True,          # Windows acilisinda arka planda basla
    "gemilerimi_takip": True,         # Gemilerim'deki gemiler bogaz listesinde otomatik takipte
    "bogaz_takip": [],                # [{"k": imo|mmsi, "ad": ...}] bogaz listesinden secilenler
    "trafik_mail": True,              # bogaz trafik plani degisince / yarinin plani yayinlaninca mail
    "trafik_anlik": True,             # acildi / askiya alindi anlarinda tepsi bildirimi
    "trafik_anlik_mail": False,       # ... ve mail
    "ozet_aktif": False,              # sabah ozeti maili
    "ozet_saat": "08:00",
    "son_ozet": "",
    "rapor_dil": "TR",
    "otomatik_guncelle": True,        # ekip: yeni surum yayinlaninca kendiliginden kur
    "guncelleme_kaynagi": "",         # bos ise ortak veritabanindaki (yoneticinin ayarladigi) kullanilir
    "yonetici_sifre": "",             # sha256
    "yayin_klasoru": "",
    "yayin_yeri": "github",           # github | klasor
    "github_kullanici": "", "github_depo": "gemi-sefer-takibi", "github_token": "",
    "yayin_no": 0,
    "link_surum_json": "", "link_apk": "", "link_web": "", "link_masaustu": "",
    "rapor_alicilar": "",
    "mail_aktif": False,
    "mail_yontem": "Outlook",         # Outlook | SMTP
    "mail_alicilar": "",
    "smtp_hazir": "Gmail",
    "smtp_sunucu": "smtp.gmail.com",
    "smtp_port": 587,
    "smtp_kullanici": "",
    "smtp_sifre": "",
}

# ---- Okyanus Esintisi temasi
TEAL = "#0E7C86"
TEAL_KOYU = "#0A5C63"
MERCAN = "#F2704F"
ZEMIN = "#F4F8F8"
KART = "#FFFFFF"
YAZI = "#1E2A2E"
SOLUK = "#6B7C80"
KIRMIZI = "#C62828"

BELGE_ADLARI = sorted({ad for ad, _, _ in STANDART_BELGELER} | {
    "Konşimento (B/L)", "Draft Survey", "Tayfa Değişimi Dilekçesi", "Shore Pass", "Kumanya Siparişi",
    "Proforma DA", "Final DA", "Bunker", "Atık Alımı", "Kılavuz Kaptan"})

KILAVUZ = {
    "Harita": (
        "HARİTA (VesselFinder)\n\n"
        "• Harita VesselFinder'ın tam kapsamlı haritasıdır; programın içinde açılır.\n"
        "• Üstteki kutuya IMO (7 hane), MMSI (9 hane) ya da gemi adı yazıp 'Bul'a basın:\n"
        "  harita gemiyi son 24 saatlik rotasıyla gösterir.\n"
        "• Bölge düğmeleri (Marmara, İstanbul Boğazı, Çanakkale…) o bölgedeki bütün gemileri gösterir.\n"
        "• Soldaki listede gemiye tıklayınca harita o gemiye gider.\n"
        "• Haritadaki gemiye tıklayınca VesselFinder'ın bilgi kutusu açılır (tip, varış, ETA, hız).\n"
        "• Gemiler sekmesinde boğaz listesinde çift tıklayınca da harita o gemiyi gösterir."),
    "Gemiler": (
        "GEMİLER\n\n"
        "• '＋ Yeni Gemi' → IMO yazın: ad, MMSI, çağrı işareti, bayrak, tip, boy, en ve su çekimi\n"
        "  kendiliğinden dolar. Sağdaki Bilgi Kartı boğaz sırası, AIS varış/ETA ve Kıyı Emniyeti\n"
        "  boğaz geçiş geçmişini gösterir. DWT, GRT ve yapım yılı elle girilir.\n"
        "  Gemi hiç görülmediyse AIS'te dünya genelinde aranır (1-8 dk); kaydedip bekleyebilirsiniz.\n"
        "• Aynı gemiyi iki kez ekleyemezsiniz; program mevcut kayda işlemeyi önerir.\n"
        "• Boğaz listesinde gemiyi seçip '🔔 Takip / Mail' (ya da sağ tık): statüsü değişince bildirim\n"
        "  ve e-posta gelir. Gemilerim'deki gemiler otomatik takiptedir. E-posta ayarı: Ayarlar sekmesi.\n"
        "• '📄 Durum Raporu': seçtiğiniz gemiler için Türkçe/İngilizce rapor; mail (tablo), Excel ya da kopyala.\n"
        "• Boğaz başlığının ortası: anlık boğaz trafiği (tıklayınca günlük çizelge). '📊 İstatistik': bekleme süreleri.\n"
        "• Takipteki gemi Marmara'ya gelirken, boğaza girerken ya da AIS varış/ETA'sı değişince bildirim gelir.\n"
        "• Ayarlar → Otomatik Bildirimler: trafik planı maili, sabah özeti.\n"        "• Yönetici sekmesi (şifreli): 'Güncelleme Yayınla' ekipteki programları ve telefonları günceller.\n"
        "• Çarpıdan kapatınca program saat yanındaki simgeye iner ve 5 dk'da bir yenilemeye devam eder.\n"
        "  Tamamen kapatmak için simgeye sağ tık → Kapat.\n"
        "• 'Haritada Göster' gemiyi haritada bulur."),
    "Hatırlatmalar": (
        "HATIRLATMALAR\n\n"
        "• Tek liste: açık işler, en acil en üstte. Gecikmiş kırmızı, yaklaşan turuncu.\n"
        "• '＋ Ekle': gemi + iş + son tarih (18.10.2026 14:30). Çift tıklayınca düzenlenir.\n"
        "• 'Standart Belgeleri Ekle': gemi, ETA ve ETD'yi sorar; NOR, SOF, LTP bildirimleri vb.\n"
        "  8 işi son tarihleriyle birlikte ekler.\n"
        "• İş bitince '✔ Tamamlandı'. Program açıkken her dakika kontrol eder ve sesli uyarır."),
    "Ayarlar": (
        "AYARLAR\n\n"
        "• Kullanıcı adı: değişikliklerde adınız görünür.\n"
        "• Ortak Veritabanı: ekip aynı dosyayı seçerse herkes aynı gemileri görür\n"
        "  (OneDrive/Drive ortak klasörü ya da ofis ağ klasörü).\n"
        "• AISStream anahtarı: aisstream.io → GitHub ile giriş → API Keys → Create (ücretsiz).\n"
        "• Veriler program klasöründen ayrı, %APPDATA%\\GemiSeferTakibi içinde durur;\n"
        "  programı güncellemek ya da yeniden kurmak verileri silmez."),
}


# ======================================================================  yardimcilar
def pythonw_yolu():
    exe = sys.executable
    klasor, ad = os.path.split(exe)
    if ad.lower() == "python.exe":
        aday = os.path.join(klasor, "pythonw.exe")
        if os.path.exists(aday):
            return aday
    return exe


def bilgisayar_adi():
    import platform
    return os.environ.get("COMPUTERNAME") or platform.node() or "?"


def ayar_yukle():
    a = dict(VARSAYILAN_AYAR)
    try:
        with open(AYAR_DOSYA, "r", encoding="utf-8") as f:
            a.update(json.load(f))
    except (OSError, ValueError):
        pass
    return a


def ayar_kaydet(a):
    with open(AYAR_DOSYA, "w", encoding="utf-8") as f:
        json.dump(a, f, ensure_ascii=False, indent=2)


def bos(x):
    return "" if x is None else str(x)


def ortala(pencere, ebeveyn):
    pencere.update_idletasks()
    try:
        ust = ebeveyn.winfo_toplevel()
        x = ust.winfo_rootx() + (ust.winfo_width() - pencere.winfo_reqwidth()) // 2
        y = ust.winfo_rooty() + (ust.winfo_height() - pencere.winfo_reqheight()) // 3
        pencere.geometry(f"+{max(0, x)}+{max(0, y)}")
    except tk.TclError:
        pass


def tablo_olustur(ebeveyn, sutunlar, yukseklik=None):
    cerceve = ttk.Frame(ebeveyn)
    tv = ttk.Treeview(cerceve, columns=[s[0] for s in sutunlar], show="headings", selectmode="browse")
    if yukseklik:
        tv.configure(height=yukseklik)
    for k, b, g in sutunlar:
        tv.heading(k, text=b)
        tv.column(k, width=g, minwidth=40, anchor="w", stretch=True)
    sy = ttk.Scrollbar(cerceve, orient="vertical", command=tv.yview)
    tv.configure(yscrollcommand=sy.set)
    tv.grid(row=0, column=0, sticky="nsew")
    sy.grid(row=0, column=1, sticky="ns")
    cerceve.rowconfigure(0, weight=1)
    cerceve.columnconfigure(0, weight=1)
    return cerceve, tv


def secili_id(tv):
    s = tv.selection()
    try:
        return int(s[0]) if s else None
    except ValueError:
        return None


def konum_zamani(gemi):
    """'18.10.2026 14:30' -> '14:30' bugunse, yoksa '17.10 14:30'."""
    z = bos(gemi.get("ais_zaman"))
    if len(z) == 16:
        return z[-5:] if z[:10] == dt.datetime.now().strftime("%d.%m.%Y") else z[:5] + z[10:]
    return z


# ======================================================================  ana pencere
class Uygulama(tk.Tk):
    def __init__(self, arkaplan=False):
        super().__init__()
        if arkaplan:
            self.withdraw()                 # Windows acilisinda: pencere yok, sadece tepsi simgesi
        self.tek_kopya = None
        self._gizleme_bildirildi = False
        self.title("GEMİ SEFER TAKİBİ")
        self._ikon_ayarla()
        self.geometry("1380x820")
        self.minsize(1080, 640)
        self.configure(bg=ZEMIN)
        self.ayar = ayar_yukle()
        self.ais = None
        self.kuyruk = queue.Queue()
        self.gosterilen_hatirlatma = set()
        self.son_gunluk_id = -1
        self.bekleyen_formlar = {}          # imo -> GemiFormu (dunya geneli arama bekleyen)
        try:
            self.rehber = Rehber(os.path.join(VERI_KLASOR, "rehber.db"))
        except Exception:
            self.rehber = None
        self._stil()
        self._ust_bant()

        if not (self.ayar.get("kullanici") and self.ayar.get("sirket_adi")):
            if arkaplan:
                self.deiconify()
            self._ilk_acilis()
        self.marka_uygula()
        self.vt = self._vt_ac()

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=10, pady=(0, 6))
        self.bogaz = BogazSirasi(os.path.join(VERI_KLASOR, "bogaz_sirasi.json"),
                                 lambda v: self.kuyruk.put(("bogaz", v)),
                                 lambda m: self.kuyruk.put(("bogaz_durum", m)))
        self.sekme_gemi = GemiSekmesi(self.nb, self)
        self.sekme_harita = HaritaSekmesi(self.nb, self)
        self.sekme_hat = HatirlatmaSekmesi(self.nb, self)
        self.sekme_ayar = AyarSekmesi(self.nb, self)
        self.sekme_yonetici = YoneticiSekmesi(self.nb, self)
        self.nb.add(self.sekme_gemi, text="  🚢 Gemiler  ")
        self.nb.add(self.sekme_harita, text="  🗺 Harita  ")
        self.nb.add(self.sekme_hat, text="  ⏰ Hatırlatmalar  ")
        self.nb.add(self.sekme_ayar, text="  ⚙ Ayarlar  ")
        self.nb.add(self.sekme_yonetici, text="  🛡 Yönetici  ")
        # Harita sekmesine gecilince gemileri hemen ciz (gizliyken cizilmiyor)
        self.nb.bind("<<NotebookTabChanged>>", lambda e: self.after(120, self.sekme_harita.gorundu)
                     if self.nb.select() == str(self.sekme_harita) else None)

        self.durum_cubugu = tk.Label(self, anchor="w", bg=TEAL_KOYU, fg="white", font=("Segoe UI", 9), padx=10)
        self.durum_cubugu.pack(fill="x", side="bottom")
        self.ais_etiket = tk.Label(self.durum_cubugu, bg=TEAL_KOYU, fg="#CFEFF1", font=("Segoe UI", 9))
        self.ais_etiket.pack(side="right")

        self.hepsini_yenile()
        self.ais_baslat()
        self.bogaz.baslat()
        self.after(1500, self._hatirlatma_dongusu)
        self.after(500, self._kuyruk_oku)
        self.after(30000, self._otomatik_yenile)
        self.takip = bildirim.TakipDurumu(os.path.join(VERI_KLASOR, "bogaz_takip_durum.json"))
        self.trafik_takip = raporlar.TrafikTakip(os.path.join(VERI_KLASOR, "trafik_son.json"))
        try:
            self.istatistik = Istatistik(os.path.join(VERI_KLASOR, "bogaz_istatistik.db"))
        except Exception:
            self.istatistik = None
        self.tepsi = Tepsi(os.path.join(KAYNAK, "gemi_sefer.ico"), self.tepsi_basligi(),
                           ac=lambda: self.kuyruk.put(("goster", None)),
                           yenile=lambda: self.kuyruk.put(("tepsi_yenile", None)),
                           kapat=lambda: self.kuyruk.put(("tepsi_kapat", None)))
        self.tepsi.baslat()
        self.after(2000, self.otomatik_baslat_uygula)
        self.after(20000, self.guncelleme_dongusu)
        self.protocol("WM_DELETE_WINDOW", self._gizle)      # carpi: kapanmaz, tepsiye iner

    # ------------------------------------------------------------ arka plan / tepsi
    def otomatik_baslat_uygula(self):
        ok, mesaj = otomatik_baslat_ayarla(bool(self.ayar.get("otomatik_baslat")), pythonw_yolu(),
                                           os.path.join(PROGRAM_KLASOR, "GemiSeferTakibi.pyw"),
                                           os.path.join(KAYNAK, "gemi_sefer.ico"))
        return ok, mesaj

    def goster(self):
        self.deiconify()
        self.state("normal")
        self.lift()
        self.attributes("-topmost", True)
        self.after(300, lambda: self.attributes("-topmost", False))
        self.focus_force()

    def _gizle(self):
        if not self.tepsi.hazir:
            self.iconify()                  # tepsi simgesi yoksa en azindan gorev cubuguna insin
            return
        self.withdraw()
        if not self._gizleme_bildirildi:
            self._gizleme_bildirildi = True
            self.tepsi.bildir("Program arka planda çalışmaya devam ediyor (boğaz listesi 5 dk'da bir yenilenir).\n"
                              "Açmak: simgeye çift tıklayın. Kapatmak: sağ tık → Kapat.")

    # ------------------------------------------------------------ bogaz takibi + e-posta
    def izlenen_gemiler(self):
        """{imo|mmsi: ad} — bogaz listesinde statusu izlenen gemiler"""
        iz = {}
        for t in self.ayar.get("bogaz_takip") or []:
            if t.get("k"):
                iz[t["k"]] = t.get("ad") or t["k"]
        if self.ayar.get("gemilerimi_takip", True):
            try:
                for g in self.vt.gemiler():
                    k = g.get("imo") or g.get("mmsi")
                    if k and k not in iz and not (g.get("mmsi") and g["mmsi"] in iz):
                        iz[k] = g["ad"]
            except Exception:
                pass
        return iz

    def takip_degistir(self, satir):
        """Bogaz listesindeki gemiyi takibe al / takipten cikar. Donus: yeni durum (True = takipte)"""
        k = satir.get("imo") or satir.get("mmsi")
        if not k:
            return False
        liste = [t for t in (self.ayar.get("bogaz_takip") or []) if t.get("k")]
        anahtarlar = {satir.get("imo"), satir.get("mmsi")} - {"", None}
        if any(t["k"] in anahtarlar for t in liste):
            liste = [t for t in liste if t["k"] not in anahtarlar]
            durum = False
        else:
            liste.append({"k": k, "ad": satir.get("ad") or k})
            durum = True
        self.ayar["bogaz_takip"] = liste
        ayar_kaydet(self.ayar)
        return durum

    def _bogaz_takip_kontrol(self, veri):
        if self.bogaz.hata or not (veri.get("I") or veri.get("C")):
            return
        izlenen = self.izlenen_gemiler()
        ais = {}
        for k, ad in izlenen.items():
            b = self.bilgi_bul(imo=k if len(k) == 7 else None, mmsi=k if len(k) == 9 else None) or {}
            if b.get("varis") or b.get("eta"):
                ais[k] = {"varis": b.get("varis"), "eta": b.get("eta"), "ad": b.get("ad") or ad,
                          "imo": b.get("imo"), "mmsi": b.get("mmsi")}
        olaylar = self.takip.guncelle(veri, izlenen, ais)
        if not olaylar:
            return
        konu, govde = bildirim.mail_icerigi(olaylar, veri.get("zaman", ""), self.firma_imzasi(), self.firma_adi())
        self.durum(konu)
        self.tepsi.bildir("\n".join(bildirim.olay_metni(o).split("\n")[0] + " " + (o.get("durum") or "")
                                    for o in olaylar[:4]), "⚓ Takipteki gemi")
        if self.mail_hazir():
            self.mail_gonder(konu, govde)

    def mail_hazir(self):
        return bool(self.ayar.get("mail_aktif") and bildirim.alicilari_coz(self.ayar.get("mail_alicilar")))

    # ------------------------------------------------------------ bogaz trafigi degisiklikleri
    def _trafik_kontrol(self, veri):
        olaylar = self.trafik_takip.guncelle(veri.get("trafik"))
        if not olaylar:
            return
        konu, govde, html = raporlar.trafik_mail_icerigi(olaylar, self.firma_adi(), self.firma_imzasi())
        self.durum(konu)
        self.tepsi.bildir("\n".join(f"{raporlar.BOGAZ[o['bogaz']]} {raporlar.YON_TRAFIK[o['yon']]}: "
                                    f"{'plan değişti' if o['tur'] == 'degisti' else 'yeni plan'} ({o['tarih'][:5]})"
                                    for o in olaylar[:4]), "⚓ Boğaz trafik planı")
        if self.ayar.get("trafik_mail", True) and self.mail_hazir():
            self.mail_gonder(konu, govde, html=html)

    # ------------------------------------------------------------ otomatik guncelleme
    def surum(self):
        return guncelleme.yuklu_surum(PROGRAM_KLASOR, SURUM)

    def kaynak_klasor_mu(self):
        """Yoneticinin kaynak klasoru (android/ ve kurulum/ var): kendini guncellemez."""
        return os.path.isdir(os.path.join(PROGRAM_KLASOR, "android"))

    def guncelleme_kaynagi(self):
        k = (self.ayar.get("guncelleme_kaynagi") or "").strip()
        if not k:
            try:
                k = self.vt.meta_al("guncelleme_kaynagi") or ""
            except Exception:
                k = ""
        return k

    def guncelleme_dongusu(self):
        try:
            self.vt.kurulum_bildir(bilgisayar_adi(), self.ayar.get("kullanici", "?"), self.surum())
        except Exception:
            pass
        if self.ayar.get("otomatik_guncelle", True) and not self.kaynak_klasor_mu():
            self.guncelleme_kontrol()
        self.after(30 * 60 * 1000, self.guncelleme_dongusu)

    def guncelleme_kontrol(self, elle=False):
        kaynak = self.guncelleme_kaynagi()
        if not kaynak:
            if elle:
                self.kuyruk.put(("guncelleme_sonuc", (False, "Güncelleme kaynağı ayarlanmamış (yönetici yayınlayınca otomatik gelir).")))
            return
        mevcut = self.surum()

        def is_():
            try:
                bilgi = guncelleme.kontrol_et(kaynak)
                yeni = str(bilgi.get("masaustu_surum") or "")
                if not guncelleme.daha_yeni(yeni, mevcut):
                    if elle:
                        self.kuyruk.put(("guncelleme_sonuc", (False, f"Program güncel (sürüm {mevcut}).")))
                    return
                if self.kaynak_klasor_mu():
                    self.kuyruk.put(("guncelleme_sonuc", (False, "Bu yöneticinin kaynak klasörü; kendini güncellemez.")))
                    return
                kurulan = guncelleme.indir_ve_kur(kaynak, bilgi, PROGRAM_KLASOR)
                self.kuyruk.put(("guncellendi", (kurulan, bilgi.get("notlar") or "")))
            except Exception as e:
                if elle:
                    self.kuyruk.put(("guncelleme_sonuc", (False, f"Güncelleme kontrol edilemedi: {e}")))
        threading.Thread(target=is_, daemon=True).start()

    def _guncellendi(self, surum, notlar):
        try:
            self.vt.kurulum_bildir(bilgisayar_adi(), self.ayar.get("kullanici", "?"), surum)
        except Exception:
            pass
        mesaj = f"Program {surum} sürümüne güncellendi." + (f"\n{notlar}" if notlar else "")
        self.tepsi.bildir(mesaj + "\nYeniden başlatılıyor…", "⬆ Gemi Sefer Takibi")
        self.durum("⬆ " + mesaj.replace("\n", "  "))
        if self.state() == "withdrawn":
            self.after(3000, self.yeniden_baslat)
        elif messagebox.askyesno("Güncelleme", mesaj + "\n\nŞimdi yeniden başlatılsın mı?", parent=self):
            self.yeniden_baslat()

    def dakika_kontrol(self):
        """Her dakika: bogaz trafiginin acilip askiya alinmasi + sabah ozeti zamani"""
        t = self.bogaz.veri.get("trafik")
        degisen = self.trafik_takip.anlik_kontrol(t, trafik_durumu)
        if degisen and self.ayar.get("trafik_anlik", True):
            satir = [f"{raporlar.BOGAZ[k]} {raporlar.YON_TRAFIK[y]}: "
                     f"{'AÇILDI' if yeni == 'acik' else ('ASKIYA ALINDI' if yeni == 'askida' else 'PLANSIZ')}"
                     f"  ({sonra})" for k, y, eski, yeni, sonra in degisen]
            self.durum("⚓ " + " | ".join(satir))
            self.tepsi.bildir("\n".join(satir), "⚓ Boğaz trafiği")
            if self.ayar.get("trafik_anlik_mail") and self.mail_hazir():
                firma = self.firma_adi()
                self.mail_gonder((f"[{firma}] " if firma else "") + "⚓ Boğaz trafiği: " + "; ".join(satir),
                                 "\n".join(satir) + f"\n\n{dt.datetime.now():%d.%m.%Y %H:%M}\n\n" + self.firma_imzasi())
        self._ozet_zamani_mi()

    # ------------------------------------------------------------ sabah ozeti
    def _ozet_zamani_mi(self):
        if not self.ayar.get("ozet_aktif") or not self.mail_hazir():
            return
        simdi = dt.datetime.now()
        bugun = simdi.strftime("%d.%m.%Y")
        if self.ayar.get("son_ozet") == bugun:
            return
        try:
            sa, dk = (int(x) for x in str(self.ayar.get("ozet_saat") or "08:00").split(":"))
        except ValueError:
            sa, dk = 8, 0
        if (simdi.hour, simdi.minute) < (sa, dk):
            return
        if not self.bogaz.veri.get("zaman"):
            return                              # liste henuz gelmedi; bir sonraki dakika
        self.ayar["son_ozet"] = bugun
        ayar_kaydet(self.ayar)
        self.ozet_gonder()

    def ozet_verisi(self):
        t = self.bogaz.veri.get("trafik")
        trafik_s = []
        for k in ("I", "C"):
            for y in ("KG", "GK"):
                d = trafik_durumu(t, k, y)
                plan = ", ".join(f"{a}–{b} {raporlar.DURUM_AD.get(du, du)}" for a, b, du, _ in
                                 (((t or {}).get("bugun") or {}).get(k) or {}).get(y) or []) or "planlanmamış"
                trafik_s.append((k, y, d[0] if d else "", d[2] if d else "bilgi yok", plan))
        gemiler = [self.rapor_verisi(k) for k in self.izlenen_gemiler()]
        try:
            hat = self.vt.yaklasanlar(24)
        except Exception:
            hat = []
        return trafik_s, gemiler, hat

    def ozet_gonder(self, geri=None):
        konu, metin, html = raporlar.sabah_ozeti(*self.ozet_verisi(), firma=self.firma_adi(),
                                                 imza=self.firma_imzasi())
        self.mail_gonder(konu, metin, html=html, geri=geri)

    # ------------------------------------------------------------ rapor verisi
    def rapor_verisi(self, anahtar, ad=""):
        """Bir gemi (imo ya da mmsi) icin rapor satiri sozlugu: kimlik + bogaz sirasi + AIS"""
        imo = anahtar if len(anahtar) == 7 else ""
        mmsi = anahtar if len(anahtar) == 9 else ""
        g = None
        for x in self.vt.gemiler():
            if (imo and x.get("imo") == imo) or (mmsi and x.get("mmsi") == mmsi):
                g = x
                break
        imo = imo or (g or {}).get("imo") or ""
        mmsi = mmsi or (g or {}).get("mmsi") or ""
        b = self.bilgi_bul(imo=imo or None, mmsi=mmsi or None) or {}
        bz = self.bogaz.bul(imo or b.get("imo") or "", mmsi or b.get("mmsi") or "")
        s = {"ad": (g or {}).get("ad") or b.get("ad") or ad or anahtar, "imo": imo or b.get("imo") or "",
             "mmsi": mmsi or b.get("mmsi") or "", "bayrak": (g or {}).get("bayrak") or b.get("bayrak") or "",
             "tip": (g or {}).get("tip") or b.get("tip_metin") or b.get("tip_adi") or "",
             "varis": b.get("varis") or "", "eta": b.get("eta") or ""}
        if bz:
            kod, sira, sat = bz
            s.update(bogaz_kod=kod, sira=str(sira), durum=sat.get("durum") or "", plan=sat.get("plan_zamani") or "",
                     yon=sat.get("yon") or "")
            if not s["tip"]:
                s["tip"] = (sat.get("tip") or "").title()
        if g and g.get("mmsi"):
            if g.get("lat") is not None:
                s["ais_durum"] = NAV_DURUM.get(g.get("nav_durum"), "konum var")
            if g.get("sog") is not None:
                s["hiz"] = f"{g['sog']:.1f} kn"
            s["son_konum"] = bos(g.get("ais_zaman"))
        elif b.get("son"):
            s["son_konum"] = b["son"]
        return s

    def mail_gonder(self, konu, govde, geri=None, html=None, alicilar=None):
        ayar = dict(self.ayar)

        def is_():
            try:
                bildirim.gonder(ayar, konu, govde, html=html, alicilar=alicilar)
                self.kuyruk.put(("mail_sonuc", (True, f"✉ E-posta gönderildi: {konu}", geri)))
            except Exception as e:
                self.kuyruk.put(("mail_sonuc", (False, f"✖ E-posta gönderilemedi: {e}", geri)))
        threading.Thread(target=is_, daemon=True).start()

    # ------------------------------------------------------------ gorunum
    def _stil(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure(".", font=("Segoe UI", 10), background=ZEMIN, foreground=YAZI)
        s.configure("TNotebook", background=ZEMIN, borderwidth=0)
        s.configure("TNotebook.Tab", padding=(12, 6), font=("Segoe UI", 10, "bold"),
                    background="#DCEAEA", foreground=TEAL_KOYU)
        s.map("TNotebook.Tab", background=[("selected", TEAL)], foreground=[("selected", "white")])
        s.configure("TFrame", background=ZEMIN)
        s.configure("TLabel", background=ZEMIN)
        s.configure("Treeview", rowheight=26, font=("Segoe UI", 10), fieldbackground=KART)
        s.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background=TEAL,
                    foreground="white", relief="flat")
        s.map("Treeview.Heading", background=[("active", TEAL_KOYU)])
        s.map("Treeview", background=[("selected", MERCAN)], foreground=[("selected", "white")])
        s.configure("Ana.TButton", font=("Segoe UI", 10, "bold"), background=TEAL,
                    foreground="white", padding=(10, 5), borderwidth=0)
        s.map("Ana.TButton", background=[("active", TEAL_KOYU)])
        s.configure("Vurgu.TButton", font=("Segoe UI", 10, "bold"), background=MERCAN,
                    foreground="white", padding=(10, 5), borderwidth=0)
        s.map("Vurgu.TButton", background=[("active", "#D85A3B")])
        s.configure("TButton", padding=(8, 4))
        s.configure("TCheckbutton", background=ZEMIN)

    def _ikon_ayarla(self):
        ico = os.path.join(KAYNAK, "gemi_sefer.ico")
        png = os.path.join(KAYNAK, "logo.png")
        try:
            if os.name == "nt" and os.path.exists(ico):
                self.iconbitmap(default=ico)
            elif os.path.exists(png):
                self._ikon_resim = tk.PhotoImage(file=png).subsample(16, 16)
                self.iconphoto(True, self._ikon_resim)
        except tk.TclError:
            pass

    def _ust_bant(self):
        ust = tk.Frame(self, bg=TEAL, height=54)
        ust.pack(fill="x")
        self._logo = None
        try:
            self._logo = tk.PhotoImage(file=os.path.join(KAYNAK, "logo40.png"))
            tk.Label(ust, image=self._logo, bg=TEAL).pack(side="left", padx=(12, 0), pady=6)
        except tk.TclError:
            pass
        tk.Label(ust, text="GEMİ SEFER TAKİBİ" if self._logo else "⚓  GEMİ SEFER TAKİBİ", bg=TEAL, fg="white",
                 font=("Segoe UI", 16, "bold")).pack(side="left", padx=(10, 14), pady=8)
        self.firma_etiket = tk.Label(ust, text="", bg=TEAL, fg="#BFE6E9", font=("Segoe UI", 10))
        self.firma_etiket.pack(side="left", pady=(14, 8))
        tk.Button(ust, text="⟳ Yeniden Başlat", command=self.yeniden_baslat, bg=TEAL_KOYU,
                  fg="white", relief="flat", font=("Segoe UI", 10, "bold"), padx=10,
                  activebackground="#08474D", activeforeground="white", cursor="hand2"
                  ).pack(side="right", padx=(0, 12))
        tk.Button(ust, text="❓ Kullanım Kılavuzu", command=self.kilavuz_goster, bg=MERCAN,
                  fg="white", relief="flat", font=("Segoe UI", 10, "bold"), padx=10,
                  activebackground="#D85A3B", activeforeground="white", cursor="hand2"
                  ).pack(side="right", padx=8)
        self.saat_etiket = tk.Label(ust, bg=TEAL, fg="white", font=("Segoe UI", 10))
        self.saat_etiket.pack(side="right", padx=8)
        self._saat()

    def _saat(self):
        self.saat_etiket.config(text=dt.datetime.now().strftime("%d.%m.%Y  %H:%M"))
        self.after(20000, self._saat)

    def kilavuz_goster(self):
        sekme = self.nb.tab(self.nb.select(), "text")
        anahtar = next((k for k in KILAVUZ if k in sekme), "Harita")
        messagebox.showinfo("Kullanım Kılavuzu", KILAVUZ[anahtar], parent=self)

    def durum(self, metin):
        self.durum_cubugu.config(text=metin)

    # ------------------------------------------------------------ ilk acilis / vt
    # ------------------------------------------------------------ sirket bilgisi
    def firma_adi(self):
        return (self.ayar.get("sirket_adi") or "").strip()

    def firma_unvani(self):
        return (self.ayar.get("sirket_unvani") or "").strip()

    def firma_imzasi(self):
        """Mail imzasi: '— Gemi Sefer Takibi' + sirket unvani (yoksa adi)"""
        f = self.firma_unvani() or self.firma_adi()
        return "— Gemi Sefer Takibi" + (f"\n{f}" if f else "")

    def tepsi_basligi(self):
        return "Gemi Sefer Takibi" + (f" — {self.firma_adi()}" if self.firma_adi() else "")

    def marka_uygula(self):
        """Sirket adi/unvani programin her yerine (pencere basligi, ust bant, tepsi) islenir."""
        ad, unvan = self.firma_adi(), self.firma_unvani()
        self.title("GEMİ SEFER TAKİBİ" + (f" — {ad}" if ad else ""))
        try:
            self.firma_etiket.config(text=unvan or ad)
        except (AttributeError, tk.TclError):
            pass
        t = getattr(self, "tepsi", None)
        if t is not None and t.icon is not None:
            try:
                t.icon.title = self.tepsi_basligi()
            except Exception:
                pass

    def _ilk_acilis(self):
        p = tk.Toplevel(self)
        p.title("Hoş geldiniz")
        p.configure(bg=ZEMIN)
        p.transient(self)
        p.grab_set()
        tk.Label(p, text="  Gemi Sefer Takibi — İlk Ayarlar", bg=TEAL, fg="white", font=("Segoe UI", 12, "bold"),
                 anchor="w", padx=10, pady=8).pack(fill="x")
        g = ttk.Frame(p, padding=(20, 14, 20, 4))
        g.pack()
        alanlar = {}
        for i, (k, etiket, ipucu) in enumerate([
                ("kullanici", "Adınız *", "değişiklik kayıtlarında görünür"),
                ("sirket_adi", "Şirket adı *", "pencere başlığında ve bildirimlerde görünür"),
                ("sirket_unvani", "Şirket ünvanı", "üst bantta ve e-posta imzasında görünür")]):
            ttk.Label(g, text=etiket, font=("Segoe UI", 10, "bold")).grid(row=i * 2, column=0, sticky="w", pady=(8, 0))
            e = ttk.Entry(g, width=42, font=("Segoe UI", 11))
            e.grid(row=i * 2, column=1, sticky="w", padx=(12, 0), pady=(8, 0))
            e.insert(0, self.ayar.get(k) or "")
            ttk.Label(g, text=ipucu, foreground=SOLUK, font=("Segoe UI", 8)).grid(row=i * 2 + 1, column=1, sticky="w",
                                                                                padx=(12, 0))
            alanlar[k] = e
        uyari = ttk.Label(p, text="Bu bilgiler sonradan Ayarlar sekmesinden değiştirilebilir.", foreground=SOLUK)
        uyari.pack(pady=(8, 0))
        bos_alan = next((k for k in ("kullanici", "sirket_adi") if not alanlar[k].get().strip()), "sirket_unvani")
        alanlar[bos_alan].focus_set()

        def tamam(_=None):
            if not alanlar["kullanici"].get().strip() or not alanlar["sirket_adi"].get().strip():
                uyari.config(text="Adınız ve şirket adı gerekli.", foreground=KIRMIZI)
                return
            for k, e in alanlar.items():
                self.ayar[k] = e.get().strip()
            ayar_kaydet(self.ayar)
            p.destroy()
        p.bind("<Return>", tamam)
        ttk.Button(p, text="Devam", style="Ana.TButton", command=tamam).pack(pady=14)
        ortala(p, self)

        def kapat_x():
            if not self.ayar.get("kullanici"):
                self.ayar["kullanici"] = alanlar["kullanici"].get().strip() or os.environ.get("USERNAME", "Kullanıcı")
            p.destroy()
        p.protocol("WM_DELETE_WINDOW", kapat_x)
        self.wait_window(p)
        if not self.ayar.get("kullanici"):
            self.ayar["kullanici"] = os.environ.get("USERNAME", "Kullanıcı")

    def _vt_ac(self):
        yol = self.ayar.get("vt_yolu") or VARSAYILAN_AYAR["vt_yolu"]
        try:
            return Veritabani(yol, self.ayar.get("kullanici"))
        except Exception as e:
            messagebox.showwarning("Veritabanı", f"Ortak veritabanı açılamadı:\n{yol}\n\n{e}\n\n"
                                   "Yerel veritabanı kullanılacak. Ayarlar'dan düzeltin.")
            return Veritabani(VARSAYILAN_AYAR["vt_yolu"], self.ayar.get("kullanici"))

    def vt_fabrika(self):
        return Veritabani(self.vt.yol, self.vt.kullanici)

    # ------------------------------------------------------------ yenileme
    def hepsini_yenile(self):
        try:
            self.sekme_gemi.yenile()
            self.sekme_hat.yenile()
            self.sekme_harita.liste_yenile()
            self.sekme_ayar.gunlugu_doldur()
            self.son_gunluk_id = self.vt.son_degisiklik()
            self.durum(f"Kullanıcı: {self.vt.kullanici}   |   Veritabanı: {self.vt.yol}   |   "
                       f"Son yenileme: {dt.datetime.now():%H:%M:%S}")
        except Exception as e:
            self.durum(f"Yenileme hatası: {e}")

    def degisti(self):
        self.hepsini_yenile()
        if self.ais:
            self.ais.listeyi_yenile()

    def _otomatik_yenile(self):
        try:
            if self.vt.son_degisiklik() != self.son_gunluk_id:
                self.degisti()
            else:
                self.sekme_gemi.yenile()
                self.sekme_harita.liste_yenile()
        except Exception as e:
            self.durum(f"Ortak veritabanına ulaşılamadı: {e}")
        self.after(30000, self._otomatik_yenile)

    # ------------------------------------------------------------ AIS
    def ais_baslat(self):
        if self.ais:
            self.ais.durdur()
        self.ais = AISTakip(self.vt_fabrika, self.ayar.get("ais_anahtar"),
                            lambda m: self.kuyruk.put(("durum", m)),
                            lambda tur, veri: self.kuyruk.put((tur, veri)), rehber=self.rehber,
                            onbellek_yolu=os.path.join(VERI_KLASOR, "son_konumlar.json"))
        self.ais.baslat()

    def _kuyruk_oku(self):
        try:
            while True:
                tur, veri = self.kuyruk.get_nowait()
                if tur == "durum":
                    self.ais_etiket.config(text="📡 " + veri)
                elif tur == "mmsi_ogrenildi":
                    g = self.vt.gemi(veri["gemi_id"])
                    self.durum(f"✔ {g['ad'] if g else ''} (IMO {veri['imo']}) AIS'te bulundu, MMSI {veri['mmsi']} kaydedildi")
                    self.hepsini_yenile()
                elif tur == "gecici_bulundu":
                    pass
                elif tur == "bogaz":
                    self.sekme_gemi.bogaz_yenile()
                    try:
                        self._bogaz_takip_kontrol(veri)
                    except Exception as e:
                        self.durum(f"Boğaz takip kontrol hatası: {e}")
                    try:
                        self._trafik_kontrol(veri)
                    except Exception as e:
                        self.durum(f"Boğaz trafiği kontrol hatası: {e}")
                    if self.istatistik and not self.bogaz.hata:
                        try:
                            self.istatistik.gozlem_ekle(veri)
                        except Exception:
                            pass
                elif tur == "goster":
                    self.goster()
                elif tur == "tepsi_yenile":
                    self.bogaz.simdi_yenile()
                    self.sekme_gemi.bogaz_durum("Güncelleniyor…")
                elif tur == "tepsi_kapat":
                    self._kapat()
                    return
                elif tur == "guncellendi":
                    self._guncellendi(*veri)
                elif tur == "guncelleme_sonuc":
                    self.durum(veri[1])
                    try:
                        self.sekme_yonetici.durum_yaz(veri[1])
                    except Exception:
                        pass
                elif tur == "mail_sonuc":
                    ok, metin, geri = veri
                    self.durum(metin)
                    if not ok:
                        self.tepsi.bildir(metin, "E-posta hatası")
                    if geri:
                        geri(ok, metin)
                elif tur == "bogaz_durum":
                    self.sekme_gemi.bogaz_durum(veri)
                elif tur == "imo_bulundu":
                    self._imo_bulundu(veri)
                elif tur == "imo_bulunamadi":
                    f = self.bekleyen_formlar.pop(veri["imo"], None)
                    if f is not None and f.winfo_exists():
                        f.durum_yaz("✖ Bu IMO 8 dakikada AIS'te görülmedi (gemi yayın yapmıyor ya da menzil dışı).\n"
                                    "Ad ve MMSI'yi elle girin.", KIRMIZI)
        except queue.Empty:
            pass
        self.after(800, self._kuyruk_oku)

    # ------------------------------------------------------------ hatirlatma
    def _hatirlatma_dongusu(self):
        try:
            liste = self.vt.yaklasanlar(int(self.ayar.get("hatirlatma_saat") or 24))
            self.sekme_hat.yaklasanlari_goster(liste)
            yeni = [h for h in liste if h["anahtar"] not in self.gosterilen_hatirlatma]
            if yeni:
                for h in yeni:
                    self.gosterilen_hatirlatma.add(h["anahtar"])
                self._hatirlatma_penceresi(yeni)
                if self.state() == "withdrawn":
                    self.tepsi.bildir("\n".join(h["metin"] for h in yeni[:4]), "⏰ Hatırlatma")
        except Exception as e:
            self.durum(f"Hatırlatma kontrol hatası: {e}")
        self.after(60000, self._hatirlatma_dongusu)

    def _hatirlatma_penceresi(self, liste):
        p = tk.Toplevel(self)
        p.title("⏰ Hatırlatma")
        p.configure(bg=KART)
        p.attributes("-topmost", True)
        tk.Label(p, text="⏰  Yaklaşan / Gecikmiş İşler", bg=MERCAN, fg="white",
                 font=("Segoe UI", 12, "bold"), anchor="w", padx=12, pady=8).pack(fill="x")
        for h in liste[:15]:
            renk = KIRMIZI if h["gecikti"] else "#B35C00"
            ek = "GECİKTİ" if h["gecikti"] else "yaklaşıyor"
            tk.Label(p, text=f"{h['zaman']:%d.%m %H:%M}   {h['metin']}   ({ek})",
                     bg=KART, fg=renk, font=("Segoe UI", 10), anchor="w", padx=12).pack(fill="x", pady=2)
        if len(liste) > 15:
            tk.Label(p, text=f"… ve {len(liste) - 15} iş daha", bg=KART, fg=SOLUK).pack(anchor="w", padx=12)
        alt = tk.Frame(p, bg=KART)
        alt.pack(fill="x", pady=10, padx=12)
        ttk.Button(alt, text="Hatırlatmalara Git", style="Ana.TButton",
                   command=lambda: (self.nb.select(self.sekme_hat), p.destroy())).pack(side="left")
        ttk.Button(alt, text="Kapat", command=p.destroy).pack(side="right")
        ortala(p, self)
        if winsound:
            try:
                winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
            except Exception:
                pass

    def bilgi_bul(self, imo=None, mmsi=None):
        """Butun yerel kaynaklardan gemi bilgisi (AIS rehberi + canli AIS + bogaz listeleri).
        {ad, mmsi, imo, cagri, bayrak, tip_adi, boy, en, draft, varis, eta, son, bogaz, kaynak[]} ya da None"""
        b, kaynak = {}, []
        r = None
        if self.rehber:
            r = self.rehber.imo_ile(imo) if imo else (self.rehber.mmsi_ile(mmsi) if mmsi else None)
        if r:
            kaynak.append("AIS")
            b.update({k: r.get(k) for k in ("ad", "mmsi", "imo", "cagri", "boy", "en", "draft", "varis", "eta", "son")
                      if r.get(k) not in (None, "")})
            if r.get("tip") is not None:
                b["tip_adi"] = gemi_tipi_adi(r.get("tip"))
        canli = self.ais.canli_kopya() if self.ais else {}
        m = b.get("mmsi") or mmsi or ((self.ais.imo_mmsi.get(imo) if (self.ais and imo) else None)
                                       or next((k for k, v in canli.items() if imo and v.get("imo") == imo), None))
        if m and m in canli:
            c = canli[m]
            if "AIS" not in kaynak:
                kaynak.append("AIS")
            b.setdefault("mmsi", m)
            if c.get("ad"):
                b.setdefault("ad", c["ad"])
            if c.get("varis"):
                b.setdefault("varis", c["varis"])
            if c.get("tip") is not None:
                b.setdefault("tip_adi", gemi_tipi_adi(c["tip"]))
            b["son"] = "şimdi"
        bz = self.bogaz.bul(imo or b.get("imo") or "", b.get("mmsi") or mmsi or "")
        if bz:
            kod, sira, sat = bz
            kaynak.append("Boğaz listesi")
            for k in ("ad", "mmsi", "imo"):
                if sat.get(k):
                    b.setdefault(k, sat[k])
            if sat.get("boy") and not b.get("boy"):
                b["boy"] = sat["boy"].replace(",", ".")
            if sat.get("tip"):
                b["tip_metin"] = sat["tip"].title()
            b["bogaz"] = (f"{BOGAZLAR[kod]} Boğazı #{sira}: {sat.get('durum') or '-'} {sat.get('plan_zamani', '')}"
                          + (f" ({YONLER[sat['yon']]})" if sat.get("yon") in YONLER else ""))
        if not b:
            return None
        if imo:
            b.setdefault("imo", imo)
        b["bayrak"] = mmsi_bayrak(b.get("mmsi"))
        b["kaynak"] = kaynak
        return b

    def _imo_bulundu(self, veri):
        imo = veri["imo"]
        bilgi = {"ad": veri.get("ad", ""), "mmsi": veri["mmsi"], "bayrak": veri.get("bayrak", ""),
                 "tip_adi": gemi_tipi_adi(veri.get("tip")), "son": "şimdi"}
        tam = self.bilgi_bul(imo=imo, mmsi=veri["mmsi"]) or {}
        for k, v in tam.items():
            if v and not bilgi.get(k):
                bilgi[k] = v
        f = self.bekleyen_formlar.pop(imo, None)
        if f is not None and f.winfo_exists():
            f.bilgileri_doldur(bilgi, kaynak="AIS'te bulundu")
        g = self.vt.gemi_imo_ile(imo)
        if g:
            self.vt.gemi_bilgi_doldur(g["id"], mmsi=bilgi["mmsi"], ad=bilgi["ad"], bayrak=bilgi["bayrak"],
                                      tip=bilgi.get("tip_metin") or bilgi["tip_adi"], cagri=bilgi.get("cagri"),
                                      boy=bilgi.get("boy"), en=bilgi.get("en"), draft=bilgi.get("draft"))
            self.degisti()
        self.durum(f"✔ IMO {imo} bulundu: {bilgi['ad']}  MMSI {bilgi['mmsi']}  {bilgi['bayrak']}")

    def vf_ac(self, imo="", mmsi="", ad="", lat=None, lon=None, zoom=None):
        """VesselFinder haritasini Harita sekmesinin ICINDE goster (ayri pencere yok)."""
        p = {"imo": imo, "mmsi": mmsi, "ad": ad}
        if lat is not None:
            p.update(lat=lat, lon=lon, zoom=zoom)
        self.nb.select(self.sekme_harita)
        self.sekme_harita.vf_goster(p)

    def _hatirlatma_dongusu_tek(self):
        """Hatirlatma listesini hemen guncelle (pencere acmadan)."""
        try:
            self.sekme_hat.yaklasanlari_goster(self.vt.yaklasanlar(int(self.ayar.get("hatirlatma_saat") or 24)))
        except Exception:
            pass

    # ------------------------------------------------------------ kapat / yeniden baslat
    def yeniden_baslat(self):
        import subprocess
        pyw = os.path.join(PROGRAM_KLASOR, "GemiSeferTakibi.pyw")
        if self.tek_kopya:
            self.tek_kopya.birak()          # yeni kopya acilabilsin
        try:
            subprocess.Popen([pythonw_yolu(), pyw, "--yeniden"], cwd=PROGRAM_KLASOR,
                             creationflags=0x00000008 if os.name == "nt" else 0)   # DETACHED_PROCESS
        except Exception as e:
            messagebox.showerror("Yeniden Başlat", f"Program yeniden açılamadı:\n{e}", parent=self)
            return
        self._kapat()

    def _kapat(self):
        try:
            self.sekme_harita.web.kapat()
        except Exception:
            pass
        try:
            self.tepsi.durdur()
        except Exception:
            pass
        if self.tek_kopya:
            self.tek_kopya.birak()
        if self.ais:
            self.ais.durdur()
        self.bogaz.durdur()
        self.destroy()


# ======================================================================  formlar
class Form(tk.Toplevel):
    def __init__(self, app, baslik):
        super().__init__(app)
        self.app = app
        self.title(baslik)
        self.configure(bg=ZEMIN)
        self.transient(app)
        self.alanlar = {}
        tk.Label(self, text=baslik, bg=TEAL, fg="white", font=("Segoe UI", 12, "bold"),
                 anchor="w", padx=14, pady=8).pack(fill="x")
        self.govde = ttk.Frame(self, padding=14)
        self.govde.pack(fill="both", expand=True)
        self.satir = 0

    def alan(self, anahtar, etiket, tur="entry", secenekler=None, ipucu="", genislik=34):
        ttk.Label(self.govde, text=etiket).grid(row=self.satir, column=0, sticky="w", pady=4, padx=(0, 10))
        if tur == "combo":
            w = ttk.Combobox(self.govde, values=secenekler or [], width=genislik - 2)
        elif tur == "readonly":
            w = ttk.Combobox(self.govde, values=secenekler or [], width=genislik - 2, state="readonly")
        elif tur == "text":
            w = tk.Text(self.govde, width=genislik, height=4, font=("Segoe UI", 10), relief="solid", bd=1)
        else:
            w = ttk.Entry(self.govde, width=genislik)
        w.grid(row=self.satir, column=1, sticky="w", pady=4)
        if ipucu:
            ttk.Label(self.govde, text=ipucu, foreground=SOLUK, font=("Segoe UI", 8)).grid(
                row=self.satir, column=2, sticky="w", padx=6)
        self.alanlar[anahtar] = w
        self.satir += 1
        return w

    def deger(self, k):
        w = self.alanlar[k]
        if isinstance(w, tk.Text):
            return w.get("1.0", "end").strip()
        return w.get().strip()

    def yaz(self, k, v):
        w = self.alanlar[k]
        v = bos(v)
        if isinstance(w, tk.Text):
            w.delete("1.0", "end")
            w.insert("1.0", v)
        elif str(w.cget("state")) == "readonly":
            w.set(v)
        else:
            w.delete(0, "end")
            w.insert(0, v)

    def dugmeler(self, kaydet):
        alt = ttk.Frame(self, padding=(14, 0, 14, 14))
        alt.pack(fill="x")
        ttk.Button(alt, text="💾 Kaydet", style="Vurgu.TButton", command=kaydet).pack(side="right")
        ttk.Button(alt, text="Vazgeç", command=self.destroy).pack(side="right", padx=8)
        self.bind("<Escape>", lambda e: self.destroy())
        self.bind("<Return>", lambda e: kaydet() if not isinstance(e.widget, tk.Text) else None)
        ortala(self, self.app)
        self.grab_set()


class GemiFormu(Form):
    """IMO yazinca butun kaynaklardan (AIS, bogaz listeleri, Kiyi Emniyeti gecis gecmisi) bilgi toplar."""
    TIPLER = ["General Cargo", "Bulk Carrier", "Container", "Tanker", "Chemical Tanker", "Oil Products Tanker",
              "LPG/LNG", "Ro-Ro", "Vehicle Carrier", "Passenger", "Tug", "Kargo", "Diğer"]

    def __init__(self, app, gid, onveri=None, sonra=None):
        super().__init__(app, "Gemi Düzenle" if gid else "Yeni Gemi")
        self.gid = gid
        self.sonra = sonra
        self._gecmis = None
        self._gecmis_imo = None
        kap = self.govde
        sol = ttk.Frame(kap)
        sol.grid(row=0, column=0, sticky="nw")
        sag = tk.Frame(kap, bg=KART, highlightthickness=1, highlightbackground="#C9D6D8")
        sag.grid(row=0, column=1, sticky="nsew", padx=(16, 0))
        kap.columnconfigure(1, weight=1)
        self.govde = sol                                          # alan() bu cerceveye yazar

        self.alan("imo", "IMO No *", ipucu="7 hane", genislik=26)
        self.durum_lbl = tk.Label(sol, text="IMO numarasını yazın; bilgiler kendiliğinden gelir.", bg=ZEMIN,
                                  fg=SOLUK, font=("Segoe UI", 9), justify="left", anchor="w", wraplength=330)
        self.durum_lbl.grid(row=self.satir, column=1, columnspan=2, sticky="w", pady=(0, 6))
        self.satir += 1
        self.alan("ad", "Gemi Adı", genislik=26)
        self.alan("mmsi", "MMSI", genislik=26)
        self.alan("cagri", "Çağrı İşareti", genislik=26)
        self.alan("bayrak", "Bayrak", genislik=26)
        self.alan("tip", "Gemi Tipi", "combo", self.TIPLER, genislik=26)
        self.alan("boy", "Boy (m)", genislik=26)
        self.alan("en", "En (m)", genislik=26)
        self.alan("draft", "Su Çekimi (m)", genislik=26)
        self.alan("dwt", "DWT", genislik=26, ipucu="elle")
        self.alan("grt", "GRT", genislik=26, ipucu="elle")
        self.alan("yapim", "Yapım Yılı", genislik=26, ipucu="elle")
        self.alan("notlar", "Notlar", "text", genislik=26)
        self.alanlar["notlar"].configure(height=3)

        # ---- sag: bilgi karti
        tk.Label(sag, text="📋  Gemi Bilgi Kartı", bg=TEAL, fg="white", font=("Segoe UI", 10, "bold"),
                 anchor="w", padx=10, pady=5).pack(fill="x")
        self.kart = tk.Label(sag, text="—", bg=KART, fg=YAZI, font=("Segoe UI", 9), justify="left", anchor="nw",
                             padx=10, pady=8, wraplength=430)
        self.kart.pack(fill="x")
        tk.Label(sag, text="Son boğaz geçişleri (Kıyı Emniyeti)", bg=KART, fg=TEAL_KOYU,
                 font=("Segoe UI", 9, "bold"), anchor="w", padx=10).pack(fill="x")
        c2, self.gecmis_tv = tablo_olustur(sag, [("zaman", "Tarih", 125), ("bogaz", "Boğaz", 85),
                                                ("yon", "Yön", 115), ("rota", "Nereden → Nereye", 230)], 7)
        c2.pack(fill="both", expand=True, padx=8, pady=(2, 6))
        self.gecmis_lbl = tk.Label(sag, text="", bg=KART, fg=SOLUK, font=("Segoe UI", 8), anchor="w", padx=10)
        self.gecmis_lbl.pack(fill="x")
        ttk.Button(sag, text="🗺 Haritada Göster", command=self._haritada).pack(anchor="e", padx=8, pady=8)

        if gid:
            g = app.vt.gemi(gid)
            for k in self.alanlar:
                self.yaz(k, g.get(k))
        for k, v in (onveri or {}).items():
            if k in self.alanlar and v:
                self.yaz(k, v)
        self.govde = kap
        self.dugmeler(self.kaydet)
        self._son_sorgu = None
        self.alanlar["imo"].bind("<KeyRelease>", lambda e: self._otomatik())
        self.alanlar["imo"].bind("<FocusOut>", lambda e: self._otomatik())
        self.alanlar["mmsi"].bind("<KeyRelease>", lambda e: self._otomatik())
        self.alanlar["imo"].focus_set()
        if self.deger("imo") or self.deger("mmsi"):
            self.after(150, self._otomatik)

    # ------------------------------------------------------------ yardimcilar
    def durum_yaz(self, metin, renk=SOLUK):
        try:
            self.durum_lbl.config(text=metin, fg=renk)
        except tk.TclError:
            pass

    def _kart_yaz(self, b):
        satirlar = []
        if b.get("ad"):
            satirlar.append(f"🚢  {b['ad']}")
        kim = "   ".join(x for x in (f"IMO {b['imo']}" if b.get("imo") else "", f"MMSI {b['mmsi']}" if b.get("mmsi") else "",
                                     f"Çağrı {b['cagri']}" if b.get("cagri") else "") if x)
        if kim:
            satirlar.append(kim)
        if b.get("bayrak"):
            satirlar.append(f"Bayrak: {b['bayrak']}")
        tip = b.get("tip_metin") or b.get("tip_adi")
        if tip:
            satirlar.append(f"Tip: {tip}")
        def m(k):
            v = b.get(k)
            return f"{float(str(v).replace(',', '.')):g}" if _sayi_mi(v) else v
        olcu = "   ".join(x for x in (f"Boy {m('boy')} m" if b.get("boy") else "", f"En {m('en')} m" if b.get("en") else "",
                                      f"Su çekimi {m('draft')} m" if b.get("draft") else "") if x)
        if olcu:
            satirlar.append(olcu)
        if b.get("varis") or b.get("eta"):
            satirlar.append(f"AIS varış: {b.get('varis') or '-'}" + (f"   ETA {b['eta']}" if b.get("eta") else ""))
        if b.get("bogaz"):
            satirlar.append(f"⚓ {b['bogaz']}")
        if b.get("son"):
            satirlar.append(f"AIS son görülme: {b['son']}")
        if b.get("kaynak"):
            satirlar.append(f"Kaynak: {', '.join(b['kaynak'])}")
        self.kart.config(text="\n".join(satirlar) or "—")

    def bilgileri_doldur(self, b, kaynak=None):
        adlar = {"ad": "ad", "mmsi": "MMSI", "cagri": "çağrı işareti", "bayrak": "bayrak", "tip": "tip",
                 "boy": "boy", "en": "en", "draft": "su çekimi"}
        degerler = {"ad": b.get("ad"), "mmsi": b.get("mmsi"), "cagri": b.get("cagri"), "bayrak": b.get("bayrak"),
                    "tip": b.get("tip_metin") or b.get("tip_adi"), "boy": b.get("boy"), "en": b.get("en"),
                    "draft": b.get("draft")}
        dolan = []
        for alan, deger in degerler.items():
            if deger not in (None, "") and not self.deger(alan):
                self.yaz(alan, (f"{float(str(deger).replace(',', '.')):g}" if alan in ("boy", "en", "draft") and _sayi_mi(deger) else deger))
                dolan.append(adlar[alan])
        self._kart_yaz(b)
        kaynaklar = kaynak or ", ".join(b.get("kaynak") or [])
        if dolan:
            self.durum_yaz(f"✔ Dolduruldu: {', '.join(dolan)}  ({kaynaklar})", "#2E7D32")
        else:
            self.durum_yaz(f"✔ Bilgiler güncel  ({kaynaklar})", "#2E7D32")

    # ------------------------------------------------------------ otomatik doldurma
    def _otomatik(self):
        imo = self.deger("imo").upper().replace("IMO", "").strip()
        mmsi = self.deger("mmsi")
        if len(imo) == 7 and imo.isdigit():
            if imo == self._son_sorgu:
                return
            self._son_sorgu = imo
            if not imo_gecerli(imo):
                self.durum_yaz("⚠ Bu IMO numarası hatalı görünüyor (son hane tutmuyor). Kontrol edin.", KIRMIZI)
                return
            self._gecmis_baslat(imo)
            b = self.app.bilgi_bul(imo=imo, mmsi=mmsi or None)
            if b:
                self.bilgileri_doldur(b)
            elif self.deger("ad") and self.deger("mmsi"):
                self._kart_yaz({"ad": self.deger("ad"), "imo": imo, "mmsi": self.deger("mmsi"),
                                "bayrak": self.deger("bayrak") or mmsi_bayrak(self.deger("mmsi"))})
                self.durum_yaz("✔ Ad ve MMSI dolu. Diğer bilgiler gemi AIS'te görülünce eklenir.", "#2E7D32")
            if not self.deger("mmsi") or not self.deger("ad"):
                if self.app.ais and self.app.ais.anahtar and self.app.ais.thread:
                    self.app.ais.imo_ara(imo)
                    self.app.bekleyen_formlar[imo] = self
                    self.durum_yaz("⏳ Ad/MMSI yerel kayıtlarda yok — AIS'te dünya genelinde aranıyor (1–8 dk).\n"
                                   "Hemen kaydedebilirsiniz; bulununca bilgiler kayda kendiliğinden işlenir.", "#B35C00")
                elif not b:
                    self.durum_yaz("Bu IMO yerel kayıtlarda yok. Ad ve MMSI'yi elle girin.", "#B35C00")
        elif len(mmsi) == 9 and mmsi.isdigit() and mmsi != self._son_sorgu:
            self._son_sorgu = mmsi
            b = self.app.bilgi_bul(mmsi=mmsi)
            if b:
                if b.get("imo") and not self.deger("imo"):
                    self.yaz("imo", b["imo"])
                    self._gecmis_baslat(b["imo"])
                self.bilgileri_doldur(b)
            elif not self.deger("bayrak") and mmsi_bayrak(mmsi):
                self.yaz("bayrak", mmsi_bayrak(mmsi))

    # ------------------------------------------------------------ Kiyi Emniyeti gecis gecmisi (arka planda)
    def _gecmis_baslat(self, imo):
        if self._gecmis_imo == imo:
            return
        self._gecmis_imo = imo
        self._gecmis = None
        self.gecmis_lbl.config(text="Kıyı Emniyeti'nden geçiş geçmişi alınıyor…")

        def is_():
            try:
                self._gecmis = ("ok", imo, gecmis_getir(imo))
            except Exception as e:
                self._gecmis = ("hata", imo, str(e)[:80])
        threading.Thread(target=is_, daemon=True).start()
        self.after(300, self._gecmis_bekle)

    def _gecmis_bekle(self):
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        if self._gecmis is None:
            self.after(300, self._gecmis_bekle)
            return
        durum, imo, veri = self._gecmis
        if imo != self._gecmis_imo:
            return
        self.gecmis_tv.delete(*self.gecmis_tv.get_children())
        if durum == "hata":
            self.gecmis_lbl.config(text=f"Geçiş geçmişi alınamadı: {veri}")
            return
        for i, g in enumerate(veri[:30]):
            self.gecmis_tv.insert("", "end", iid=str(i), values=(g["zaman"] or "—", g["bogaz"], g["yon"],
                                                                 f"{g['kalkis']} → {g['varis']}"))
        if veri:
            son = veri[0]
            self.gecmis_lbl.config(text=f"{len(veri)} geçiş kaydı • son: {son['zaman'] or '-'} {son['bogaz']} "
                                        f"({son['kalkis']} → {son['varis']})")
        else:
            self.gecmis_lbl.config(text="Bu IMO için boğaz geçiş kaydı yok.")

    def _haritada(self):
        imo, mmsi = self.deger("imo"), self.deger("mmsi")
        if not (imo or mmsi):
            return
        ad = self.deger("ad")
        self.app.vf_ac(imo=imo, mmsi=mmsi, ad=ad)

    def kaydet(self):
        veri = {k: self.deger(k) for k in self.alanlar}
        try:
            gid = self.app.vt.gemi_kaydet(veri, self.gid)
        except GemiZatenVar as e:
            g = e.gemi
            if not messagebox.askyesno(
                    "Gemi zaten kayıtlı",
                    f"{g['ad']} (IMO {g.get('imo') or '-'}) listede zaten var.\n\n"
                    "Yeni kayıt açmak yerine yazdığınız bilgileri\nMEVCUT gemiye işleyeyim mi?",
                    parent=self):
                return
            for k, v in g.items():
                if k in veri and not veri[k]:
                    veri[k] = v or ""
            try:
                gid = self.app.vt.gemi_kaydet(veri, g["id"])
            except ValueError as e2:
                messagebox.showwarning("Eksik / hatalı", str(e2), parent=self)
                return
            if self.gid and self.gid != g["id"]:
                self.app.vt.tekrar_eden_gemileri_birlestir()
        except ValueError as e:
            messagebox.showwarning("Eksik / hatalı", str(e), parent=self)
            return
        imo = self.app.vt.gemi(gid).get("imo") if gid else None
        if imo and imo in self.app.bekleyen_formlar:
            self.app.bekleyen_formlar.pop(imo, None)       # arama surer; bulununca kayda islenir
        self.destroy()
        self.app.degisti()
        if self.sonra:
            self.sonra(gid)


def _sayi_mi(x):
    try:
        float(str(x).replace(",", "."))
        return True
    except (ValueError, TypeError):
        return False


class GemiSecici:
    """Formlarda gemi secim kutusu."""
    def __init__(self, form, anahtar="gemi", etiket="Gemi *"):
        self.form = form
        self.liste = form.app.vt.gemiler()
        self.cb = form.alan(anahtar, etiket, "readonly", [g["ad"] + (f"  (IMO {g['imo']})" if g.get("imo") else "")
                                                          for g in self.liste])

    def sec(self, gid):
        for i, g in enumerate(self.liste):
            if g["id"] == gid:
                self.cb.current(i)

    def secili(self):
        i = self.cb.current()
        return self.liste[i]["id"] if i >= 0 else None


class HatirlatmaFormu(Form):
    def __init__(self, app, hid=None, gemi_id=None):
        super().__init__(app, "Hatırlatma Düzenle" if hid else "Yeni Hatırlatma")
        self.hid = hid
        self.gemi = GemiSecici(self)
        self.alan("ad", "İş / Belge *", "combo", BELGE_ADLARI)
        self.alan("son_tarih", "Son Tarih", ipucu="GG.AA.YYYY SS:DD — uyarı bu saate göre")
        self.alan("dosya", "Bağlı Dosya")
        ttk.Button(self.govde, text="Gözat…", command=self._gozat).grid(row=self.satir - 1, column=2, sticky="w", padx=6)
        self.alan("notlar", "Notlar", "text")
        self.tamam = tk.BooleanVar(value=False)
        ttk.Checkbutton(self.govde, text="Tamamlandı", variable=self.tamam).grid(row=self.satir, column=1, sticky="w")
        if hid:
            h = app.vt.hatirlatma(hid)
            for k in ("ad", "son_tarih", "dosya", "notlar"):
                self.yaz(k, h.get(k))
            self.tamam.set(bool(h["tamam"]))
            self.gemi.sec(h["gemi_id"])
        elif gemi_id:
            self.gemi.sec(gemi_id)
        self.dugmeler(self.kaydet)

    def _gozat(self):
        yol = filedialog.askopenfilename(parent=self)
        if yol:
            self.yaz("dosya", yol)

    def kaydet(self):
        veri = {k: self.deger(k) for k in ("ad", "son_tarih", "dosya", "notlar")}
        veri["tamam"] = self.tamam.get()
        veri["gemi_id"] = self.gemi.secili()
        try:
            self.app.vt.hatirlatma_kaydet(veri, self.hid)
        except ValueError as e:
            messagebox.showwarning("Eksik / hatalı", str(e), parent=self)
            return
        self.destroy()
        self.app.degisti()


class StandartBelgeFormu(Form):
    def __init__(self, app, gemi_id=None):
        super().__init__(app, "Standart Belgeleri Ekle")
        self.gemi = GemiSecici(self)
        self.alan("eta", "ETA (tahmini varış)", ipucu="GG.AA.YYYY SS:DD")
        self.alan("etd", "ETD (tahmini kalkış)", ipucu="boş bırakılabilir")
        ttk.Label(self.govde, text="NOR, SOF, LTP geliş/ayrılış bildirimi, gümrük, mürettebat listesi vb.\n"
                                   "8 iş eklenir; son tarihleri ETA/ETD'ye göre hesaplanır.",
                  foreground=SOLUK).grid(row=self.satir, column=0, columnspan=3, sticky="w", pady=(8, 0))
        if gemi_id:
            self.gemi.sec(gemi_id)
        self.dugmeler(self.kaydet)

    def kaydet(self):
        gid = self.gemi.secili()
        if not gid:
            messagebox.showwarning("Eksik", "Gemi seçin.", parent=self)
            return
        try:
            n = self.app.vt.standart_belgeleri_ekle(gid, self.deger("eta"), self.deger("etd"))
        except ValueError as e:
            messagebox.showwarning("Hatalı tarih", str(e), parent=self)
            return
        self.destroy()
        self.app.degisti()
        messagebox.showinfo("Standart belgeler", f"{n} iş eklendi." if n else "Hepsi zaten listede.", parent=self.app)


# ======================================================================  HARITA
class HaritaSekmesi(ttk.Frame):
    """Harita = VesselFinder haritasi (tam kapsamli), programin icine gomulu."""
    BOLGELER = {"Marmara": (40.75, 28.6, 8), "İstanbul Boğazı": (41.10, 29.05, 11),
                "Çanakkale Boğazı": (40.20, 26.45, 10), "İzmit Körfezi": (40.74, 29.65, 11),
                "Ege": (38.6, 25.8, 7)}

    def __init__(self, ebeveyn, app):
        super().__init__(ebeveyn)
        self.app = app
        self.gemilerim = []
        self._ilk = True

        ust = ttk.Frame(self)
        ust.pack(fill="x", padx=4, pady=(8, 6))
        ttk.Label(ust, text="🎯 IMO / MMSI / Gemi adı:", font=("Segoe UI", 10, "bold")).pack(side="left")
        self.ara = ttk.Entry(ust, width=24, font=("Segoe UI", 11))
        self.ara.pack(side="left", padx=6)
        self.ara.bind("<Return>", lambda e: self.bul())
        ttk.Button(ust, text="Bul", style="Vurgu.TButton", command=self.bul).pack(side="left")
        ttk.Label(ust, text="     Bölge:").pack(side="left")
        for ad in self.BOLGELER:
            ttk.Button(ust, text=ad, command=lambda a=ad: self.bolge(a)).pack(side="left", padx=2)

        govde = ttk.Frame(self)
        govde.pack(fill="both", expand=True)
        sol = ttk.Frame(govde, width=270)
        sol.pack(side="left", fill="y", padx=(4, 6), pady=(0, 8))
        sol.pack_propagate(False)
        ttk.Label(sol, text="Gemilerim", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        cerceve, self.tv = tablo_olustur(sol, [("gemi", "Gemi", 150), ("imo", "IMO", 80)], 12)
        cerceve.pack(fill="both", expand=True, pady=4)
        self.tv.bind("<<TreeviewSelect>>", self._listeden_sec)
        self.tv.bind("<Double-1>", lambda e: GemiFormu(self.app, secili_id(self.tv)) if secili_id(self.tv) else None)
        ttk.Button(sol, text="＋ Gemi Ekle", style="Vurgu.TButton",
                   command=lambda: GemiFormu(self.app, None)).pack(fill="x", pady=(2, 4))
        ttk.Label(sol, text="Gemiye tıklayın: harita o gemiyi\nson 24 saatlik rotasıyla gösterir.",
                  foreground=SOLUK, font=("Segoe UI", 8), justify="left").pack(anchor="w")

        sag = tk.Frame(govde, bg=ZEMIN)
        sag.pack(side="left", fill="both", expand=True, pady=(0, 8), padx=(0, 4))
        bas = tk.Frame(sag, bg=TEAL_KOYU)
        bas.pack(fill="x")
        self.baslik = tk.Label(bas, text="Marmara", bg=TEAL_KOYU, fg="white", font=("Segoe UI", 10, "bold"),
                               anchor="w", padx=10, pady=5)
        self.baslik.pack(side="left", fill="x", expand=True)
        self.alan = tk.Frame(sag, bg=ZEMIN)
        self.alan.pack(fill="both", expand=True)
        self.web = GomuluWeb(self.alan, pythonw_yolu(), os.path.join(PROGRAM_KLASOR, "vf_harita.py"))

    # ------------------------------------------------------------ gorunum
    def gorundu(self):
        """Sekme ilk kez acildiginda Marmara bolgesini yukle."""
        if self._ilk:
            self._ilk = False
            self.bolge("Marmara")

    def bolge(self, ad):
        lat, lon, zoom = self.BOLGELER[ad]
        self._ilk = False
        self.baslik.config(text=ad)
        self.web.ac({"lat": lat, "lon": lon, "zoom": zoom, "ad": ad})

    def vf_goster(self, p):
        self._ilk = False
        kim = p.get("ad") or (f"IMO {p['imo']}" if p.get("imo") else (f"MMSI {p['mmsi']}" if p.get("mmsi") else ""))
        if p.get("lat") is not None and not (p.get("imo") or p.get("mmsi")):
            self.baslik.config(text=kim)
        else:
            kimlik = "  ".join(x for x in (f"IMO {p['imo']}" if p.get("imo") else "",
                                           f"MMSI {p['mmsi']}" if p.get("mmsi") else "") if x)
            self.baslik.config(text=f"{kim}   {kimlik}")
        self.update_idletasks()
        self.web.ac(p)

    # ------------------------------------------------------------ gemilerim listesi
    def liste_yenile(self):
        self.gemilerim = self.app.vt.gemiler()
        secim = self.tv.selection()
        self.tv.delete(*self.tv.get_children())
        for g in self.gemilerim:
            self.tv.insert("", "end", iid=str(g["id"]), values=(g["ad"], bos(g.get("imo"))))
        if secim and self.tv.exists(secim[0]):
            self.tv.selection_set(secim[0])

    def _listeden_sec(self, _):
        gid = secili_id(self.tv)
        g = next((x for x in self.gemilerim if x["id"] == gid), None) if gid else None
        if g:
            self.git_veya_sor(g.get("mmsi") or "", g.get("imo") or "", g["ad"])

    # ------------------------------------------------------------ arama
    def git_veya_sor(self, mmsi="", imo="", ad="", ek=""):
        """Gemiyi VesselFinder haritasinda goster (IMO varsa IMO ile, yoksa MMSI ile)."""
        if not (mmsi or imo):
            messagebox.showinfo("Bulunamadı", f"'{ad}' için IMO ya da MMSI bilinmiyor.", parent=self)
            return
        self.app.nb.select(self)
        self.vf_goster({"imo": imo, "mmsi": mmsi, "ad": ad})
        if ek:
            self.app.durum(f"🌐 {ad}: {ek}")

    def bul(self):
        q = self.ara.get().strip()
        if not q:
            return
        if q.upper().startswith("IMO"):
            q = q[3:].strip()
        if q.isdigit() and len(q) == 7:
            g = next((x for x in self.app.vt.gemiler() if x.get("imo") == q), None)
            self.git_veya_sor((g or {}).get("mmsi") or "", q, (g or {}).get("ad") or f"IMO {q}")
            return
        if q.isdigit() and len(q) == 9:
            g = next((x for x in self.app.vt.gemiler() if x.get("mmsi") == q), None)
            self.git_veya_sor(q, (g or {}).get("imo") or "", (g or {}).get("ad") or f"MMSI {q}")
            return
        # ad ile: once gemilerim, sonra bogaz listeleri, sonra yerel rehber / canli AIS
        katla = lambda x: tr_lower(x or "").replace("ı", "i")
        aranan = katla(q)
        for g in self.app.vt.gemiler():
            if aranan in katla(g["ad"]) and (g.get("imo") or g.get("mmsi")):
                return self.git_veya_sor(g.get("mmsi") or "", g.get("imo") or "", g["ad"])
        for kod in ("I", "C"):
            for s in self.app.bogaz.veri.get(kod) or []:
                if aranan in katla(s["ad"]) and (s.get("imo") or s.get("mmsi")):
                    return self.git_veya_sor(s.get("mmsi", ""), s.get("imo", ""), s["ad"])
        canli = self.app.ais.canli_kopya() if self.app.ais else {}
        for m, v in canli.items():
            if aranan in katla(v.get("ad")):
                return self.git_veya_sor(m, v.get("imo", ""), v.get("ad", ""))
        messagebox.showinfo("Bulunamadı", f"'{q}' adlı gemi listelerde yok.\nIMO (7 hane) ya da MMSI (9 hane) ile "
                            "aratın; VesselFinder her gemiyi bulur.", parent=self)


# ======================================================================  GEMILER
class GemiSekmesi(ttk.Frame):
    """Ustte gemilerim, altta Kiyi Emniyeti'nin Istanbul/Canakkale Bogazi gecis sirasi (5 dk'da bir guncel)."""
    BOGAZ_SUTUN = [("sira", "#", 40), ("durum", "Durum", 105), ("plan", "Planlama", 110), ("yon", "Yön", 105),
                   ("ad", "Gemi Adı", 175), ("boy", "Boy", 60), ("tip", "Gemi Tipi", 140), ("kk", "Kılavuz", 60),
                   ("rom", "Römorkör", 70), ("sp2", "SP2", 75), ("sp1", "SP1", 75), ("imo", "IMO", 75), ("mmsi", "MMSI", 90)]

    def __init__(self, ebeveyn, app):
        super().__init__(ebeveyn)
        self.app = app
        bolme = ttk.PanedWindow(self, orient="vertical")
        bolme.pack(fill="both", expand=True)

        # ---------------- gemilerim
        ust_cerceve = ttk.Frame(bolme)
        ust = ttk.Frame(ust_cerceve)
        ust.pack(fill="x", padx=4, pady=(8, 4))
        tk.Label(ust, text="🚢  Gemilerim", bg=ZEMIN, fg=TEAL_KOYU, font=("Segoe UI", 12, "bold")).pack(side="left", padx=(0, 12))
        ttk.Button(ust, text="＋ Yeni Gemi", style="Vurgu.TButton",
                   command=lambda: GemiFormu(self.app, None)).pack(side="left")
        ttk.Button(ust, text="✎ Düzenle", command=self.duzenle).pack(side="left", padx=4)
        ttk.Button(ust, text="🗺 Haritada Göster", command=self.haritada).pack(side="left", padx=4)
        ttk.Button(ust, text="🗑 Sil", command=self.sil).pack(side="left", padx=4)
        ttk.Button(ust, text="📄 Durum Raporu", style="Ana.TButton",
                   command=lambda: RaporPenceresi(self.app, self._secili_anahtarlar())).pack(side="left", padx=(16, 4))
        cerceve, self.tv = tablo_olustur(ust_cerceve, [
            ("ad", "Gemi Adı", 170), ("imo", "IMO", 75), ("mmsi", "MMSI", 90), ("bayrak", "Bayrak", 95),
            ("tip", "Tip", 95), ("durum", "AIS Durumu", 120), ("hiz", "Hız", 60), ("son", "Son Konum", 95),
            ("bogaz", "Boğaz Sırası", 260), ("acik", "Açık İş", 60)], 6)
        cerceve.pack(fill="both", expand=True, padx=4, pady=(0, 4))
        self.tv.tag_configure("mmsiyok", foreground=KIRMIZI)
        self.tv.bind("<Double-1>", lambda e: self.duzenle())
        bolme.add(ust_cerceve, weight=1)

        # ---------------- bogaz sirasi
        alt_cerceve = ttk.Frame(bolme)
        bas = ttk.Frame(alt_cerceve)
        bas.pack(fill="x", padx=4, pady=(8, 4))
        tk.Label(bas, text="⚓  Boğaz Geçiş Sırası", bg=ZEMIN, fg=TEAL_KOYU, font=("Segoe UI", 12, "bold")).pack(side="left")
        self.bogaz_lbl = ttk.Label(bas, foreground=SOLUK)
        self.bogaz_lbl.pack(side="right")
        ttk.Button(bas, text="⟳ Şimdi Yenile", command=self._simdi).pack(side="right", padx=6)
        ttk.Button(bas, text="📊 İstatistik", command=lambda: IstatistikPenceresi(self.app)).pack(side="right")
        # ---- ortada: bogaz trafigi (acik / askida), Kiyi Emniyeti "Turk Bogazlari Gemi Trafik Yonu"
        self.trafik_cerceve = tk.Frame(bas, bg=ZEMIN, cursor="hand2")
        self.trafik_cerceve.pack(side="left", expand=True)
        self.trafik_hucre = {}
        for r, kod in enumerate(("I", "C")):
            tk.Label(self.trafik_cerceve, text=BOGAZLAR[kod], bg=ZEMIN, fg=TEAL_KOYU, font=("Segoe UI", 9, "bold"),
                     anchor="w").grid(row=r, column=0, sticky="w", padx=(0, 6))
            for c, yon in enumerate(("KG", "GK")):
                rozet = tk.Label(self.trafik_cerceve, text=" … ", bg="#9AA5A8", fg="white",
                                 font=("Segoe UI", 8, "bold"), padx=4)
                rozet.grid(row=r, column=1 + c * 2, sticky="w", pady=1)
                ek = tk.Label(self.trafik_cerceve, text="", bg=ZEMIN, fg=SOLUK, font=("Segoe UI", 8), anchor="w",
                              width=24)
                ek.grid(row=r, column=2 + c * 2, sticky="w", padx=(4, 10))
                self.trafik_hucre[(kod, yon)] = (rozet, ek)
        for w in [self.trafik_cerceve] + list(self.trafik_cerceve.winfo_children()):
            w.bind("<Button-1>", lambda e: self.trafik_penceresi())

        filt = ttk.Frame(alt_cerceve)
        filt.pack(fill="x", padx=4, pady=(0, 4))
        ttk.Label(filt, text="Yön:").pack(side="left")
        self.f_yon = ttk.Combobox(filt, state="readonly", width=13, values=["Hepsi"] + list(YONLER.values()))
        self.f_yon.set("Hepsi")
        self.f_yon.pack(side="left", padx=(4, 12))
        ttk.Label(filt, text="Durum:").pack(side="left")
        self.f_durum = ttk.Combobox(filt, state="readonly", width=13,
                                    values=["Hepsi", "BOĞAZDA", "PLAN. GEÇİŞ", "GEÇİŞE HAZIR", "SP1", "DİĞER"])
        self.f_durum.set("Hepsi")
        self.f_durum.pack(side="left", padx=(4, 12))
        ttk.Label(filt, text="🔍 Ara:").pack(side="left")
        self.f_ara = tk.StringVar()
        ttk.Entry(filt, textvariable=self.f_ara, width=16).pack(side="left", padx=(4, 12))
        self.f_bizim = tk.BooleanVar(value=False)
        ttk.Checkbutton(filt, text="Gemilerim", variable=self.f_bizim, command=self.bogaz_yenile).pack(side="left")
        for w in (self.f_yon, self.f_durum):
            w.bind("<<ComboboxSelected>>", lambda e: self.bogaz_yenile())
        self.f_ara.trace_add("write", lambda *_: self.bogaz_yenile())
        self.f_takip = tk.BooleanVar(value=False)
        ttk.Checkbutton(filt, text="Takiptekiler", variable=self.f_takip,
                        command=self.bogaz_yenile).pack(side="left", padx=(10, 0))
        ttk.Button(filt, text="⭐ Gemilerime Ekle", style="Ana.TButton", command=self._bogazdan_ekle).pack(side="right")
        ttk.Button(filt, text="🗺 Haritada Göster", command=self._bogazdan_harita).pack(side="right", padx=6)
        ttk.Button(filt, text="🔔 Takip / Mail", style="Vurgu.TButton",
                   command=self._takip_degistir).pack(side="right")

        self.bnb = ttk.Notebook(alt_cerceve)
        self.bnb.pack(fill="both", expand=True, padx=4, pady=(0, 6))
        self.bogaz_tv = {}
        for kod in ("I", "C"):
            fr = ttk.Frame(self.bnb)
            c2, tv = tablo_olustur(fr, self.BOGAZ_SUTUN)
            c2.pack(fill="both", expand=True)
            tv.tag_configure("bizim", background="#FFE1D6", foreground="#8A2B12")
            tv.tag_configure("bogazda", foreground="#0A5C63")
            tv.tag_configure("takip", background="#FFF4C2", foreground="#5C4400")
            tv.bind("<Double-1>", lambda e, k=kod: self._bogazdan_harita(k))
            tv.bind("<Button-3>", lambda e, k=kod: self._sag_tik(e, k))
            self.bnb.add(fr, text=f"  {BOGAZLAR[kod]} Boğazı  ")
            self.bogaz_tv[kod] = tv
        bolme.add(alt_cerceve, weight=3)
        self.after(200, self.bogaz_yenile)
        self.after(60000, self._trafik_dongu)

    # ---------------- gemilerim
    def _bogaz_bilgisi(self):
        """imo/mmsi -> 'İstanbul: PLAN. GEÇİŞ 18.10.26 03:30 (Kuzey → Güney)'"""
        v = self.app.bogaz.veri
        harita = {}
        for kod in ("I", "C"):
            for i, s in enumerate(v.get(kod) or [], 1):
                metin = f"{BOGAZLAR[kod]} #{i}: {s['durum'] or '-'} {s['plan_zamani']}".strip()
                if s.get("yon"):
                    metin += f" ({YONLER.get(s['yon'], '')})"
                for anahtar in (s.get("imo"), s.get("mmsi")):
                    if anahtar:
                        harita[anahtar] = metin
        return harita

    def yenile(self):
        secim = self.tv.selection()
        self.tv.delete(*self.tv.get_children())
        bogaz = self._bogaz_bilgisi()
        for g in self.app.vt.gemiler():
            if not g.get("mmsi"):
                durum = "MMSI aranıyor (IMO ile)" if g.get("imo") else "MMSI yok"
            elif g.get("lat") is None:
                durum = "konum bekleniyor"
            else:
                durum = NAV_DURUM.get(g.get("nav_durum"), "konum var")
            b = bogaz.get(g.get("imo") or "-") or bogaz.get(g.get("mmsi") or "-") or ""
            self.tv.insert("", "end", iid=str(g["id"]), tags=("mmsiyok",) if not g.get("mmsi") else (), values=(
                g["ad"], bos(g["imo"]), bos(g["mmsi"]), bos(g["bayrak"]), bos(g["tip"]), durum,
                f"{g['sog']:.1f} kn" if g.get("sog") is not None else "", konum_zamani(g),
                b, g.get("acik") or ""))
        if secim and self.tv.exists(secim[0]):
            self.tv.selection_set(secim[0])

    def _secili(self):
        gid = secili_id(self.tv)
        if not gid:
            messagebox.showinfo("Seçim", "Önce listeden bir gemi seçin.", parent=self)
        return gid

    def _secili_anahtarlar(self):
        """Gemilerim'de secili gemilerin imo/mmsi'si (rapor penceresinde isaretli gelir)"""
        sonuc = []
        for iid in self.tv.selection():
            g = self.app.vt.gemi(int(iid))
            if g and (g.get("imo") or g.get("mmsi")):
                sonuc.append(g.get("imo") or g.get("mmsi"))
        return sonuc

    def duzenle(self):
        gid = self._secili()
        if gid:
            GemiFormu(self.app, gid)

    def haritada(self):
        gid = self._secili()
        if not gid:
            return
        g = self.app.vt.gemi(gid)
        self.app.nb.select(self.app.sekme_harita)
        h = self.app.sekme_harita
        h.git_veya_sor(g.get("mmsi") or "", g.get("imo") or "", g["ad"])

    def sil(self):
        gid = self._secili()
        if gid and messagebox.askyesno("Sil", "Gemi ve hatırlatmaları silinsin mi?", parent=self):
            self.app.vt.gemi_sil(gid)
            self.app.degisti()

    # ---------------- bogaz sirasi
    def _simdi(self):
        self.app.bogaz.simdi_yenile()
        self.bogaz_lbl.config(text="Güncelleniyor…")

    def bogaz_durum(self, metin):
        self.bogaz_lbl.config(text=metin)

    def bogaz_yenile(self):
        v = self.app.bogaz.veri
        bizim_imo = {g["imo"] for g in self.app.vt.gemiler() if g.get("imo")}
        bizim_mmsi = {g["mmsi"] for g in self.app.vt.gemiler() if g.get("mmsi")}
        izlenen = self.app.izlenen_gemiler()
        yon_sec = {y: k for k, y in YONLER.items()}.get(self.f_yon.get())
        durum_sec = self.f_durum.get()
        katla = lambda x: tr_lower(x).replace("ı", "i")      # GEMI / gemi / GEMİ hepsi eslessin
        aranan = katla(self.f_ara.get().strip())
        for kod, tv in self.bogaz_tv.items():
            secim = tv.selection()
            tv.delete(*tv.get_children())
            liste = v.get(kod) or []
            gosterilen = 0
            for i, s in enumerate(liste, 1):
                bizim = s.get("imo") in bizim_imo or s.get("mmsi") in bizim_mmsi
                takipte = s.get("imo") in izlenen or s.get("mmsi") in izlenen
                if self.f_bizim.get() and not bizim:
                    continue
                if self.f_takip.get() and not takipte:
                    continue
                if yon_sec and s.get("yon") != yon_sec:
                    continue
                if durum_sec != "Hepsi" and (s.get("durum") or "") != durum_sec:
                    continue
                if aranan and aranan not in katla(f"{s['ad']} {s['tip']} {s['imo']} {s['mmsi']}"):
                    continue
                etiket = ("bizim",) if bizim else (("takip",) if takipte else
                                                   (("bogazda",) if s.get("durum") == "BOĞAZDA" else ()))
                tv.insert("", "end", iid=f"{kod}{i}", tags=etiket, values=(
                    f"🔔{i}" if takipte else i, s["durum"], s["plan_zamani"], YONLER.get(s.get("yon"), ""), s["ad"], s["boy"], s["tip"],
                    s["kilavuz"], s["romorkor"], s["sp2"], s["sp1"], s["imo"], s["mmsi"]))
                gosterilen += 1
            if secim and tv.exists(secim[0]):
                tv.selection_set(secim[0])
            ek = f"{gosterilen}/{len(liste)}" if gosterilen != len(liste) else str(len(liste))
            self.bnb.tab(list(self.bogaz_tv).index(kod), text=f"  {BOGAZLAR[kod]} Boğazı ({ek})  ")
        self.trafik_yenile()
        if v.get("zaman"):
            hata = f"   ⚠ {self.app.bogaz.hata}" if self.app.bogaz.hata else ""
            self.bogaz_lbl.config(text=f"Son güncelleme: {v['zaman']}{hata}")
        self.yenile()

    # ---------------- bogaz trafigi
    TRAFIK_RENK = {"acik": "#2E7D32", "askida": "#C62828", "diger": "#8A9599"}
    TRAFIK_YAZI = {"acik": "AÇIK", "askida": "ASKIDA", "diger": "PLANSIZ"}
    YON_OK = {"KG": "K→G", "GK": "G→K"}

    def _trafik_dongu(self):
        self.trafik_yenile()
        try:
            self.app.dakika_kontrol()
        except Exception as e:
            self.app.durum(f"Kontrol hatası: {e}")
        self.after(60000, self._trafik_dongu)

    def trafik_yenile(self):
        t = self.app.bogaz.veri.get("trafik")
        for (kod, yon), (rozet, ek) in self.trafik_hucre.items():
            d = trafik_durumu(t, kod, yon)
            if d is None:
                rozet.config(text=f" {self.YON_OK[yon]}  — ", bg="#9AA5A8")
                ek.config(text="bilgi yok")
                continue
            durum, metin, sonra = d
            rozet.config(text=f" {self.YON_OK[yon]}  {self.TRAFIK_YAZI[durum]} ", bg=self.TRAFIK_RENK[durum])
            ek.config(text=sonra)

    def trafik_penceresi(self):
        t = self.app.bogaz.veri.get("trafik") or {}
        p = tk.Toplevel(self)
        p.title("Boğaz Trafiği")
        p.configure(bg=KART)
        p.transient(self.app)
        tk.Label(p, text="  ⚓  Türk Boğazları Trafiği — Açık / Askıda Saatler", bg=TEAL, fg="white",
                 font=("Segoe UI", 11, "bold"), anchor="w", pady=7).pack(fill="x")
        govde = tk.Frame(p, bg=KART, padx=14, pady=10)
        govde.pack(fill="both")
        if not t.get("bugun"):
            tk.Label(govde, text="Bilgi henüz alınamadı. '⟳ Şimdi Yenile' ile tekrar deneyin.", bg=KART,
                     fg=SOLUK).pack()
        G, Y, X0 = 600, 18, 92
        simdi = dt.datetime.now()
        bugun_tarih = t.get("tarih", "")
        yarin_tarih = (dt.datetime.strptime(bugun_tarih, "%d.%m.%Y") + dt.timedelta(days=1)).strftime("%d.%m.%Y") \
            if bugun_tarih else ""
        for gun, baslik in (("bugun", f"Bugün {bugun_tarih}"), ("yarin", f"Yarın {yarin_tarih}")):
            veri = t.get(gun) or {}
            if gun == "yarin" and not veri:
                continue
            tk.Label(govde, text=baslik, bg=KART, fg=YAZI, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(6, 2))
            for kod in ("I", "C"):
                tk.Label(govde, text=f"{BOGAZLAR[kod]} Boğazı", bg=KART, fg=TEAL_KOYU,
                         font=("Segoe UI", 9, "bold")).pack(anchor="w", pady=(4, 0))
                for yon in ("KG", "GK"):
                    dilim = (veri.get(kod) or {}).get(yon) or []
                    cv = tk.Canvas(govde, width=X0 + G + 10, height=Y + 16, bg=KART, highlightthickness=0)
                    cv.pack(anchor="w")
                    cv.create_text(4, Y / 2 + 2, text={"KG": "Kuzey→Güney", "GK": "Güney→Kuzey"}[yon], anchor="w",
                                   font=("Segoe UI", 8), fill=YAZI)
                    cv.create_rectangle(X0, 2, X0 + G, Y + 2, fill="#D5DADB", outline="")
                    dk = lambda h: int(h[:2]) * 60 + int(h[3:])
                    for bas_, bit_, durum, metin in dilim:
                        x1 = X0 + G * dk(bas_) / 1440
                        x2 = X0 + G * (1440 if bit_ == "23:59" else dk(bit_)) / 1440
                        cv.create_rectangle(x1, 2, x2, Y + 2, fill=self.TRAFIK_RENK[durum], outline="white")
                        if x2 - x1 > 34:
                            cv.create_text((x1 + x2) / 2, Y / 2 + 2, text=f"{bas_}–{bit_}", fill="white",
                                           font=("Segoe UI", 7))
                    for saat in range(0, 25, 3):
                        x = X0 + G * saat / 24
                        cv.create_text(x, Y + 10, text=f"{saat:02d}", font=("Segoe UI", 7), fill=SOLUK)
                    if gun == "bugun":
                        x = X0 + G * (simdi.hour * 60 + simdi.minute) / 1440
                        cv.create_line(x, 0, x, Y + 4, fill="#111", width=2)
        lej = tk.Frame(govde, bg=KART)
        lej.pack(anchor="w", pady=(10, 0))
        for d in ("acik", "askida", "diger"):
            tk.Label(lej, text=f"  {self.TRAFIK_YAZI[d]}  ", bg=self.TRAFIK_RENK[d], fg="white",
                     font=("Segoe UI", 8, "bold")).pack(side="left", padx=(0, 8))
        tk.Label(lej, text="siyah çizgi: şu an   •   Kaynak: Kıyı Emniyeti, 5 dk'da bir güncellenir", bg=KART,
                 fg=SOLUK, font=("Segoe UI", 8)).pack(side="left")
        ttk.Button(p, text="Kapat", command=p.destroy).pack(pady=(4, 12))
        p.bind("<Escape>", lambda e: p.destroy())
        ortala(p, self.app)

    def _secili_bogaz(self, kod=None):
        kod = kod or ("I", "C")[self.bnb.index(self.bnb.select())]
        tv = self.bogaz_tv[kod]
        sec = tv.selection()
        if not sec:
            messagebox.showinfo("Seçim", "Önce boğaz listesinden bir gemi seçin.", parent=self)
            return None
        i = int(sec[0][1:]) - 1
        liste = self.app.bogaz.veri.get(kod) or []
        return liste[i] if 0 <= i < len(liste) else None

    def _bogazdan_harita(self, kod=None):
        s = self._secili_bogaz(kod)
        if not s:
            return
        h = self.app.sekme_harita
        self.app.nb.select(h)
        kod = kod or ("I", "C")[self.bnb.index(self.bnb.select())]
        ek = (f"Boğaz listesinde: {BOGAZLAR[kod]} Boğazı — {s['durum'] or '-'} {s['plan_zamani']}"
              + (f" ({YONLER[s['yon']]})" if s.get("yon") in YONLER else ""))
        h.git_veya_sor(s.get("mmsi", ""), s.get("imo", ""), s["ad"], ek)

    def _takip_degistir(self, kod=None):
        s = self._secili_bogaz(kod)
        if not s:
            return
        bizim = any(g.get("imo") and g["imo"] == s.get("imo") or g.get("mmsi") and g["mmsi"] == s.get("mmsi")
                    for g in self.app.vt.gemiler())
        if bizim and self.app.ayar.get("gemilerimi_takip", True):
            messagebox.showinfo("Statü Takibi", f"{s['ad']} Gemilerim listesinde; zaten otomatik takipte.\n"
                                "(Ayarlar → 'Gemilerim'deki gemileri otomatik takip et')", parent=self)
            return
        takipte = self.app.takip_degistir(s)
        mail = self.app.ayar.get("mail_aktif") and bildirim.alicilari_coz(self.app.ayar.get("mail_alicilar"))
        if takipte:
            ek = ("Durumu değişince e-posta gönderilecek." if mail else
                  "Durumu değişince bildirim gelir.\nE-posta için Ayarlar → E-posta bildirimi bölümünü doldurun.")
            self.app.durum(f"🔔 {s['ad']} takibe alındı")
            messagebox.showinfo("Statü Takibi", f"🔔 {s['ad']} takibe alındı.\n{ek}", parent=self)
        else:
            self.app.durum(f"{s['ad']} takipten çıkarıldı")
        self.bogaz_yenile()

    def _sag_tik(self, e, kod):
        tv = self.bogaz_tv[kod]
        iid = tv.identify_row(e.y)
        if not iid:
            return
        tv.selection_set(iid)
        s = self._secili_bogaz(kod)
        izlenen = self.app.izlenen_gemiler()
        takipte = s and (s.get("imo") in izlenen or s.get("mmsi") in izlenen)
        m = tk.Menu(self, tearoff=0)
        m.add_command(label="🔕 Takipten Çıkar" if takipte else "🔔 Statü Takibine Al (Mail)",
                      command=lambda: self._takip_degistir(kod))
        m.add_command(label="🗺 Haritada Göster", command=lambda: self._bogazdan_harita(kod))
        m.add_command(label="⭐ Gemilerime Ekle", command=self._bogazdan_ekle)
        m.tk_popup(e.x_root, e.y_root)

    def _bogazdan_ekle(self):
        s = self._secili_bogaz()
        if not s:
            return
        GemiFormu(self.app, None, onveri={"ad": s["ad"], "imo": s.get("imo", ""), "mmsi": s.get("mmsi", ""),
                                          "bayrak": mmsi_bayrak(s.get("mmsi")), "tip": s["tip"].title()})


# ======================================================================  DURUM RAPORU
class RaporPenceresi(tk.Toplevel):
    """Secilen gemiler icin armator/musteri durum raporu: mail (HTML tablo), Excel, panoya kopyala."""

    def __init__(self, app, secili=None):
        super().__init__(app)
        self.app = app
        self.title("Gemi Durum Raporu")
        self.configure(bg=ZEMIN)
        self.transient(app)
        tk.Label(self, text="  📄  Gemi Durum Raporu", bg=TEAL, fg="white", font=("Segoe UI", 12, "bold"),
                 anchor="w", pady=8).pack(fill="x")
        govde = ttk.Frame(self, padding=12)
        govde.pack(fill="both", expand=True)

        # sol: gemi secimi
        sol = ttk.Frame(govde)
        sol.pack(side="left", fill="y")
        ttk.Label(sol, text="Rapora girecek gemiler (tıklayarak seçin)", font=("Segoe UI", 9, "bold")).pack(anchor="w")
        c, self.tv = tablo_olustur(sol, [("sec", "✔", 34), ("ad", "Gemi", 170), ("kaynak", "", 90)], 14)
        c.pack(fill="y", expand=True, pady=4)
        self.tv.bind("<Button-1>", self._tikla)
        self.gemiler = []                               # [(anahtar, ad, kaynak)]
        gorulen = set()
        for g in app.vt.gemiler():
            k = g.get("imo") or g.get("mmsi")
            if k and k not in gorulen:
                gorulen.add(k)
                self.gemiler.append((k, g["ad"], "Gemilerim"))
        for t in app.ayar.get("bogaz_takip") or []:
            if t.get("k") and t["k"] not in gorulen:
                gorulen.add(t["k"])
                self.gemiler.append((t["k"], t.get("ad") or t["k"], "🔔 Takip"))
        secili = set(secili or [])
        for i, (k, ad, kay) in enumerate(self.gemiler):
            self.tv.insert("", "end", iid=str(i), values=("☑" if (k in secili or not secili) else "☐", ad, kay))
        sd = ttk.Frame(sol)
        sd.pack(fill="x")
        ttk.Button(sd, text="Tümü", command=lambda: self._hepsi(True)).pack(side="left")
        ttk.Button(sd, text="Hiçbiri", command=lambda: self._hepsi(False)).pack(side="left", padx=4)

        # sag: ayarlar + onizleme
        sag = ttk.Frame(govde)
        sag.pack(side="left", fill="both", expand=True, padx=(14, 0))
        f = ttk.Frame(sag)
        f.pack(fill="x")
        ttk.Label(f, text="Dil").grid(row=0, column=0, sticky="w")
        self.dil = ttk.Combobox(f, state="readonly", width=12, values=["Türkçe", "English"])
        self.dil.current(1 if app.ayar.get("rapor_dil") == "EN" else 0)
        self.dil.grid(row=0, column=1, sticky="w", padx=6)
        self.dil.bind("<<ComboboxSelected>>", lambda e: self.onizle())
        ttk.Label(f, text="Alıcılar").grid(row=1, column=0, sticky="w", pady=4)
        self.alici = ttk.Entry(f, width=60)
        self.alici.insert(0, app.ayar.get("rapor_alicilar") or app.ayar.get("mail_alicilar") or "")
        self.alici.grid(row=1, column=1, sticky="w", padx=6)
        ttk.Label(f, text="Not (isteğe bağlı)").grid(row=2, column=0, sticky="w")
        self.not_ = ttk.Entry(f, width=60)
        self.not_.grid(row=2, column=1, sticky="w", padx=6)
        self.not_.bind("<KeyRelease>", lambda e: self.after(400, self.onizle))
        ttk.Label(sag, text="Önizleme (mailde tablo olarak gider)", foreground=SOLUK).pack(anchor="w", pady=(8, 2))
        self.on = tk.Text(sag, width=86, height=22, font=("Consolas", 9), relief="solid", bd=1, wrap="none")
        self.on.pack(fill="both", expand=True)
        alt = ttk.Frame(self, padding=(12, 0, 12, 12))
        alt.pack(fill="x")
        self.durum_lbl = ttk.Label(alt, text="", foreground=SOLUK)
        self.durum_lbl.pack(side="left")
        ttk.Button(alt, text="Kapat", command=self.destroy).pack(side="right")
        ttk.Button(alt, text="📋 Kopyala", command=self.kopyala).pack(side="right", padx=6)
        ttk.Button(alt, text="📊 Excel'e Kaydet", command=self.excel).pack(side="right")
        ttk.Button(alt, text="✉ Mail Gönder", style="Vurgu.TButton", command=self.gonder).pack(side="right", padx=6)
        self.bind("<Escape>", lambda e: self.destroy())
        self.onizle()
        ortala(self, app)

    def _tikla(self, e):
        iid = self.tv.identify_row(e.y)
        if iid:
            v = list(self.tv.item(iid, "values"))
            v[0] = "☐" if v[0] == "☑" else "☑"
            self.tv.item(iid, values=v)
            self.onizle()
            return "break"

    def _hepsi(self, deger):
        for iid in self.tv.get_children():
            v = list(self.tv.item(iid, "values"))
            v[0] = "☑" if deger else "☐"
            self.tv.item(iid, values=v)
        self.onizle()

    def _hazirla(self):
        satirlar = [self.app.rapor_verisi(self.gemiler[int(iid)][0], self.gemiler[int(iid)][1])
                    for iid in self.tv.get_children() if self.tv.item(iid, "values")[0] == "☑"]
        dil = "EN" if self.dil.current() == 1 else "TR"
        return raporlar.durum_raporu(satirlar, dil, self.app.firma_adi(), self.app.firma_unvani(),
                                     self.not_.get().strip()), satirlar

    def onizle(self):
        try:
            (konu, metin, html, bas, tablo), satirlar = self._hazirla()
        except Exception as e:
            konu, metin = "", f"Rapor hazırlanamadı: {e}"
        self.on.config(state="normal")
        self.on.delete("1.0", "end")
        self.on.insert("1.0", f"Konu: {konu}\n\n{metin}")
        self.on.config(state="disabled")

    def gonder(self):
        (konu, metin, html, bas, tablo), satirlar = self._hazirla()
        if not satirlar:
            self.durum_lbl.config(text="En az bir gemi seçin.", foreground=KIRMIZI)
            return
        alici = self.alici.get().strip()
        if not bildirim.alicilari_coz(alici):
            self.durum_lbl.config(text="Alıcı e-posta adresi yazın.", foreground=KIRMIZI)
            return
        self.app.ayar["rapor_alicilar"] = alici
        self.app.ayar["rapor_dil"] = "EN" if self.dil.current() == 1 else "TR"
        ayar_kaydet(self.app.ayar)
        self.durum_lbl.config(text="Gönderiliyor…", foreground=SOLUK)

        def geri(ok, m):
            try:
                self.durum_lbl.config(text=m, foreground="#2E7D32" if ok else KIRMIZI)
            except tk.TclError:
                pass
        self.app.mail_gonder(konu, metin, html=html, alicilar=alici, geri=geri)

    def excel(self):
        (konu, metin, html, bas, tablo), satirlar = self._hazirla()
        if not satirlar:
            self.durum_lbl.config(text="En az bir gemi seçin.", foreground=KIRMIZI)
            return
        yol = filedialog.asksaveasfilename(parent=self, defaultextension=".xlsx",
                                           initialfile=f"Gemi_Durum_Raporu_{dt.datetime.now():%Y%m%d_%H%M}.xlsx",
                                           filetypes=[("Excel", "*.xlsx")])
        if not yol:
            return
        try:
            yol = raporlar.excel_kaydet(yol, konu, bas, tablo, self.app.firma_unvani() or self.app.firma_adi())
            self.durum_lbl.config(text=f"✔ Kaydedildi: {yol}", foreground="#2E7D32")
            try:
                os.startfile(yol)
            except (AttributeError, OSError):
                pass
        except Exception as e:
            self.durum_lbl.config(text=f"Kaydedilemedi: {e}", foreground=KIRMIZI)

    def kopyala(self):
        (konu, metin, html, bas, tablo), satirlar = self._hazirla()
        self.clipboard_clear()
        self.clipboard_append(metin)
        self.durum_lbl.config(text="✔ Panoya kopyalandı", foreground="#2E7D32")


# ======================================================================  ISTATISTIK
class IstatistikPenceresi(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app)
        self.app = app
        self.title("Boğaz Bekleme İstatistiği")
        self.configure(bg=KART)
        self.transient(app)
        tk.Label(self, text="  📊  Boğaz Bekleme Süreleri", bg=TEAL, fg="white", font=("Segoe UI", 12, "bold"),
                 anchor="w", pady=8).pack(fill="x")
        ust = tk.Frame(self, bg=KART, padx=12, pady=8)
        ust.pack(fill="x")
        tk.Label(ust, text="Dönem:", bg=KART).pack(side="left")
        self.gun = ttk.Combobox(ust, state="readonly", width=12, values=["Son 1 gün", "Son 7 gün", "Son 30 gün",
                                                                       "Son 90 gün"])
        self.gun.current(1)
        self.gun.pack(side="left", padx=6)
        self.gun.bind("<<ComboboxSelected>>", lambda e: self.ciz())
        self.bilgi = tk.Label(ust, text="", bg=KART, fg=SOLUK, font=("Segoe UI", 8), justify="left")
        self.bilgi.pack(side="left", padx=12)
        self.govde = tk.Frame(self, bg=KART, padx=12)
        self.govde.pack(fill="both", expand=True)
        ttk.Button(self, text="Kapat", command=self.destroy).pack(pady=10)
        self.bind("<Escape>", lambda e: self.destroy())
        self.ciz()
        ortala(self, app)

    def ciz(self):
        for w in self.govde.winfo_children():
            w.destroy()
        if not self.app.istatistik:
            tk.Label(self.govde, text="İstatistik dosyası açılamadı.", bg=KART).pack()
            return
        gun = [1, 7, 30, 90][self.gun.current()]
        o = self.app.istatistik.ozet(gun)
        self.bilgi.config(text=f"Program {o['baslangic'] or '-'} tarihinden beri listeyi kaydediyor; "
                               f"bu dönemde {o['toplam']} gemi gözlendi.\n"
                               "Bekleme = listeye giriş → BOĞAZDA.  Program kapalıyken giren gemiler hesaba katılmaz.")
        tk.Label(self.govde, text="Boğaz ve yöne göre", bg=KART, fg=TEAL_KOYU,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(4, 2))
        c, tv = tablo_olustur(self.govde, [("bogaz", "Boğaz", 90), ("yon", "Yön", 110), ("sayi", "Gemi", 55),
                                           ("ort", "Ort. bekleme", 105), ("med", "Medyan", 95),
                                           ("max", "En uzun", 95), ("gec", "Ort. geçiş", 90)], 5)
        c.pack(fill="x")
        for i, g in enumerate(o["gruplar"]):
            tv.insert("", "end", iid=str(i), values=(BOGAZLAR.get(g["bogaz"]), YONLER.get(g["yon"], "—"), g["sayi"],
                                                     sure_metni(g["bekleme_ort"]), sure_metni(g["bekleme_med"]),
                                                     sure_metni(g["bekleme_max"]), sure_metni(g["gecis_ort"])))
        if not o["gruplar"]:
            tv.insert("", "end", values=("", "Henüz yeterli veri yok", "", "", "", "", ""))
        tk.Label(self.govde, text="Gemi boyuna göre ortalama bekleme", bg=KART, fg=TEAL_KOYU,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 2))
        c2, tv2 = tablo_olustur(self.govde, [("bogaz", "Boğaz", 90), ("yon", "Yön", 110), ("sinif", "Boy", 95),
                                             ("sayi", "Gemi", 55), ("ort", "Ort. bekleme", 105)], 6)
        c2.pack(fill="x")
        for i, g in enumerate(o["boy"]):
            tv2.insert("", "end", iid=str(i), values=(BOGAZLAR.get(g["bogaz"]), YONLER.get(g["yon"], "—"), g["sinif"],
                                                      g["sayi"], sure_metni(g["bekleme_ort"])))
        tk.Label(self.govde, text="Saatlere göre boğaza giren gemi sayısı (yoğunluk)", bg=KART, fg=TEAL_KOYU,
                 font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(10, 2))
        G, H, X0 = 620, 70, 80
        cv = tk.Canvas(self.govde, width=X0 + G + 10, height=2 * (H + 26), bg=KART, highlightthickness=0)
        cv.pack(anchor="w")
        en_cok = max([1] + o["saatlik"]["I"] + o["saatlik"]["C"])
        for r, kod in enumerate(("I", "C")):
            y0 = r * (H + 26)
            cv.create_text(4, y0 + H / 2, text=BOGAZLAR[kod], anchor="w", font=("Segoe UI", 9, "bold"), fill=TEAL_KOYU)
            for saat, n in enumerate(o["saatlik"][kod]):
                x = X0 + saat * G / 24
                h = (H - 14) * n / en_cok
                cv.create_rectangle(x + 2, y0 + H - h, x + G / 24 - 2, y0 + H, fill=TEAL if n else "#E3E8E9",
                                    outline="")
                if n:
                    cv.create_text(x + G / 48, y0 + H - h - 6, text=str(n), font=("Segoe UI", 7), fill=SOLUK)
                if saat % 3 == 0:
                    cv.create_text(x + G / 48, y0 + H + 9, text=f"{saat:02d}", font=("Segoe UI", 7), fill=SOLUK)


# ======================================================================  HATIRLATMALAR
class HatirlatmaSekmesi(ttk.Frame):
    """Tek liste: acik isler, en acil olan en ustte. Gecikmis kirmizi, yaklasan turuncu."""
    def __init__(self, ebeveyn, app):
        super().__init__(ebeveyn)
        self.app = app
        ust = ttk.Frame(self)
        ust.pack(fill="x", padx=4, pady=(10, 6))
        tk.Label(ust, text="⏰  Hatırlatmalar", bg=ZEMIN, fg=MERCAN, font=("Segoe UI", 12, "bold")).pack(side="left")
        self.ozet = ttk.Label(ust, foreground=SOLUK)
        self.ozet.pack(side="left", padx=12)
        ttk.Button(ust, text="🗑 Sil", command=self.sil).pack(side="right")
        ttk.Button(ust, text="✔ Tamamlandı", command=self.tamam).pack(side="right", padx=4)
        ttk.Button(ust, text="📑 Standart Belgeler", style="Ana.TButton",
                   command=lambda: StandartBelgeFormu(self.app)).pack(side="right", padx=4)
        ttk.Button(ust, text="＋ Ekle", style="Vurgu.TButton",
                   command=lambda: HatirlatmaFormu(self.app)).pack(side="right", padx=4)
        cerceve, self.tv = tablo_olustur(self, [("zaman", "Son Tarih", 150), ("gemi", "Gemi", 180),
                                               ("is", "İş / Belge", 520), ("durum", "Durum", 130)])
        cerceve.pack(fill="both", expand=True, padx=4, pady=(0, 6))
        self.tv.tag_configure("gecikti", foreground=KIRMIZI, background="#FDECEA")
        self.tv.tag_configure("yakin", foreground="#B35C00", background="#FFF4E0")
        self.tv.tag_configure("tarihsiz", foreground=SOLUK)
        self.tv.bind("<Double-1>", lambda e: self.duzenle())
        ttk.Label(self, text="Çift tıklayınca düzenlenir. Tamamlanan işler listeden kalkar.",
                  foreground=SOLUK, font=("Segoe UI", 8)).pack(anchor="w", padx=6, pady=(0, 4))

    def yenile(self):
        secim = self.tv.selection()
        self.tv.delete(*self.tv.get_children())
        simdi = dt.datetime.now()
        sinir = simdi + dt.timedelta(hours=int(self.app.ayar.get("hatirlatma_saat") or 24))
        gec = yak = 0
        for h in self.app.vt.hatirlatma_listesi(sadece_acik=True):
            try:
                t = tarih_coz(h.get("son_tarih"))
            except ValueError:
                t = None
            if t is None:
                tag, durum = "tarihsiz", "tarih yok"
            elif t < simdi:
                tag, durum, gec = "gecikti", "⚠ GECİKTİ", gec + 1
            elif t <= sinir:
                tag, durum, yak = "yakin", "Yaklaşıyor", yak + 1
            else:
                tag, durum = "", "Bekliyor"
            self.tv.insert("", "end", iid=str(h["id"]), tags=(tag,),
                           values=(bos(h.get("son_tarih")) or "—", h["gemi_adi"], h["ad"], durum))
        if secim and self.tv.exists(secim[0]):
            self.tv.selection_set(secim[0])
        self.ozet.config(text=f"{gec} gecikmiş, {yak} yaklaşan, toplam {len(self.tv.get_children())} açık iş")

    def yaklasanlari_goster(self, liste):
        self.yenile()

    def _secili(self):
        hid = secili_id(self.tv)
        if not hid:
            messagebox.showinfo("Seçim", "Önce listeden bir hatırlatma seçin.", parent=self)
        return hid

    def tamam(self):
        hid = self._secili()
        if hid:
            self.app.vt.hatirlatma_tamam(hid, True)
            self.app.degisti()

    def duzenle(self):
        hid = secili_id(self.tv)
        if hid:
            HatirlatmaFormu(self.app, hid)

    def sil(self):
        hid = self._secili()
        if hid and messagebox.askyesno("Sil", "Hatırlatma silinsin mi?", parent=self):
            self.app.vt.hatirlatma_sil(hid)
            self.app.degisti()


# ======================================================================  AYARLAR
class AyarSekmesi(ttk.Frame):
    def __init__(self, ebeveyn, app):
        super().__init__(ebeveyn)
        self.app = app
        ust = ttk.Frame(self, padding=(18, 14, 18, 6))
        ust.pack(fill="x")
        k = ttk.Frame(ust)
        k.pack(side="left", anchor="n")
        a = app.ayar
        r = 0

        def satir(etiket, w, ipucu=""):
            nonlocal r
            ttk.Label(k, text=etiket, font=("Segoe UI", 10, "bold")).grid(row=r, column=0, sticky="w", pady=8, padx=(0, 12))
            w.grid(row=r, column=1, sticky="w")
            if ipucu:
                ttk.Label(k, text=ipucu, foreground=SOLUK).grid(row=r + 1, column=1, sticky="w")
                r += 1
            r += 1

        self.kullanici = ttk.Entry(k, width=40)
        self.kullanici.insert(0, a.get("kullanici", ""))
        satir("Kullanıcı adı", self.kullanici)
        self.sirket_adi = ttk.Entry(k, width=40)
        self.sirket_adi.insert(0, a.get("sirket_adi", ""))
        satir("Şirket adı", self.sirket_adi)
        self.sirket_unvani = ttk.Entry(k, width=52)
        self.sirket_unvani.insert(0, a.get("sirket_unvani", ""))
        satir("Şirket ünvanı", self.sirket_unvani, "Üst bantta ve e-posta imzasında görünür.")

        vt_c = ttk.Frame(k)
        self.vt_yolu = ttk.Entry(vt_c, width=52)
        self.vt_yolu.insert(0, a.get("vt_yolu", ""))
        self.vt_yolu.pack(anchor="w")
        vt_d = ttk.Frame(vt_c)
        vt_d.pack(anchor="w", pady=(4, 0))
        ttk.Button(vt_d, text="Ortak klasör seç…", command=self._klasor).pack(side="left")
        ttk.Button(vt_d, text="Var olan dosyayı seç…", command=self._dosya).pack(side="left", padx=6)
        satir("Ortak veritabanı", vt_c,
              "Ekipteki herkes AYNI dosyayı seçmeli\n(OneDrive/Drive ortak klasörü veya ofis ağ klasörü).")

        ais_c = ttk.Frame(k)
        self.ais = ttk.Entry(ais_c, width=44, show="•")
        self.ais.insert(0, a.get("ais_anahtar", ""))
        self.ais.pack(side="left")
        self.goster = tk.BooleanVar()
        ttk.Checkbutton(ais_c, text="göster", variable=self.goster,
                        command=lambda: self.ais.config(show="" if self.goster.get() else "•")).pack(side="left", padx=6)
        satir("AISStream API anahtarı", ais_c, "Ücretsiz: aisstream.io → GitHub ile giriş → API Keys → Create")

        self.saat = ttk.Spinbox(k, from_=1, to=168, width=6)
        self.saat.set(a.get("hatirlatma_saat", 24))
        satir("Hatırlatma (saat önce)", self.saat, "Son tarihe bu kadar saat kala uyarı verir.")

        dk = ttk.Frame(k)
        dk.grid(row=r, column=1, sticky="w", pady=14)
        ttk.Button(dk, text="💾 Ayarları Kaydet", style="Vurgu.TButton", command=self.kaydet).pack(side="left")
        ttk.Button(dk, text="📂 Veri Klasörünü Aç", command=self._veri_ac).pack(side="left", padx=8)
        r += 1
        ttk.Label(k, text=f"Sürüm {app.surum()}   •   Program: {PROGRAM_KLASOR}\nVeriler: {VERI_KLASOR}",
                  foreground=SOLUK, wraplength=520).grid(row=r, column=1, sticky="w")

        # ---------------- sag: arka plan + e-posta
        sag_kolon = ttk.Frame(ust)
        sag_kolon.pack(side="left", anchor="n", padx=(28, 0), fill="x", expand=True)
        m = ttk.LabelFrame(sag_kolon, text="  Arka Plan ve E-posta Bildirimi  ", padding=12)
        m.pack(fill="x")
        ob = ttk.LabelFrame(sag_kolon, text="  Otomatik Bildirimler  ", padding=12)
        ob.pack(fill="x", pady=(10, 0))
        gk = ttk.Frame(sag_kolon)
        gk.pack(fill="x", pady=(10, 0))
        self.oto_guncelle = tk.BooleanVar(value=bool(a.get("otomatik_guncelle", True)))
        ttk.Checkbutton(gk, text="Yeni sürüm yayınlanınca otomatik güncelle", variable=self.oto_guncelle).pack(side="left")
        ttk.Button(gk, text="Şimdi kontrol et", command=lambda: self.app.guncelleme_kontrol(elle=True)).pack(side="left", padx=8)
        ttk.Label(gk, text=f"Sürüm {app.surum()}", foreground=SOLUK).pack(side="left")
        self.trafik_mail = tk.BooleanVar(value=bool(a.get("trafik_mail", True)))
        ttk.Checkbutton(ob, text="Boğaz trafik planı değişince / yarının planı yayınlanınca e-posta",
                        variable=self.trafik_mail).grid(row=0, column=0, columnspan=3, sticky="w")
        self.trafik_anlik = tk.BooleanVar(value=bool(a.get("trafik_anlik", True)))
        ttk.Checkbutton(ob, text="Boğaz açılınca / askıya alınınca bildirim (saat yanında)",
                        variable=self.trafik_anlik).grid(row=1, column=0, columnspan=3, sticky="w")
        self.trafik_anlik_mail = tk.BooleanVar(value=bool(a.get("trafik_anlik_mail")))
        ttk.Checkbutton(ob, text="… bunu e-posta ile de gönder (günde birkaç kez gelebilir)",
                        variable=self.trafik_anlik_mail).grid(row=2, column=0, columnspan=3, sticky="w", padx=(20, 0))
        oz = ttk.Frame(ob)
        oz.grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))
        self.ozet_aktif = tk.BooleanVar(value=bool(a.get("ozet_aktif")))
        ttk.Checkbutton(oz, text="Her sabah özet e-postası gönder, saat:", variable=self.ozet_aktif).pack(side="left")
        self.ozet_saat = ttk.Entry(oz, width=6)
        self.ozet_saat.insert(0, a.get("ozet_saat", "08:00"))
        self.ozet_saat.pack(side="left", padx=4)
        ttk.Button(oz, text="Şimdi gönder", command=self._ozet_simdi).pack(side="left", padx=6)
        ttk.Label(ob, text="Özet: boğaz trafiği, takipteki gemilerin durumu, günün hatırlatmaları. "
                           "Program o saatte açık (arka planda) olmalı.",
                  foreground=SOLUK, font=("Segoe UI", 8), wraplength=520).grid(row=4, column=0, columnspan=3, sticky="w")
        self.oto = tk.BooleanVar(value=bool(a.get("otomatik_baslat", True)))
        ttk.Checkbutton(m, text="Windows açılınca otomatik başlat (arka planda, saat yanında simge)",
                        variable=self.oto).grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(m, text="Çarpıdan kapatınca program tepsiye iner ve çalışmaya devam eder.\n"
                          "Tamamen kapatmak: saat yanındaki simgeye sağ tık → Kapat.",
                  foreground=SOLUK).grid(row=1, column=0, columnspan=3, sticky="w", pady=(0, 8))
        self.gtakip = tk.BooleanVar(value=bool(a.get("gemilerimi_takip", True)))
        ttk.Checkbutton(m, text="Gemilerim'deki gemileri boğaz listesinde otomatik takip et",
                        variable=self.gtakip).grid(row=2, column=0, columnspan=3, sticky="w")
        self.mail_aktif = tk.BooleanVar(value=bool(a.get("mail_aktif")))
        ttk.Checkbutton(m, text="Takipteki gemilerin boğaz statüsü değişince e-posta gönder",
                        variable=self.mail_aktif).grid(row=3, column=0, columnspan=3, sticky="w", pady=(4, 6))

        def msatir(rr, etiket, w, ipucu=""):
            ttk.Label(m, text=etiket).grid(row=rr, column=0, sticky="w", pady=3, padx=(0, 8))
            w.grid(row=rr, column=1, sticky="w", pady=3)
            if ipucu:
                ttk.Label(m, text=ipucu, foreground=SOLUK, font=("Segoe UI", 8)).grid(row=rr, column=2, sticky="w", padx=6)

        self.alicilar = ttk.Entry(m, width=40)
        self.alicilar.insert(0, a.get("mail_alicilar", ""))
        msatir(4, "Alıcılar", self.alicilar, "virgülle birden fazla")
        self.yontem = ttk.Combobox(m, state="readonly", width=37,
                                   values=["Outlook (bilgisayardaki Outlook)", "SMTP (Gmail vb.)"])
        self.yontem.current(0 if a.get("mail_yontem", "Outlook") == "Outlook" else 1)
        self.yontem.bind("<<ComboboxSelected>>", lambda e: self._smtp_goster())
        msatir(5, "Gönderim", self.yontem)

        self.smtp = ttk.Frame(m)
        self.smtp.grid(row=6, column=0, columnspan=3, sticky="w")
        ttk.Label(self.smtp, text="Hesap türü").grid(row=0, column=0, sticky="w", pady=3, padx=(0, 8))
        self.hazir = ttk.Combobox(self.smtp, state="readonly", width=24, values=list(bildirim.SMTP_HAZIR))
        self.hazir.set(a.get("smtp_hazir", "Gmail"))
        self.hazir.bind("<<ComboboxSelected>>", lambda e: self._hazir_sec())
        self.hazir.grid(row=0, column=1, sticky="w")
        ttk.Label(self.smtp, text="Sunucu / Port").grid(row=1, column=0, sticky="w", pady=3, padx=(0, 8))
        sp = ttk.Frame(self.smtp)
        sp.grid(row=1, column=1, sticky="w")
        self.sunucu = ttk.Entry(sp, width=28)
        self.sunucu.insert(0, a.get("smtp_sunucu", ""))
        self.sunucu.pack(side="left")
        self.port = ttk.Entry(sp, width=6)
        self.port.insert(0, str(a.get("smtp_port", 587)))
        self.port.pack(side="left", padx=6)
        ttk.Label(self.smtp, text="E-posta adresi").grid(row=2, column=0, sticky="w", pady=3, padx=(0, 8))
        self.skul = ttk.Entry(self.smtp, width=40)
        self.skul.insert(0, a.get("smtp_kullanici", ""))
        self.skul.grid(row=2, column=1, sticky="w")
        ttk.Label(self.smtp, text="Uygulama şifresi").grid(row=3, column=0, sticky="w", pady=3, padx=(0, 8))
        self.ssifre = ttk.Entry(self.smtp, width=40, show="•")
        self.ssifre.insert(0, bildirim.sifre_coz(a.get("smtp_sifre", "")))
        self.ssifre.grid(row=3, column=1, sticky="w")
        ttk.Label(self.smtp, text="Gmail: Google Hesabı → Güvenlik → 2 Adımlı Doğrulama → Uygulama şifreleri\n"
                                  "(normal Gmail şifresi çalışmaz). Şifre bu bilgisayarda Windows ile şifreli saklanır.",
                  foreground=SOLUK, font=("Segoe UI", 8)).grid(row=4, column=0, columnspan=2, sticky="w")
        md = ttk.Frame(m)
        md.grid(row=7, column=0, columnspan=3, sticky="w", pady=(10, 0))
        ttk.Button(md, text="✉ Test Maili Gönder", command=self._test_mail).pack(side="left")
        self.mail_lbl = ttk.Label(md, text="", foreground=SOLUK, wraplength=380)
        self.mail_lbl.pack(side="left", padx=8)
        ttk.Label(m, text="Ayarlar bu bilgisayara özeldir; ekipte mail almak isteyen kendi bilgisayarında açar.",
                  foreground=SOLUK, font=("Segoe UI", 8)).grid(row=8, column=0, columnspan=3, sticky="w", pady=(8, 0))
        self._smtp_goster()

        ttk.Label(self, text="Son değişiklikler (ekip)", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=18)
        cerceve, self.log_tv = tablo_olustur(self, [("zaman", "Zaman", 140), ("kim", "Kim", 140), ("islem", "İşlem", 700)])
        cerceve.pack(fill="both", expand=True, padx=18, pady=(4, 10))

    def _smtp_goster(self):
        if self.yontem.current() == 1:
            self.smtp.grid()
        else:
            self.smtp.grid_remove()

    def _hazir_sec(self):
        sunucu, port = bildirim.SMTP_HAZIR.get(self.hazir.get(), ("", 587))
        if sunucu:
            self.sunucu.delete(0, "end")
            self.sunucu.insert(0, sunucu)
        self.port.delete(0, "end")
        self.port.insert(0, str(port))

    def _mail_ayarlarini_al(self, a):
        a["otomatik_guncelle"] = self.oto_guncelle.get()
        a["trafik_mail"] = self.trafik_mail.get()
        a["trafik_anlik"] = self.trafik_anlik.get()
        a["trafik_anlik_mail"] = self.trafik_anlik_mail.get()
        a["ozet_aktif"] = self.ozet_aktif.get()
        saat = self.ozet_saat.get().strip().replace(".", ":")
        try:
            sa, dk = (int(x) for x in saat.split(":"))
            a["ozet_saat"] = f"{max(0, min(23, sa)):02d}:{max(0, min(59, dk)):02d}"
        except ValueError:
            a["ozet_saat"] = "08:00"
        a["otomatik_baslat"] = self.oto.get()
        a["gemilerimi_takip"] = self.gtakip.get()
        a["mail_aktif"] = self.mail_aktif.get()
        a["mail_alicilar"] = self.alicilar.get().strip()
        a["mail_yontem"] = "Outlook" if self.yontem.current() == 0 else "SMTP"
        a["smtp_hazir"] = self.hazir.get()
        a["smtp_sunucu"] = self.sunucu.get().strip()
        try:
            a["smtp_port"] = int(self.port.get())
        except ValueError:
            a["smtp_port"] = 587
        a["smtp_kullanici"] = self.skul.get().strip()
        a["smtp_sifre"] = bildirim.sifre_sakla(self.ssifre.get())

    def _ozet_simdi(self):
        a = dict(self.app.ayar)
        self._mail_ayarlarini_al(a)
        if not bildirim.alicilari_coz(a["mail_alicilar"]):
            self.mail_lbl.config(text="Önce alıcı e-posta adresini yazın.", foreground=KIRMIZI)
            return
        eski, self.app.ayar = self.app.ayar, a
        try:
            self.mail_lbl.config(text="Özet gönderiliyor…", foreground=SOLUK)
            self.app.ozet_gonder(geri=lambda ok, m: self.mail_lbl.config(text=m, foreground="#2E7D32" if ok else KIRMIZI))
        finally:
            self.app.ayar = eski

    def _test_mail(self):
        a = dict(self.app.ayar)
        self._mail_ayarlarini_al(a)
        if not bildirim.alicilari_coz(a["mail_alicilar"]):
            self.mail_lbl.config(text="Önce alıcı e-posta adresini yazın.", foreground=KIRMIZI)
            return
        self.mail_lbl.config(text="Gönderiliyor…", foreground=SOLUK)
        ad = self.sirket_adi.get().strip()
        unvan = self.sirket_unvani.get().strip()
        konu = (f"[{ad}] " if ad else "") + "⚓ Gemi Sefer Takibi — test e-postası"
        govde = ("Bu bir test e-postasıdır. Boğaz listesinde takip ettiğiniz gemilerin statüsü değişince "
                 "bu adrese e-posta gelecek.\n\n— Gemi Sefer Takibi" + (f"\n{unvan or ad}" if (unvan or ad) else ""))
        eski, self.app.ayar = self.app.ayar, a
        try:
            self.app.mail_gonder(konu, govde, geri=lambda ok, metin: self.mail_lbl.config(
                text=metin, foreground="#2E7D32" if ok else KIRMIZI))
        finally:
            self.app.ayar = eski

    def _klasor(self):
        d = filedialog.askdirectory(parent=self, title="Ortak klasörü seçin")
        if d:
            self.vt_yolu.delete(0, "end")
            self.vt_yolu.insert(0, os.path.join(d, "sefer_takip.db"))

    def _dosya(self):
        f = filedialog.askopenfilename(parent=self, filetypes=[("Sefer veritabanı", "*.db")])
        if f:
            self.vt_yolu.delete(0, "end")
            self.vt_yolu.insert(0, f)

    def _veri_ac(self):
        try:
            os.startfile(VERI_KLASOR)
        except AttributeError:
            pass

    def kaydet(self):
        a = self.app.ayar
        eski_vt, eski_ais = a.get("vt_yolu"), a.get("ais_anahtar")
        a["kullanici"] = self.kullanici.get().strip() or a.get("kullanici")
        a["sirket_adi"] = self.sirket_adi.get().strip() or a.get("sirket_adi", "")
        a["sirket_unvani"] = self.sirket_unvani.get().strip()
        a["vt_yolu"] = self.vt_yolu.get().strip() or VARSAYILAN_AYAR["vt_yolu"]
        a["ais_anahtar"] = self.ais.get().strip()
        self._mail_ayarlarini_al(a)
        try:
            a["hatirlatma_saat"] = max(1, int(self.saat.get()))
        except ValueError:
            a["hatirlatma_saat"] = 24
        try:
            yeni_vt = Veritabani(a["vt_yolu"], a["kullanici"])
        except Exception as e:
            messagebox.showerror("Veritabanı", f"Bu konumda veritabanı açılamadı:\n{e}", parent=self)
            a["vt_yolu"] = eski_vt
            return
        ayar_kaydet(a)
        self.app.marka_uygula()
        ok, mesaj = self.app.otomatik_baslat_uygula()
        if a.get("otomatik_baslat") and not ok and os.name == "nt":
            messagebox.showwarning("Otomatik başlatma", f"Başlangıç kısayolu yazılamadı:\n{mesaj}", parent=self)
        self.app.vt = yeni_vt
        if a["vt_yolu"] != eski_vt or a["ais_anahtar"] != eski_ais:
            self.app.ais_baslat()
        self.app.gosterilen_hatirlatma.clear()
        self.app.hepsini_yenile()
        self.app.sekme_gemi.bogaz_yenile()
        messagebox.showinfo("Kaydedildi", "Ayarlar kaydedildi.", parent=self)

    def gunlugu_doldur(self):
        self.log_tv.delete(*self.log_tv.get_children())
        for g in self.app.vt.gunluk_listesi():
            self.log_tv.insert("", "end", values=(g["zaman"], g["kim"], g["islem"]))


# ======================================================================  YONETICI
class YoneticiSekmesi(ttk.Frame):
    """Sifreyle acilir: guncelleme yayinlama (masaustu + Android), telefon kurulum kodu, ekip surumleri."""

    def __init__(self, ebeveyn, app):
        super().__init__(ebeveyn)
        self.app = app
        self.acik = False
        self.kilit = ttk.Frame(self, padding=40)
        self.kilit.pack(fill="both", expand=True)
        self._kilit_ciz()

    # ------------------------------------------------------------ kilit
    @staticmethod
    def _ozet(sifre):
        import hashlib
        return hashlib.sha256(("GST|" + sifre).encode("utf-8")).hexdigest()

    def _kilit_ciz(self):
        for w in self.kilit.winfo_children():
            w.destroy()
        yeni = not self.app.ayar.get("yonetici_sifre")
        tk.Label(self.kilit, text="🛡  Yönetici", bg=ZEMIN, fg=TEAL_KOYU, font=("Segoe UI", 16, "bold")).pack(pady=(30, 6))
        tk.Label(self.kilit, text=("Bu bilgisayar için yönetici şifresi belirleyin." if yeni else
                                   "Güncelleme yayınlamak ve ekip ayarları için yönetici şifresini girin."),
                 bg=ZEMIN, fg=SOLUK, font=("Segoe UI", 10)).pack(pady=(0, 14))
        self.sifre = ttk.Entry(self.kilit, show="•", width=30, font=("Segoe UI", 11))
        self.sifre.pack()
        self.sifre2 = None
        if yeni:
            tk.Label(self.kilit, text="Tekrar", bg=ZEMIN, fg=SOLUK).pack(pady=(8, 0))
            self.sifre2 = ttk.Entry(self.kilit, show="•", width=30, font=("Segoe UI", 11))
            self.sifre2.pack()
        self.kilit_lbl = tk.Label(self.kilit, text="", bg=ZEMIN, fg=KIRMIZI)
        self.kilit_lbl.pack(pady=6)
        ttk.Button(self.kilit, text="Aç" if not yeni else "Şifreyi Belirle", style="Vurgu.TButton",
                   command=self._ac).pack()
        self.sifre.bind("<Return>", lambda e: self._ac())

    def _ac(self):
        s = self.sifre.get()
        if not self.app.ayar.get("yonetici_sifre"):
            if len(s) < 4:
                self.kilit_lbl.config(text="En az 4 karakter.")
                return
            if self.sifre2 is not None and s != self.sifre2.get():
                self.kilit_lbl.config(text="Şifreler aynı değil.")
                return
            self.app.ayar["yonetici_sifre"] = self._ozet(s)
            ayar_kaydet(self.app.ayar)
        elif self._ozet(s) != self.app.ayar["yonetici_sifre"]:
            self.kilit_lbl.config(text="Şifre yanlış.")
            return
        self.kilit.pack_forget()
        self._panel_ciz()
        self.acik = True

    def kilitle(self):
        if self.acik:
            self.panel.destroy()
            self.kilit.pack(fill="both", expand=True)
            self._kilit_ciz()
            self.acik = False

    # ------------------------------------------------------------ panel
    def _panel_ciz(self):
        a = self.app.ayar
        self.panel = ttk.Frame(self, padding=(18, 12))
        self.panel.pack(fill="both", expand=True)
        ust = ttk.Frame(self.panel)
        ust.pack(fill="x")
        tk.Label(ust, text="🛡  Yönetici", bg=ZEMIN, fg=TEAL_KOYU, font=("Segoe UI", 13, "bold")).pack(side="left")
        ttk.Button(ust, text="🔒 Kilitle", command=self.kilitle).pack(side="right")
        kolon = ttk.Frame(self.panel)
        kolon.pack(fill="both", expand=True, pady=(8, 0))
        sol = ttk.Frame(kolon)
        sol.pack(side="left", fill="both", expand=True)
        sag = ttk.Frame(kolon)
        sag.pack(side="left", fill="both", expand=True, padx=(18, 0))

        # ---- yayin
        y = ttk.LabelFrame(sol, text="  🚀 Güncelleme Yayınla  ", padding=12)
        y.pack(fill="x")
        self.yer = tk.StringVar(value=a.get("yayin_yeri", "github"))
        yr = ttk.Frame(y)
        yr.grid(row=0, column=0, columnspan=3, sticky="w")
        ttk.Label(yr, text="Yayın yeri:").pack(side="left")
        ttk.Radiobutton(yr, text="GitHub (önerilen)", value="github", variable=self.yer,
                        command=self._yer_degisti).pack(side="left", padx=8)
        ttk.Radiobutton(yr, text="Ortak klasör (Drive / OneDrive / ağ)", value="klasor", variable=self.yer,
                        command=self._yer_degisti).pack(side="left")
        # github
        self.gh = ttk.Frame(y)
        self.gh.grid(row=1, column=0, columnspan=3, sticky="w", pady=(8, 0))
        ttk.Label(self.gh, text="Kullanıcı adı").grid(row=0, column=0, sticky="w", pady=2, padx=(0, 8))
        self.gh_kul = ttk.Entry(self.gh, width=30)
        self.gh_kul.insert(0, a.get("github_kullanici", ""))
        self.gh_kul.grid(row=0, column=1, sticky="w")
        ttk.Label(self.gh, text="Depo adı").grid(row=1, column=0, sticky="w", pady=2, padx=(0, 8))
        self.gh_depo = ttk.Entry(self.gh, width=30)
        self.gh_depo.insert(0, a.get("github_depo", "gemi-sefer-takibi"))
        self.gh_depo.grid(row=1, column=1, sticky="w")
        ttk.Label(self.gh, text="Token").grid(row=2, column=0, sticky="w", pady=2, padx=(0, 8))
        self.gh_token = ttk.Entry(self.gh, width=46, show="•")
        self.gh_token.insert(0, bildirim.sifre_coz(a.get("github_token", "")))
        self.gh_token.grid(row=2, column=1, sticky="w")
        ttk.Button(self.gh, text="Bağlantıyı test et", command=self._gh_test).grid(row=2, column=2, padx=6)
        ttk.Label(self.gh, text="Token: github.com → Settings → Developer settings → Personal access tokens → Tokens (classic)\n"
                                "→ Generate new token → 'public_repo' kutusunu işaretleyin → Generate → kopyalayıp buraya yapıştırın.\n"
                                "Depo yoksa program oluşturur (herkese açık; içinde sadece güncelleme dosyaları olur).\n"
                                "Token bu bilgisayarda Windows ile şifreli saklanır.",
                  foreground=SOLUK, font=("Segoe UI", 8)).grid(row=3, column=0, columnspan=3, sticky="w", pady=(4, 0))
        # klasor
        self.kl = ttk.Frame(y)
        self.kl.grid(row=2, column=0, columnspan=3, sticky="w", pady=(8, 0))
        ttk.Label(self.kl, text="Yayın klasörü:").grid(row=0, column=0, sticky="w")
        self.yayin = ttk.Entry(self.kl, width=50)
        self.yayin.insert(0, a.get("yayin_klasoru", ""))
        self.yayin.grid(row=0, column=1, sticky="w", padx=6)
        ttk.Button(self.kl, text="Seç…", command=self._klasor_sec).grid(row=0, column=2, sticky="w")
        android = self._android_bilgi()
        bilgi = (f"Masaüstü: {SURUM}.{int(a.get('yayin_no', 0)) + 1} olarak yayınlanacak   •   "
                 + (f"Android: uygulama {android.get('apk_ad')} (kod {android.get('apk_surum')}), arayüz {android.get('web_surum')}"
                    if android else "Android paketi yok"))
        self.surum_lbl = ttk.Label(y, text=bilgi, foreground=SOLUK)
        self.surum_lbl.grid(row=3, column=0, columnspan=3, sticky="w", pady=(8, 0))
        ttk.Label(y, text="Sürüm notu (ekibe bildirimde görünür):").grid(row=4, column=0, columnspan=3, sticky="w", pady=(6, 0))
        self.notlar = tk.Text(y, width=64, height=2, font=("Segoe UI", 10), relief="solid", bd=1)
        self.notlar.grid(row=5, column=0, columnspan=3, sticky="w")
        yd = ttk.Frame(y)
        yd.grid(row=6, column=0, columnspan=3, sticky="w", pady=(10, 0))
        ttk.Button(yd, text="🚀 Güncelleme Yayınla", style="Vurgu.TButton", command=self._yayinla).pack(side="left")
        ttk.Button(yd, text="📱 Telefon Kurulum Kodu", style="Ana.TButton", command=self._telefon_kodu).pack(side="left", padx=6)
        ttk.Button(yd, text="APK'yı farklı kaydet…", command=self._apk_kaydet).pack(side="left")
        self.yayin_lbl = ttk.Label(y, text="", foreground=SOLUK, wraplength=560)
        self.yayin_lbl.grid(row=7, column=0, columnspan=3, sticky="w", pady=(6, 0))

        # ---- klasor modunda paylasim baglantilari
        b = ttk.LabelFrame(sol, text="  📱 Paylaşım bağlantıları (sadece ortak klasör için)  ", padding=12)
        self.baglanti_cerceve = b
        ttk.Label(b, text="Yayın klasöründeki dosyaya sağ tık → Paylaş → 'Bağlantıya sahip olan herkes' → Bağlantıyı kopyala.\n"
                          "Bir kez girilir; dosyalar yerinde güncellendiği için bağlantılar değişmez.",
                  foreground=SOLUK, font=("Segoe UI", 8)).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 6))
        self.linkler = {}
        for r, (k, ad) in enumerate([("link_surum_json", "surum.json"), ("link_apk", "GemiSeferTakibi.apk"),
                                     ("link_web", "index.html"), ("link_masaustu", "masaustu.zip (isteğe bağlı)")], 1):
            ttk.Label(b, text=ad).grid(row=r, column=0, sticky="w", pady=2, padx=(0, 8))
            e = ttk.Entry(b, width=58)
            e.insert(0, a.get(k, ""))
            e.grid(row=r, column=1, sticky="w", pady=2)
            self.linkler[k] = e
        ttk.Button(b, text="💾 Kaydet", command=self._linkleri_kaydet).grid(row=6, column=0, sticky="w", pady=(8, 0))
        self._yer_degisti()

        # ---- ekip
        e = ttk.LabelFrame(sag, text="  👥 Ekipteki programlar  ", padding=12)
        e.pack(fill="both", expand=True)
        c, self.ekip_tv = tablo_olustur(e, [("pc", "Bilgisayar", 130), ("kim", "Kullanıcı", 120),
                                           ("surum", "Sürüm", 70), ("zaman", "Son görülme", 120)], 10)
        c.pack(fill="both", expand=True)
        ed = ttk.Frame(e)
        ed.pack(fill="x", pady=(6, 0))
        ttk.Button(ed, text="⟳ Yenile", command=self.ekip_yenile).pack(side="left")
        self.kaynak_lbl = ttk.Label(e, text="", foreground=SOLUK, wraplength=420, font=("Segoe UI", 8))
        self.kaynak_lbl.pack(anchor="w", pady=(6, 0))
        self.durum_lbl = ttk.Label(e, text="", foreground=SOLUK, wraplength=420)
        self.durum_lbl.pack(anchor="w")
        self.ekip_yenile()

    def durum_yaz(self, metin):
        try:
            self.durum_lbl.config(text=metin)
        except (AttributeError, tk.TclError):
            pass

    def _android_bilgi(self):
        try:
            return json.load(open(os.path.join(PROGRAM_KLASOR, "android", "surum_bilgi.json"), encoding="utf-8"))
        except (OSError, ValueError):
            return {}

    def _yer_degisti(self):
        if self.yer.get() == "github":
            self.gh.grid()
            self.kl.grid_remove()
            self.baglanti_cerceve.pack_forget()
        else:
            self.gh.grid_remove()
            self.kl.grid()
            self.baglanti_cerceve.pack(fill="x", pady=(10, 0))

    def _gh_bilgi(self):
        return self.gh_kul.get().strip(), self.gh_depo.get().strip() or "gemi-sefer-takibi", self.gh_token.get().strip()

    def _gh_test(self):
        kul, depo, token = self._gh_bilgi()
        if not (kul and token):
            self.yayin_lbl.config(text="Kullanıcı adı ve token gerekli.", foreground=KIRMIZI)
            return
        self._linkleri_kaydet(sessiz=True)
        self.yayin_lbl.config(text="GitHub'a bağlanılıyor…", foreground=SOLUK)
        self.update_idletasks()
        try:
            ok, mesaj = guncelleme.github_test(kul, depo, token)
        except Exception as e:
            ok, mesaj = False, f"Bağlanılamadı: {e}"
        self.yayin_lbl.config(text=("✔ " if ok else "✖ ") + mesaj, foreground="#2E7D32" if ok else KIRMIZI)

    def surum_json_adresi(self):
        a = self.app.ayar
        if a.get("yayin_yeri", "github") == "github" and a.get("github_kullanici"):
            return guncelleme.github_raw(a["github_kullanici"], a.get("github_depo") or "gemi-sefer-takibi", "surum.json")
        return a.get("link_surum_json", "")

    def _klasor_sec(self):
        d = filedialog.askdirectory(parent=self, title="Yayın klasörünü seçin (ekibin ortak klasörü)")
        if d:
            self.yayin.delete(0, "end")
            self.yayin.insert(0, os.path.normpath(d))

    def _linkleri_kaydet(self, sessiz=False):
        for k, e in self.linkler.items():
            self.app.ayar[k] = e.get().strip()
        self.app.ayar["yayin_klasoru"] = self.yayin.get().strip()
        self.app.ayar["yayin_yeri"] = self.yer.get()
        kul, depo, token = self._gh_bilgi()
        self.app.ayar["github_kullanici"] = kul
        self.app.ayar["github_depo"] = depo
        self.app.ayar["github_token"] = bildirim.sifre_sakla(token)
        ayar_kaydet(self.app.ayar)
        if not sessiz:
            self.yayin_lbl.config(text="✔ Kaydedildi.", foreground="#2E7D32")

    def _yayinla(self):
        self._linkleri_kaydet(sessiz=True)
        a = self.app.ayar
        github = self.yer.get() == "github"
        kul, depo, token = self._gh_bilgi()
        klasor = self.yayin.get().strip()
        if github and not (kul and token):
            self.yayin_lbl.config(text="GitHub kullanıcı adı ve token girin.", foreground=KIRMIZI)
            return
        if not github and not klasor:
            self.yayin_lbl.config(text="Önce yayın klasörünü seçin.", foreground=KIRMIZI)
            return
        no = int(a.get("yayin_no", 0)) + 1
        surum = f"{SURUM}.{no}"
        notlar = self.notlar.get("1.0", "end").strip()
        hedef = f"github.com/{kul}/{depo}" if github else klasor
        if not messagebox.askyesno("Güncelleme Yayınla",
                                   f"Masaüstü {surum} ve Android paketi\n{hedef}\nadresine yayınlansın mı?\n\n"
                                   "Ekipteki programlar yarım saat içinde, telefonlar birkaç saat içinde güncellenir.",
                                   parent=self):
            return
        self.yayin_lbl.config(text="Yayınlanıyor…", foreground=SOLUK)
        self.update_idletasks()
        ek = {"firma": self.app.firma_adi(),
              "takip": [{"k": k, "ad": ad} for k, ad in self.app.izlenen_gemiler().items()]}
        try:
            if github:
                yazilan, bilgi, kaynak = guncelleme.github_yayinla(PROGRAM_KLASOR, kul, depo, token, surum, notlar, ek=ek)
            else:
                yazilan, bilgi = guncelleme.yayinla(PROGRAM_KLASOR, klasor, surum, notlar, {
                    "apk": a.get("link_apk"), "web": a.get("link_web"), "masaustu": a.get("link_masaustu")}, ek=ek)
                kaynak = klasor
        except Exception as e:
            self.yayin_lbl.config(text=f"✖ Yayınlanamadı: {e}", foreground=KIRMIZI)
            return
        a["yayin_no"] = no
        ayar_kaydet(a)
        self.surum_lbl.config(text=f"Son yayın: {surum}   •   Sonraki: {SURUM}.{no + 1}")
        try:
            self.app.vt.meta_yaz("guncelleme_kaynagi", kaynak)     # ekip programlari buradan okur
        except Exception:
            pass
        uyari = ""
        if not github and "GemiSeferTakibi.apk" in yazilan and not a.get("link_apk"):
            uyari = "\n⚠ Telefonların güncelleme alması için paylaşım bağlantılarını girin."
        self.yayin_lbl.config(text=f"✔ {surum} yayınlandı ({hedef}): {', '.join(yazilan)}{uyari}", foreground="#2E7D32")
        self.app.durum(f"🚀 Güncelleme yayınlandı: {surum}")
        self.notlar.delete("1.0", "end")
        self.ekip_yenile()

    def _telefon_kodu(self):
        self._linkleri_kaydet(sessiz=True)
        link = self.surum_json_adresi()
        if not link:
            messagebox.showwarning("Telefon Kurulum Kodu", "Önce GitHub bilgilerini (ya da surum.json paylaşım "
                                   "bağlantısını) girin.", parent=self)
            return
        takip = [{"k": k, "ad": ad} for k, ad in self.app.izlenen_gemiler().items()]
        kod = guncelleme.telefon_kodu(link, self.app.firma_adi(), takip)
        p = tk.Toplevel(self)
        p.title("Telefon Kurulum Kodu")
        p.configure(bg=KART)
        p.transient(self.app)
        tk.Label(p, text="  📱  Telefon Kurulum Kodu", bg=TEAL, fg="white", font=("Segoe UI", 12, "bold"),
                 anchor="w", pady=8).pack(fill="x")
        a = self.app.ayar
        apk_link = (guncelleme.github_raw(a["github_kullanici"], a.get("github_depo") or "gemi-sefer-takibi",
                                          "GemiSeferTakibi.apk")
                    if a.get("yayin_yeri", "github") == "github" and a.get("github_kullanici") else a.get("link_apk", ""))
        if apk_link:
            tk.Label(p, text="APK bağlantısı (telefonda açın):", bg=KART, padx=14, anchor="w").pack(fill="x", pady=(8, 0))
            ae = ttk.Entry(p, width=80)
            ae.insert(0, apk_link)
            ae.pack(padx=14, anchor="w")
        tk.Label(p, text="Uygulama güncelleme adresini, şirket adını ve takip listesini KENDİLİĞİNDEN alır;\n"
                         "çoğu zaman sadece APK'yı kurmak yeterlidir. Kod yalnızca farklı bir adres gerekirse kullanılır.\n\n"
                         "1) Telefona APK'yı kurun (yukarıdaki bağlantıyı telefonda açın).\n"
                         "2) Bu kodu kopyalayıp telefona gönderin (WhatsApp / e-posta).\n"
                         "3) Uygulamada Ayarlar → Kurulum kodu → yapıştır → Kodu Uygula.\n"
                         f"Kod; güncelleme adresini, şirket adını ve {len(takip)} takipteki gemiyi içerir.",
                 bg=KART, justify="left", padx=14, pady=8).pack(anchor="w")
        t = tk.Text(p, width=70, height=6, font=("Consolas", 9), wrap="char", relief="solid", bd=1)
        t.insert("1.0", kod)
        t.pack(padx=14)
        d = tk.Frame(p, bg=KART)
        d.pack(fill="x", padx=14, pady=10)

        def kopyala():
            p.clipboard_clear()
            p.clipboard_append(kod)
            lbl.config(text="✔ Panoya kopyalandı")
        ttk.Button(d, text="📋 Kopyala", style="Vurgu.TButton", command=kopyala).pack(side="left")
        lbl = tk.Label(d, text="", bg=KART, fg="#2E7D32")
        lbl.pack(side="left", padx=8)
        ttk.Button(d, text="Kapat", command=p.destroy).pack(side="right")
        ortala(p, self.app)

    def _apk_kaydet(self):
        apk = os.path.join(PROGRAM_KLASOR, "android", "GemiSeferTakibi.apk")
        if not os.path.exists(apk):
            messagebox.showinfo("APK", "Android paketi bulunamadı.", parent=self)
            return
        yol = filedialog.asksaveasfilename(parent=self, initialfile="GemiSeferTakibi.apk", defaultextension=".apk",
                                           filetypes=[("Android paketi", "*.apk")])
        if yol:
            shutil.copy2(apk, yol)
            self.yayin_lbl.config(text=f"✔ Kaydedildi: {yol}", foreground="#2E7D32")

    def ekip_yenile(self):
        try:
            self.ekip_tv.delete(*self.ekip_tv.get_children())
            for i, k in enumerate(self.app.vt.kurulumlar()):
                self.ekip_tv.insert("", "end", iid=str(i), values=(k["bilgisayar"], k["kullanici"], k["surum"], k["zaman"]))
        except Exception as e:
            self.durum_yaz(f"Ekip listesi okunamadı: {e}")
        kaynak = self.app.guncelleme_kaynagi()
        self.kaynak_lbl.config(text=f"Ekibin güncelleme kaynağı: {kaynak or '— (henüz yayın yapılmadı)'}\n"
                                    "Ekip listesi ortak veritabanından okunur; herkes aynı veritabanını kullanmalı.")


if __name__ == "__main__":
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
        # gorev cubugunda Python simgesi yerine programin kendi simgesi gorunsun
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("GemiSeferTakibi.Program")
    except Exception:
        pass
    kilit = TekKopya(None)
    if not kilit.kilitle(bekle=15 if "--yeniden" in sys.argv else 0):
        sys.exit(0)                         # zaten acik: o pencere one getirildi
    app = Uygulama(arkaplan="--arkaplan" in sys.argv)
    app.tek_kopya = kilit
    kilit.goster = lambda: app.kuyruk.put(("goster", None))
    app.mainloop()
