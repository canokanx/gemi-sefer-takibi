# -*- coding: utf-8 -*-
"""AISStream.io canli konum takibi (arka plan is parcacigi, TEK baglanti).

Ucretsiz anahtar: https://aisstream.io  (GitHub ile giris -> API Keys -> Create)

Ne dinlenir:
  * Calisma bolgesi (Marmara + Canakkale + Bogaz yaklasimlari) ve haritada bakilan bolge:
    o kutulardaki BUTUN gemiler (bellekte tutulur, haritada kucuk gemi simgesi).
  * Bizim gemilerimiz (MMSI'si girili olanlar): veritabanina yazilir.
  * Konumu bilinmeyen gemilerimiz icin 10 dakikada bir 2 dakikalik "dunya geneli arama".
  * Konumu bilinen ama bolge disindaki gemilerimiz icin etraflarinda kucuk bir kutu.
  * Gemi tanitim mesajinda (ShipStaticData) IMO'su bizim MMSI'siz gemilerden birine uyarsa
    MMSI kendiliginden ogrenilir.
"""
import asyncio
import json
import threading
import time
import datetime as dt

try:
    import websockets
except ImportError:          # program websockets olmadan da acilir, AIS kapali kalir
    websockets = None

URL = "wss://stream.aisstream.io/v0/stream"
KONUM_TIPLERI = ["PositionReport", "StandardClassBPositionReport", "ExtendedClassBPositionReport"]
STATIK_TIPLER = ["ShipStaticData", "StaticDataReport"]
CALISMA_BOLGESI = [[39.6, 25.3], [41.8, 30.5]]
DUNYA = [[-90, -180], [90, 180]]
MAKS_GORUNUM_DERECE = 7.0        # bundan buyuk harita gorunumunde "tum gemiler" abonesi yapilmaz
KESIF_ARALIK = 900               # sn (konumu bilinmeyen gemilerimiz icin dunya geneli kisa arama)
KESIF_SURE = 45                  # sn
ONBELLEK_OMUR = 2700             # sn; acilista bundan eski konumlar yuklenmez
CANLI_OMUR = 1800                # sn; bu kadar mesaj gelmeyen yabanci gemi silinir
VT_YAZMA_ARALIK = 15             # sn; ayni gemiyi veritabanina en sik bu aralikla yaz
STATIK_ARAMA_SURE = 480          # sn; IMO ile dunya genelinde tanitim mesaji arama suresi

NAV_DURUM = {
    0: "Seyirde (makine)", 1: "Demirde", 2: "Kumanda dışı", 3: "Manevra kısıtlı",
    4: "Su çekimi kısıtlı", 5: "Bağlı (rıhtım)", 6: "Karaya oturmuş", 7: "Balıkçılık",
    8: "Seyirde (yelken)", 15: "Belirtilmemiş",
}


from gemi_bilgi import ais_tip_adi as gemi_tipi_adi, mmsi_bayrak  # noqa: E402


def mesaj_zamani(meta):
    """MetaData.time_utc ('2026-10-18 00:09:43.4978 +0000 UTC') -> epoch saniye; olmazsa simdi.
    Bilgisayar saati yanlissa (10 dk'dan fazla fark) mesajin geldigi an kullanilir."""
    simdi = time.time()
    z = str((meta or {}).get("time_utc") or "")
    try:
        t = dt.datetime.strptime(z[:19], "%Y-%m-%d %H:%M:%S").replace(tzinfo=dt.timezone.utc).timestamp()
        if len(z) > 20 and z[19] == ".":
            kesir = "".join(ch for ch in z[20:29] if ch.isdigit())
            t += float("0." + kesir) if kesir else 0.0
    except ValueError:
        return simdi
    if t > simdi + 5 or simdi - t > 600:
        return simdi
    return t


def yon(hdg, cog):
    """Simgenin donecegi yon: once pruva (TrueHeading), yoksa rota (COG)."""
    try:
        if hdg is not None and 0 <= float(hdg) < 360:
            return float(hdg)
    except (TypeError, ValueError):
        pass
    try:
        if cog is not None and 0 <= float(cog) < 360:
            return float(cog)
    except (TypeError, ValueError):
        pass
    return 0.0


class AISTakip:
    def __init__(self, vt_fabrika, anahtar, durum_bildir, olay_bildir=None, rehber=None, onbellek_yolu=None):
        """vt_fabrika(): her cagrida yeni Veritabani (thread guvenli).
        durum_bildir(metin): durum cubuguna yazi.  olay_bildir(tur, veri): 'mmsi_ogrenildi' gibi olaylar."""
        self.vt_fabrika = vt_fabrika
        self.anahtar = (anahtar or "").strip()
        self.bildir = durum_bildir
        self.olay = olay_bildir or (lambda *a: None)
        self._dur = threading.Event()
        self._degisti = threading.Event()
        self.thread = None
        self.kilit = threading.Lock()
        self.canli = {}            # mmsi -> {lat, lon, sog, cog, hdg, nav, ad, imo, tip, varis, t}
        self.imo_mmsi = {}         # statik mesajlardan ogrenilen IMO -> MMSI
        self.gorunum = None        # [[lat_min, lon_min], [lat_max, lon_max]]
        self.filo = {}             # bizim gemiler: mmsi -> ad
        self.filo_konum = {}       # mmsi -> (lat, lon, zaman_str)
        self.mmsisiz = {}          # imo -> gemi_id (MMSI'si olmayan gemilerimiz)
        self._son_vt_yazma = {}
        self.mesaj_sayisi = 0
        self.kesifte = False
        self.rehber = rehber
        self.aranan_imo = {}       # imo -> istek zamani (dunya geneli tanitim mesaji aramasi)
        self.statikte = False
        self.gecici = {}           # mmsi -> istek zamani (Takibe Al)
        self._kesif_simdi = False
        self.onbellek_yolu = onbellek_yolu
        self.onbellek_yukle()

    # ------------------------------------------------------------ dis arayuz
    def baslat(self):
        if websockets is None:
            self.bildir("AIS kapalı: 'websockets' kurulu değil (KURULUM.ps1 → sağ tık → PowerShell ile çalıştır)")
            return
        if not self.anahtar:
            self.bildir("AIS kapalı: Ayarlar'dan AISStream anahtarı girin")
            return
        self.thread = threading.Thread(target=self._calis, daemon=True)
        self.thread.start()

    def durdur(self):
        self._dur.set()
        self.onbellek_kaydet()

    # ------------------------------------------------------------ konum onbellegi
    def onbellek_yukle(self):
        """Son kapanistaki gemi konumlarini yukle: program acilir acilmaz gemiler haritada olur."""
        if not self.onbellek_yolu:
            return
        try:
            with open(self.onbellek_yolu, "r", encoding="utf-8") as f:
                veri = json.load(f)
        except (OSError, ValueError):
            return
        simdi = time.time()
        with self.kilit:
            for mmsi, k in (veri.get("canli") or {}).items():
                if isinstance(k, dict) and k.get("lat") is not None and simdi - float(k.get("t") or 0) < ONBELLEK_OMUR:
                    self.canli.setdefault(mmsi, k)
        self.imo_mmsi.update(veri.get("imo_mmsi") or {})

    def onbellek_kaydet(self):
        if not self.onbellek_yolu:
            return
        try:
            veri = {"canli": self.canli_kopya(), "imo_mmsi": dict(self.imo_mmsi)}
            gecici = self.onbellek_yolu + ".tmp"
            with open(gecici, "w", encoding="utf-8") as f:
                json.dump(veri, f, ensure_ascii=False)
            import os
            os.replace(gecici, self.onbellek_yolu)
        except Exception:
            pass

    def listeyi_yenile(self):
        """Gemi listesi degisince cagrilir."""
        self._degisti.set()

    def gorunum_ayarla(self, lat1, lon1, lat2, lon2):
        lat_min, lat_max = sorted((lat1, lat2))
        lon_min, lon_max = sorted((lon1, lon2))
        if lat_max - lat_min > MAKS_GORUNUM_DERECE or lon_max - lon_min > MAKS_GORUNUM_DERECE:
            yeni = None
        else:
            pay = 0.15
            yeni = [[round(lat_min - pay, 2), round(lon_min - pay, 2)],
                    [round(lat_max + pay, 2), round(lon_max + pay, 2)]]
        if yeni != self.gorunum:
            eski = self.gorunum
            self.gorunum = yeni
            # kucuk kaymalarda aboneligi yenileme
            if eski is None or yeni is None or not self._icinde(yeni, eski):
                self._degisti.set()

    def gecici_takip(self, mmsi):
        """Listede olmayan bir gemiyi kisa sureli dunya geneli aramaya al (konumu gelince olay bildirilir)."""
        self.gecici[str(mmsi)] = time.time()
        self._kesif_simdi = True
        self._degisti.set()

    def imo_ara(self, imo):
        """Bu IMO'nun tanitim mesajini dunya genelinde ara (birkac dakika surer)."""
        imo = str(imo)
        if imo not in self.aranan_imo:
            self.aranan_imo[imo] = time.time()
            self._degisti.set()

    def canli_kopya(self):
        with self.kilit:
            return {k: dict(v) for k, v in self.canli.items()}

    def tum_gemiler_aktif(self):
        return self.gorunum is not None

    def _bolgede(self, lat, lon):
        for k in ([CALISMA_BOLGESI] + ([self.gorunum] if self.gorunum else [])):
            if k[0][0] <= lat <= k[1][0] and k[0][1] <= lon <= k[1][1]:
                return True
        return False

    @staticmethod
    def _icinde(ic, dis):
        return (dis[0][0] <= ic[0][0] and dis[0][1] <= ic[0][1] and
                ic[1][0] <= dis[1][0] and ic[1][1] <= dis[1][1])

    # ------------------------------------------------------------ ic isler
    def _filoyu_oku(self, vt):
        self.filo = vt.takip_mmsileri()
        self.filo_konum = {k["mmsi"]: (k["lat"], k["lon"], k.get("zaman") or "") for k in vt.ais_konumlar()}
        self.mmsisiz = {g["imo"]: g["id"] for g in vt.mmsisiz_gemiler() if g.get("imo")}
        # bellekte zaten IMO'su bilinen gemi varsa hemen esle
        for imo, gid in list(self.mmsisiz.items()):
            mmsi = self.imo_mmsi.get(imo)
            if mmsi:
                self._mmsi_ogren(vt, gid, imo, mmsi)

    def _kayip_filo(self):
        """Konumu hic bilinmeyen ya da 2 saatten eski gemilerimiz (+ Takibe Al ile istenenler)."""
        simdi = time.time()
        for m in [m for m, t0 in self.gecici.items() if simdi - t0 > 1800]:
            del self.gecici[m]
        kayip = [m for m in self.gecici if not (self.canli.get(m) or {}).get("lat")]
        sinir = dt.datetime.now() - dt.timedelta(hours=2)
        for mmsi in self.filo:
            k = self.filo_konum.get(mmsi)
            if not k:
                kayip.append(mmsi)
                continue
            try:
                if dt.datetime.strptime(k[2], "%d.%m.%Y %H:%M") < sinir:
                    kayip.append(mmsi)
            except ValueError:
                kayip.append(mmsi)
        return kayip

    def _abonelik(self):
        if self.statikte and self.aranan_imo:
            # dunya geneli tanitim mesaji + konumlar; bolge disindaki konumlar _isle'de atilir
            return {"APIKey": self.anahtar, "BoundingBoxes": [DUNYA],
                    "FilterMessageTypes": KONUM_TIPLERI + ["ShipStaticData"]}
        if self.kesifte:
            kayip = self._kayip_filo()[:50]
            if kayip:
                return {"APIKey": self.anahtar, "BoundingBoxes": [DUNYA],
                        "FiltersShipMMSI": kayip, "FilterMessageTypes": KONUM_TIPLERI}
            self.kesifte = False
        kutular = [CALISMA_BOLGESI]
        if self.gorunum and not self._icinde(self.gorunum, CALISMA_BOLGESI):
            kutular.append(self.gorunum)
        for mmsi, (lat, lon, _) in self.filo_konum.items():
            if mmsi not in self.filo or lat is None or len(kutular) >= 12:
                continue
            nokta = [[lat, lon], [lat, lon]]
            if any(self._icinde(nokta, k) for k in kutular):
                continue
            kutular.append([[lat - 1.0, lon - 1.0], [lat + 1.0, lon + 1.0]])
        return {"APIKey": self.anahtar, "BoundingBoxes": kutular,
                "FilterMessageTypes": KONUM_TIPLERI + STATIK_TIPLER}

    def _calis(self):
        bekleme = 5
        while not self._dur.is_set():
            try:
                asyncio.run(self._baglan())
                bekleme = 5
            except Exception as e:  # baglanti koptu -> tekrar dene
                self.bildir(f"AIS bağlantı hatası: {str(e)[:90]} — {bekleme} sn sonra tekrar")
            if self._dur.wait(bekleme):
                break
            bekleme = min(bekleme * 2, 120)

    async def _baglan(self):
        vt = self.vt_fabrika()
        self._filoyu_oku(vt)
        async with websockets.connect(URL, open_timeout=15, ping_interval=30, max_size=2 ** 22) as ws:
            await ws.send(json.dumps(self._abonelik()))
            self._degisti.clear()
            self._durum_yaz()
            son_filo = son_temizlik = time.time()
            son_kesif = time.time() - KESIF_ARALIK + 90     # acilistan 90 sn sonra (once bolge dolsun)
            son_kayit = time.time()
            kesif_basi = statik_basi = 0
            while not self._dur.is_set():
                simdi = time.time()
                yenile = False
                if self._degisti.is_set():
                    self._degisti.clear()
                    self._filoyu_oku(vt)
                    son_filo = simdi
                    yenile = True
                if simdi - son_filo > 60:
                    son_filo = simdi
                    eski = (set(self.filo), len(self.filo_konum))
                    self._filoyu_oku(vt)
                    yenile = yenile or eski[0] != set(self.filo)
                if self.aranan_imo and not self.statikte:
                    self.statikte, statik_basi, yenile = True, simdi, True
                elif self.statikte:
                    for imo in [i for i, t0 in self.aranan_imo.items() if simdi - t0 > STATIK_ARAMA_SURE]:
                        del self.aranan_imo[imo]
                        self.olay("imo_bulunamadi", {"imo": imo})
                    if not self.aranan_imo:
                        self.statikte, yenile = False, True
                if self.statikte:
                    pass
                elif not self.kesifte and (self._kesif_simdi or simdi - son_kesif > KESIF_ARALIK) and self._kayip_filo():
                    self._kesif_simdi = False
                    self.kesifte, kesif_basi, yenile = True, simdi, True
                elif self.kesifte and (simdi - kesif_basi > KESIF_SURE or not self._kayip_filo()):
                    self.kesifte, son_kesif, yenile = False, simdi, True
                if yenile:
                    await ws.send(json.dumps(self._abonelik()))   # ayni baglantida abonelik guncellenir
                    self._durum_yaz()
                if simdi - son_kayit > 60:
                    son_kayit = simdi
                    self.onbellek_kaydet()
                if simdi - son_temizlik > 60:
                    son_temizlik = simdi
                    with self.kilit:
                        for m in [m for m, v in self.canli.items()
                                  if simdi - v["t"] > CANLI_OMUR and m not in self.filo]:
                            del self.canli[m]
                try:
                    ham = await asyncio.wait_for(ws.recv(), timeout=1)
                except asyncio.TimeoutError:
                    continue
                self._isle(vt, ham)

    def _durum_yaz(self):
        if self.statikte:
            self.bildir(f"AIS bağlı — IMO {', '.join(list(self.aranan_imo)[:3])} dünya genelinde aranıyor (birkaç dk)…")
        elif self.kesifte:
            self.bildir(f"AIS bağlı — konumu bilinmeyen {len(self._kayip_filo())} gemi dünya genelinde aranıyor…")
        else:
            ek = "bölgedeki tüm gemiler" if self.gorunum else "Marmara bölgesi"
            self.bildir(f"AIS bağlı — {len(self.filo)} gemimiz izleniyor, {ek} gösteriliyor")

    def _mmsi_ogren(self, vt, gid, imo, mmsi, ad="", tip=None):
        try:
            vt.gemi_bilgi_doldur(gid, mmsi=mmsi, ad=ad, bayrak=mmsi_bayrak(mmsi), tip=gemi_tipi_adi(tip))
        except Exception:
            return
        self.mmsisiz.pop(imo, None)
        self.filo = vt.takip_mmsileri()
        self.olay("mmsi_ogrenildi", {"gemi_id": gid, "imo": imo, "mmsi": mmsi})

    def _isle(self, vt, ham):
        try:
            if isinstance(ham, bytes):
                ham = ham.decode("utf-8", "ignore")
            m = json.loads(ham)
        except ValueError:
            return
        if "error" in m:
            raise RuntimeError(m.get("error"))
        tip = m.get("MessageType")
        govde = (m.get("Message") or {}).get(tip) or {}
        meta = m.get("MetaData") or m.get("Metadata") or {}
        mmsi = str(meta.get("MMSI") or govde.get("UserID") or "")
        if not mmsi:
            return
        ad = (meta.get("ShipName") or "").strip()
        self.mesaj_sayisi += 1

        if tip in STATIK_TIPLER:
            imo = govde.get("ImoNumber")
            if tip == "StaticDataReport":
                imo = None
                ad = ad or ((govde.get("ReportA") or {}).get("Name") or "").strip()
            imo = str(imo) if imo and str(imo).isdigit() and len(str(imo)) == 7 else ""
            if self.rehber:
                boyut = govde.get("Dimension") or {}
                try:
                    boy = (float(boyut.get("A") or 0) + float(boyut.get("B") or 0)) or None
                    en = (float(boyut.get("C") or 0) + float(boyut.get("D") or 0)) or None
                except (TypeError, ValueError):
                    boy = en = None
                try:
                    draft = float(govde.get("MaximumStaticDraught") or 0) or None
                except (TypeError, ValueError):
                    draft = None
                e = govde.get("Eta") or {}
                eta = ""
                try:
                    if int(e.get("Month") or 0) and int(e.get("Day") or 0):
                        eta = f"{int(e['Day']):02d}.{int(e['Month']):02d} {int(e.get('Hour') or 0):02d}:{int(e.get('Minute') or 0):02d}"
                except (TypeError, ValueError):
                    eta = ""
                self.rehber.kaydet(mmsi, imo, (govde.get("Name") or ad or ""), govde.get("Type"),
                                   govde.get("CallSign") or "", boy, en, draft,
                                   str(govde.get("Destination") or "").strip().strip("@").strip(), eta)
            with self.kilit:
                k = self.canli.setdefault(mmsi, {"t": time.time()})
                if ad or govde.get("Name"):
                    k["ad"] = ad or (govde.get("Name") or "").strip()
                if imo:
                    k["imo"] = imo
                if govde.get("Type") is not None:
                    k["tip"] = govde.get("Type")
                if govde.get("Destination"):
                    k["varis"] = str(govde.get("Destination")).strip()
            if imo:
                self.imo_mmsi[imo] = mmsi
                ad_t = (govde.get("Name") or ad or "").strip().strip("@").strip()
                if imo in self.mmsisiz:
                    self._mmsi_ogren(vt, self.mmsisiz[imo], imo, mmsi, ad_t, govde.get("Type"))
                if imo in self.aranan_imo:
                    del self.aranan_imo[imo]
                    self.olay("imo_bulundu", {"imo": imo, "mmsi": mmsi, "ad": ad_t, "tip": govde.get("Type"),
                                              "bayrak": mmsi_bayrak(mmsi)})
                    if not self.aranan_imo:
                        self._degisti.set()
            return

        if tip not in KONUM_TIPLERI:
            return
        lat = govde.get("Latitude", meta.get("latitude"))
        lon = govde.get("Longitude", meta.get("longitude"))
        if lat is None or lon is None or abs(lat) > 90 or abs(lon) > 180:   # 91/181 = konum yok
            return
        if self.statikte and mmsi not in self.filo and not self._bolgede(lat, lon):
            return          # dunya geneli arama sirasinda uzak gemileri bellege alma
        sog, cog, hdg = govde.get("Sog"), govde.get("Cog"), govde.get("TrueHeading")
        nav = govde.get("NavigationalStatus")
        simdi = time.time()
        t_msg = mesaj_zamani(meta)
        with self.kilit:
            k = self.canli.setdefault(mmsi, {})
            # farkli istasyonlardan gec gelen ESKI konum mesajini at (gemi geri ziplamasin)
            if k.get("t") and k.get("lat") is not None and t_msg < k["t"] - 0.5:
                return
            k.update({"lat": float(lat), "lon": float(lon), "sog": sog, "cog": cog, "hdg": hdg,
                      "t": t_msg})
            if nav is not None:
                k["nav"] = nav
            if ad:
                k["ad"] = ad
        if ad and self.rehber:
            self.rehber.kaydet(mmsi, ad=ad)
        if mmsi in self.gecici:
            del self.gecici[mmsi]
            self.olay("gecici_bulundu", mmsi)
        if mmsi in self.filo and simdi - self._son_vt_yazma.get(mmsi, 0) > VT_YAZMA_ARALIK:
            self._son_vt_yazma[mmsi] = simdi
            zaman = dt.datetime.now().strftime("%d.%m.%Y %H:%M")
            vt.ais_kaydet(mmsi, ad or self.filo.get(mmsi, ""), float(lat), float(lon), sog, cog, nav, zaman, hdg)
            self.filo_konum[mmsi] = (float(lat), float(lon), zaman)
