# -*- coding: utf-8 -*-
"""Bogaz listesindeki takip edilen gemilerin statusu degisince e-posta.

- degisiklikleri_bul(): onceki ve yeni liste arasinda takipteki gemilerin degisimleri
  (durum, planlama zamani, listeye girme, listeden cikma).
- Gonderim iki yolla: Outlook (bilgisayardaki Outlook hesabi, sifre gerekmez) ya da SMTP (Gmail vb.).
- SMTP sifresi ayar dosyasinda Windows'un kendi sifrelemesiyle (DPAPI) saklanir.
"""
import os
import sys
import json
import base64
import smtplib
import subprocess
import datetime as dt
from email.message import EmailMessage

BOGAZ_AD = {"I": "İstanbul", "C": "Çanakkale"}
YON_AD = {"KG": "Kuzey → Güney", "GK": "Güney → Kuzey", "NS": "Kuzey → Güney", "SN": "Güney → Kuzey"}

SMTP_HAZIR = {
    "Gmail": ("smtp.gmail.com", 587),
    "Outlook.com / Office 365": ("smtp.office365.com", 587),
    "Yandex": ("smtp.yandex.com", 587),
    "Özel": ("", 587),
}


# ====================================================================== degisiklik bulma
def anlik_durum(veri, izlenen):
    """izlenen: {anahtar(imo|mmsi): ad}. Donus: {anahtar: {bogaz, sira, durum, plan, yon, ad, imo, mmsi}}"""
    sonuc = {}
    for kod in ("I", "C"):
        for i, s in enumerate(veri.get(kod) or [], 1):
            for anahtar in (s.get("imo"), s.get("mmsi")):
                if anahtar and anahtar in izlenen and anahtar not in sonuc:
                    sonuc[anahtar] = {"bogaz": kod, "sira": i, "durum": s.get("durum") or "",
                                      "plan": s.get("plan_zamani") or "", "yon": s.get("yon") or "",
                                      "ad": s.get("ad") or izlenen[anahtar], "imo": s.get("imo") or "",
                                      "mmsi": s.get("mmsi") or ""}
                    break
    return sonuc


def degisiklikleri_bul(onceki, simdi, izlenen):
    """onceki/simdi: anlik_durum() ciktisi. Donus: [{tur, ad, ...}] (tur: girdi | degisti | cikti)"""
    olaylar = []
    for k in izlenen:
        e, y = onceki.get(k), simdi.get(k)
        if e is None and y is None:
            continue
        if e is None:
            olaylar.append({"tur": "girdi", **y})
        elif y is None:
            olaylar.append({"tur": "cikti", **e})
        elif (e["durum"], e["plan"], e["bogaz"]) != (y["durum"], y["plan"], y["bogaz"]):
            olaylar.append({"tur": "degisti", **y, "eski_durum": e["durum"], "eski_plan": e["plan"],
                            "eski_bogaz": e["bogaz"]})
    return olaylar


def marmaraya_giriyor(o):
    """Canakkale'de Guney->Kuzey ya da Istanbul'da Kuzey->Guney: gemi Marmara'ya geliyor."""
    return (o.get("bogaz") == "C" and o.get("yon") in ("SN", "GK")) or \
        (o.get("bogaz") == "I" and o.get("yon") in ("NS", "KG"))


def olay_metni(o):
    kim = f"{o['ad']}  (IMO {o.get('imo') or '-'}, MMSI {o.get('mmsi') or '-'})"
    if o["tur"] == "ais":
        satir = [f"📡 {kim}"]
        if o.get("eski_varis") != o.get("varis"):
            satir.append(f"   AIS varış limanı: {o.get('eski_varis') or '-'}  →  {o.get('varis') or '-'}")
        if o.get("eski_eta") != o.get("eta"):
            satir.append(f"   AIS ETA: {o.get('eski_eta') or '-'}  →  {o.get('eta') or '-'}")
        return "\n".join(satir)
    bogaz = f"{BOGAZ_AD.get(o['bogaz'], o['bogaz'])} Boğazı"
    yon = f" ({YON_AD[o['yon']]})" if o.get("yon") in YON_AD else ""
    if o["tur"] == "girdi":
        ek = "\n   ➜ Gemi Marmara'ya geliyor" if marmaraya_giriyor(o) else ""
        return (f"🆕 {kim}\n   {bogaz} geçiş listesine girdi{yon}{ek}\n"
                f"   Durum: {o['durum'] or '-'}   Planlama: {o['plan'] or '-'}   Sıra: {o['sira']}")
    if o["tur"] == "cikti":
        return (f"✅ {kim}\n   {bogaz} listesinden çıktı (geçişini tamamlamış olabilir)\n"
                f"   Son durum: {o['durum'] or '-'}   Planlama: {o['plan'] or '-'}")
    isaret = "⚓" if o["durum"] == "BOĞAZDA" else "🔔"
    satir = [f"{isaret} {kim}", f"   {bogaz}{yon}   Sıra: {o['sira']}"]
    if o["durum"] == "BOĞAZDA" and o["eski_durum"] != "BOĞAZDA":
        satir.append("   ➜ Gemi şu an boğazdan geçiyor")
    if o["eski_durum"] != o["durum"]:
        satir.append(f"   Durum: {o['eski_durum'] or '-'}  →  {o['durum'] or '-'}")
    else:
        satir.append(f"   Durum: {o['durum'] or '-'}")
    if o["eski_plan"] != o["plan"]:
        satir.append(f"   Planlama: {o['eski_plan'] or '-'}  →  {o['plan'] or '-'}")
    else:
        satir.append(f"   Planlama: {o['plan'] or '-'}")
    if o["eski_bogaz"] != o["bogaz"]:
        satir.append(f"   Boğaz: {BOGAZ_AD.get(o['eski_bogaz'])} → {BOGAZ_AD.get(o['bogaz'])}")
    return "\n".join(satir)


def mail_icerigi(olaylar, liste_zamani="", imza="— Gemi Sefer Takibi", firma=""):
    if len(olaylar) == 1:
        o = olaylar[0]
        ne = {"girdi": "Marmara'ya geliyor" if marmaraya_giriyor(o) else "listeye girdi",
              "cikti": "listeden çıktı", "ais": "AIS varış/ETA değişti"}.get(o["tur"], o.get("durum") or "durum değişti")
        konu = f"⚓ Boğaz: {o['ad']} — {ne}"
    else:
        konu = f"⚓ Boğaz: {len(olaylar)} takipteki gemide değişiklik"
    if firma:
        konu = f"[{firma}] {konu}"
    govde = ("Kıyı Emniyeti boğaz geçiş listesinde takip ettiğiniz gemilerde değişiklik var:\n\n"
             + "\n\n".join(olay_metni(o) for o in olaylar)
             + f"\n\nListe zamanı: {liste_zamani or '-'}"
             + f"\nKontrol: {dt.datetime.now():%d.%m.%Y %H:%M}"
             + "\n\n" + imza)
    return konu, govde


# ====================================================================== sifre saklama (DPAPI)
def sifre_sakla(duz):
    if not duz:
        return ""
    ham = duz.encode("utf-8")
    if os.name == "nt":
        try:
            return "dpapi:" + base64.b64encode(_dpapi(ham, True)).decode()
        except Exception:
            pass
    return "b64:" + base64.b64encode(ham).decode()


def sifre_coz(saklanan):
    if not saklanan:
        return ""
    try:
        if saklanan.startswith("dpapi:"):
            return _dpapi(base64.b64decode(saklanan[6:]), False).decode("utf-8")
        if saklanan.startswith("b64:"):
            return base64.b64decode(saklanan[4:]).decode("utf-8")
    except Exception:
        return ""
    return saklanan


def _dpapi(veri, sifrele):
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]
    tampon = ctypes.create_string_buffer(veri, len(veri))
    giris = BLOB(len(veri), ctypes.cast(tampon, ctypes.POINTER(ctypes.c_char)))
    cikis = BLOB()
    crypt = ctypes.windll.crypt32
    f = crypt.CryptProtectData if sifrele else crypt.CryptUnprotectData
    if not f(ctypes.byref(giris), None, None, None, None, 0, ctypes.byref(cikis)):
        raise OSError("DPAPI hatası")
    try:
        return ctypes.string_at(cikis.pbData, cikis.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(cikis.pbData)


# ====================================================================== gonderim
def alicilari_coz(metin):
    return [a.strip() for a in (metin or "").replace(";", ",").split(",") if "@" in a]


def gonder(ayar, konu, govde, html=None, alicilar=None):
    """ayar: program ayarlari. html: istege bagli HTML govde. alicilar: verilmezse ayarlardaki.
    Hata olursa Exception firlatir."""
    alicilar = alicilari_coz(alicilar) if isinstance(alicilar, str) else (alicilar or
                                                                         alicilari_coz(ayar.get("mail_alicilar")))
    if not alicilar:
        raise ValueError("E-posta alıcısı yok (Ayarlar → Alıcılar)")
    if ayar.get("mail_yontem", "Outlook") == "Outlook":
        _outlook_gonder(alicilar, konu, govde, html)
    else:
        _smtp_gonder(ayar, alicilar, konu, govde, html)


def _outlook_gonder(alicilar, konu, govde, html=None):
    if os.name != "nt":
        raise RuntimeError("Outlook sadece Windows'ta")
    try:
        import win32com.client  # noqa: F401
    except ImportError:
        py = sys.executable
        if py.lower().endswith("pythonw.exe"):
            py = py[:-len("pythonw.exe")] + "python.exe"
        subprocess.run([py, "-m", "pip", "install", "--quiet", "--disable-pip-version-check", "pywin32"],
                       creationflags=0x08000000, timeout=300)
        try:
            import win32com.client  # noqa: F401
        except ImportError:
            raise RuntimeError("Outlook bağlantısı için 'pywin32' kurulamadı. Programı yeniden başlatıp tekrar deneyin "
                               "ya da Ayarlar'dan SMTP (Gmail) seçin.")
    import pythoncom
    import win32com.client
    pythoncom.CoInitialize()
    try:
        try:
            ol = win32com.client.Dispatch("Outlook.Application")
        except Exception:
            raise RuntimeError("Klasik Outlook bulunamadı (Yeni Outlook bu yolu desteklemez). "
                               "Ayarlar'dan SMTP (Gmail) seçin.")
        m = ol.CreateItem(0)
        m.To = "; ".join(alicilar)
        m.Subject = konu
        if html:
            m.HTMLBody = html
        else:
            m.Body = govde
        m.Send()
    finally:
        pythoncom.CoUninitialize()


def _smtp_gonder(ayar, alicilar, konu, govde, html=None):
    sunucu = (ayar.get("smtp_sunucu") or "").strip()
    port = int(ayar.get("smtp_port") or 587)
    kul = (ayar.get("smtp_kullanici") or "").strip()
    sifre = sifre_coz(ayar.get("smtp_sifre", ""))
    if not (sunucu and kul and sifre):
        raise ValueError("SMTP sunucusu, kullanıcı ve şifre Ayarlar'da girilmeli")
    msg = EmailMessage()
    msg["From"] = kul
    msg["To"] = ", ".join(alicilar)
    msg["Subject"] = konu
    msg.set_content(govde)
    if html:
        msg.add_alternative(html, subtype="html")
    if port == 465:
        with smtplib.SMTP_SSL(sunucu, port, timeout=30) as s:
            s.login(kul, sifre)
            s.send_message(msg)
    else:
        with smtplib.SMTP(sunucu, port, timeout=30) as s:
            s.starttls()
            s.login(kul, sifre)
            s.send_message(msg)


# ====================================================================== takip durumu dosyasi
def _ais_temiz(varis, eta):
    """Karsilastirma icin: VesselFinder'in 'Destination not available' ve limana varis (ATA) bilgisi
    varis/ETA sayilmaz (eski surumler bunlari ETA diye kaydediyordu; yanlis 'degisti' maili gitmesin)."""
    v, e = (varis or "").strip(), (eta or "").strip()
    if "not available" in v.lower():
        v = ""
    if e.upper().startswith("ATA"):
        e = ""
    return v, e


class TakipDurumu:
    """Son bilinen durumlar diske yazilir: program kapanip acilinca ayni degisiklik icin tekrar mail gitmez."""

    def __init__(self, yol):
        self.yol = yol
        self.onceki = None
        try:
            with open(yol, "r", encoding="utf-8") as f:
                self.onceki = json.load(f)
        except (OSError, ValueError):
            pass

    def guncelle(self, veri, izlenen, ais=None):
        """Yeni listeyi isle; mail gerektiren olaylari dondur.
        ais: {anahtar: {'varis':.., 'eta':.., 'ad':.., 'imo':.., 'mmsi':..}} takipteki gemilerin AIS bilgisi"""
        simdi = anlik_durum(veri, izlenen)
        if self.onceki is None:
            olaylar = []                      # ilk calisma: sadece hafizaya al
        else:
            onceki = {k: v for k, v in self.onceki.items() if k in izlenen and not k.startswith("_")}
            # yeni takibe alinan gemi listede zaten varsa "girdi" maili atma
            yeni_takip = set(izlenen) - set(self.onceki.get("_izlenen_", []))
            for k in yeni_takip:
                if k in simdi:
                    onceki[k] = simdi[k]
            olaylar = degisiklikleri_bul(onceki, simdi, izlenen)
        eski_ais = (self.onceki or {}).get("_ais_") or {}
        yeni_ais = dict(eski_ais)
        for k, a in (ais or {}).items():
            if k not in izlenen:
                continue
            v, e = _ais_temiz(a.get("varis"), a.get("eta"))
            if not (v or e):
                continue
            o = eski_ais.get(k)
            ov, oe = _ais_temiz((o or {}).get("varis"), (o or {}).get("eta"))
            if self.onceki is not None and (ov or oe) and (ov, oe) != (v, e):
                olaylar.append({"tur": "ais", "ad": a.get("ad") or izlenen[k], "imo": a.get("imo") or "",
                                "mmsi": a.get("mmsi") or "", "durum": "", "varis": v, "eta": e,
                                "eski_varis": ov, "eski_eta": oe})
            yeni_ais[k] = {"varis": v, "eta": e}
        kayit = dict(simdi)
        kayit["_izlenen_"] = sorted(izlenen)
        kayit["_ais_"] = yeni_ais
        self.onceki = kayit
        try:
            gecici = self.yol + ".tmp"
            with open(gecici, "w", encoding="utf-8") as f:
                json.dump(kayit, f, ensure_ascii=False)
            os.replace(gecici, self.yol)
        except OSError:
            pass
        return olaylar
