# -*- coding: utf-8 -*-
"""Arka planda calisma: sistem tepsisi simgesi, tek kopya kontrolu, Windows acilisinda baslatma.

- Pencere carpidan kapatilinca program kapanmaz; saat yanindaki tepside simgesi durur.
  Sag tik -> Ac / Bogaz listesini simdi yenile / Kapat.
- Program ikinci kez acilirsa yeni kopya acilmaz; calisan pencere one getirilir.
- Windows'a giriste otomatik baslatma: Baslangic klasorune .lnk (PowerShell kullanmadan yazilir).
"""
import os
import sys
import socket
import threading
import subprocess

TEK_KOPYA_PORT = 47613          # yalnizca bu bilgisayar icinden (127.0.0.1)
KISAYOL_ADI = "Gemi Sefer Takibi.lnk"


# ====================================================================== tek kopya
class TekKopya:
    """Ilk acilan kopya 127.0.0.1:PORT'u dinler. Ikinci kopya baglanip 'goster' der ve kapanir."""

    def __init__(self, goster):
        self.goster = goster
        self.soket = None

    def kilitle(self, bekle=0.0):
        """True: bu ilk kopya. False: zaten acik bir kopya var (ona 'goster' gonderildi).
        bekle: yeniden baslatmada eski kopyanin kapanmasini bu kadar saniye bekle."""
        import time
        bitis = time.time() + bekle
        while True:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            if os.name == "nt":
                s.setsockopt(socket.SOL_SOCKET, getattr(socket, "SO_EXCLUSIVEADDRUSE", -5), 1)
            try:
                s.bind(("127.0.0.1", TEK_KOPYA_PORT))
                break
            except OSError:
                s.close()
            if time.time() < bitis:
                time.sleep(0.4)
                continue
            try:
                with socket.create_connection(("127.0.0.1", TEK_KOPYA_PORT), timeout=2) as c:
                    c.sendall(b"goster")
            except OSError:
                pass
            return False
        s.listen(4)
        self.soket = s
        threading.Thread(target=self._dinle, daemon=True).start()
        return True

    def _dinle(self):
        while self.soket is not None:
            try:
                c, _ = self.soket.accept()
            except OSError:
                return
            try:
                c.settimeout(2)
                if c.recv(32).startswith(b"goster") and self.goster:
                    self.goster()
            except OSError:
                pass
            finally:
                c.close()

    def birak(self):
        s, self.soket = self.soket, None
        if s is not None:
            try:
                s.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                s.close()
            except OSError:
                pass


# ====================================================================== tepsi simgesi
def _pystray_yukle():
    try:
        import pystray  # noqa: F401
        return True
    except ImportError:
        pass
    py = sys.executable
    if py.lower().endswith("pythonw.exe"):
        py = py[:-len("pythonw.exe")] + "python.exe"
    try:
        subprocess.run([py, "-m", "pip", "install", "--quiet", "--disable-pip-version-check", "pystray", "pillow"],
                       creationflags=0x08000000 if os.name == "nt" else 0, timeout=240)
    except Exception:
        try:
            subprocess.run([py, "-m", "pip", "install", "--user", "--quiet", "pystray", "pillow"],
                           creationflags=0x08000000 if os.name == "nt" else 0, timeout=240)
        except Exception:
            return False
    try:
        import pystray  # noqa: F401
        return True
    except ImportError:
        return False


class Tepsi:
    """Saat yanindaki simge. Geri cagirimlar tepsinin kendi is parcacigindan cagrilir;
    ana program bunlari kuyruga koymali (Tk is parcacigi guvenli degil)."""

    def __init__(self, ikon_yolu, baslik, ac, yenile, kapat):
        self.ikon_yolu = ikon_yolu
        self.baslik = baslik
        self.ac, self.yenile, self.kapat = ac, yenile, kapat
        self.icon = None
        self.hazir = False

    def baslat(self):
        threading.Thread(target=self._calis, daemon=True).start()

    def _calis(self):
        if not _pystray_yukle():
            return
        try:
            import pystray
            from PIL import Image
            try:
                resim = Image.open(self.ikon_yolu)
            except Exception:
                resim = Image.new("RGB", (64, 64), "#0E7C86")
            menu = pystray.Menu(
                pystray.MenuItem("Aç", lambda i, m: self.ac(), default=True),
                pystray.MenuItem("Boğaz listesini şimdi yenile", lambda i, m: self.yenile()),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem("Kapat", lambda i, m: self.kapat()),
            )
            self.icon = pystray.Icon("GemiSeferTakibi", resim, self.baslik, menu)
            self.hazir = True
            self.icon.run()
        except Exception:
            self.hazir = False

    def bildir(self, mesaj, baslik="Gemi Sefer Takibi"):
        """Windows bildirim balonu (tepsiden)."""
        if self.icon is not None and self.hazir:
            try:
                self.icon.notify(mesaj[:250], baslik[:60])
            except Exception:
                pass

    def durdur(self):
        if self.icon is not None:
            try:
                self.icon.stop()
            except Exception:
                pass
        self.icon = None
        self.hazir = False


# ====================================================================== Windows acilisinda baslat
def baslangic_klasoru():
    appdata = os.environ.get("APPDATA")
    if not appdata:
        return None
    return os.path.join(appdata, "Microsoft", "Windows", "Start Menu", "Programs", "Startup")


def otomatik_baslat_ayarla(acik, pythonw, betik, ikon):
    """acik=True: Baslangic klasorune kisayol yaz (pythonw "betik" --arkaplan). False: kisayolu sil.
    Donus: (basarili, mesaj)"""
    if os.name != "nt":
        return False, "Sadece Windows'ta"
    klasor = baslangic_klasoru()
    if not klasor:
        return False, "Başlangıç klasörü bulunamadı"
    yol = os.path.join(klasor, KISAYOL_ADI)
    if not acik:
        try:
            if os.path.exists(yol):
                os.remove(yol)
            return True, "Otomatik başlatma kapalı"
        except OSError as e:
            return False, str(e)
    try:
        os.makedirs(klasor, exist_ok=True)
        from kisayol import lnk_yaz
        lnk_yaz(yol, pythonw, f'"{betik}" --arkaplan', os.path.dirname(betik), ikon,
                "Gemi Sefer Takibi — arka planda")
        return True, yol
    except Exception as e:
        return False, str(e)


def otomatik_baslat_var_mi():
    k = baslangic_klasoru()
    return bool(k) and os.path.exists(os.path.join(k, KISAYOL_ADI))
