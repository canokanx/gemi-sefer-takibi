# -*- coding: utf-8 -*-
"""Programin kendi penceresinde VesselFinder haritasi (VesselFinder'in sitelere izin verdigi
ucretsiz harita araci: https://www.vesselfinder.com/embed).

Ana program bunu ayri bir islem olarak acar (pywebview kendi penceresini ana is parcaciginda ister):
  pythonw vf_harita.py '{"imo": "...", "mmsi": "...", "ad": "...", "lat": .., "lon": .., "zoom": ..}'
"""
import json
import os
import sys

KLASOR = os.path.dirname(os.path.abspath(__file__))
KIRP = 24          # ustten kirpilacak serit yuksekligi (piksel)


def html_olustur(p):
    tek = bool(p.get("imo") or p.get("mmsi"))
    satirlar = [
        'var width="100%";',
        f'var height=String(Math.max(300, window.innerHeight + {int(p.get("kirp", KIRP))}));',
        f'var names={"true" if p.get("isimler", True) else "false"};',
    ]
    if tek:
        if p.get("imo"):
            satirlar.append(f'var imo="{int(p["imo"])}";')
        if p.get("mmsi"):
            satirlar.append(f'var mmsi="{int(p["mmsi"])}";')
        satirlar.append("var show_track=true;")
        satirlar.append(f'var zoom="{int(p.get("zoom") or 10)}";')
    else:
        satirlar.append(f'var latitude="{float(p.get("lat", 40.75)):.4f}";')
        satirlar.append(f'var longitude="{float(p.get("lon", 28.6)):.4f}";')
        satirlar.append(f'var zoom="{max(3, min(18, int(p.get("zoom") or 8)))}";')
    # VesselFinder'in ust seridi (VesselFinder.com | Embed this map | iOS | Android) kirpilir:
    # harita KIRP piksel yukari kaydirilir, fazlasi pencere disinda kalir.
    kirp = int(p.get("kirp", KIRP))
    return ("<!doctype html><html><head><meta charset='utf-8'>"
            "<style>html,body{margin:0;padding:0;background:#F4F8F8;overflow:hidden;height:100%}"
            f"#kap{{position:absolute;left:0;right:0;top:-{kirp}px;bottom:0}}</style></head><body><div id='kap'>"
            "<script type='text/javascript'>" + "\n".join(satirlar) + "</script>"
            "<script type='text/javascript' src='https://www.vesselfinder.com/aismap.js'></script>"
            "</div>"
            # pencere (program icindeki alan) buyuyup kuculdukce harita da uysun
            f"<script>function _b(){{var h=window.innerHeight+{kirp};"
            "document.querySelectorAll('iframe').forEach(function(f){"
            "f.style.width='100%';f.style.height=h+'px';f.height=h;f.style.display='block';f.style.border='0';});}"
            "window.addEventListener('resize',_b);setInterval(_b,1500);</script>"
            "</body></html>")


def _ana_program_izle(pid):
    """Ana program kapanirsa bu pencere de kapansin."""
    import threading
    import time
    if os.name != "nt" or not pid:
        return

    def is_():
        import ctypes
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x00100000, False, int(pid))      # SYNCHRONIZE
        if not h:
            os._exit(0)
        while True:
            if k32.WaitForSingleObject(h, 0) == 0:           # ana program bitti
                os._exit(0)
            time.sleep(2)
    threading.Thread(target=is_, daemon=True).start()


def main():
    p = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    _ana_program_izle(p.get("ana_pid"))
    try:
        import webview
    except ImportError:
        import subprocess
        subprocess.run([sys.executable.replace("pythonw.exe", "python.exe"), "-m", "pip", "install", "--quiet",
                        "pywebview"], creationflags=0x08000000 if os.name == "nt" else 0)
        try:
            import webview
        except ImportError:
            import tkinter as tk
            from tkinter import messagebox
            r = tk.Tk()
            r.withdraw()
            messagebox.showerror("Gemi Sefer Takibi", "VesselFinder haritası için 'pywebview' kurulamadı.\n"
                                 "İnternet bağlantısını kontrol edip tekrar deneyin.")
            return
    ad = p.get("ad") or (f"IMO {p['imo']}" if p.get("imo") else (f"MMSI {p['mmsi']}" if p.get("mmsi") else "Bölge"))
    baslik = f"Gemi Sefer Takibi — VesselFinder: {ad}"
    if p.get("gomulu"):
        # ekran disinda ve cercevesiz acilir; ana program onu kendi sekmesinin icine alir
        try:
            webview.create_window(baslik, html=html_olustur(p), width=1200, height=800, x=-20000, y=-20000,
                                  frameless=True, easy_drag=False, background_color="#F4F8F8")
        except TypeError:
            webview.create_window(baslik, html=html_olustur(p), width=1200, height=800, x=-20000, y=-20000,
                                  frameless=True, background_color="#F4F8F8")
    else:
        webview.create_window(baslik, html=html_olustur(p), width=1150, height=780, background_color="#F4F8F8")
    ikon = os.path.join(KLASOR, "kaynak", "gemi_sefer.ico")
    try:
        webview.start(icon=ikon if os.path.exists(ikon) else None)
    except TypeError:
        webview.start()


if __name__ == "__main__":
    main()
