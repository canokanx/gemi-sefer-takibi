# -*- coding: utf-8 -*-
"""Harita karolari: diskte onbellek + deniz isaretleri (OpenSeaMap) katmani.

tkintermapview'in kendi ust-katman kodu yeni Pillow surumlerinde calismiyor ve bos
deniz-isareti karolarinda (404) butun karoyu bos birakiyor. Burada daha saglam bir
surumle degistirilir. Karolar veri/harita_onbellek klasorunde 30 gun saklanir; harita
ikinci acilista cok daha hizli gelir.
"""
import io
import os
import time
import hashlib

import requests
from PIL import Image, ImageTk

try:
    import tkintermapview
    from tkintermapview import TkinterMapView
except ImportError:
    TkinterMapView = None

UA = {"User-Agent": "GemiSeferTakibi/2.0 (IRONHULL Marine Services desktop app)"}
OMUR = 30 * 24 * 3600

STILLER = {
    "Deniz haritası": {
        "karo": "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        "ust": "https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png",
        "max": 19,
        "kaynak": "© OpenStreetMap katkıcıları  •  Deniz işaretleri © OpenSeaMap",
    },
    "Uydu": {
        "karo": "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        "ust": "https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png",
        "max": 18,
        "kaynak": "Uydu © Esri, Maxar, Earthstar Geographics  •  Deniz işaretleri © OpenSeaMap",
    },
    "Sade": {
        "karo": "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        "ust": None,
        "max": 19,
        "kaynak": "© OpenStreetMap katkıcıları",
    },
}

_onbellek_klasor = None
_oturum = requests.Session()
_oturum.headers.update(UA)


def onbellek_ayarla(klasor):
    global _onbellek_klasor
    _onbellek_klasor = klasor
    try:
        os.makedirs(klasor, exist_ok=True)
    except OSError:
        _onbellek_klasor = None


def _yol(url_kalip, z, x, y):
    if not _onbellek_klasor:
        return None
    h = hashlib.md5(url_kalip.encode()).hexdigest()[:10]
    return os.path.join(_onbellek_klasor, h, str(z), str(x), f"{y}.png")


def _karo_al(url_kalip, z, x, y, bos_olabilir=False):
    """Karo resmi (RGBA) ya da None. Diskteki onbellegi kullanir."""
    yol = _yol(url_kalip, z, x, y)
    if yol and os.path.exists(yol) and time.time() - os.path.getmtime(yol) < OMUR:
        if os.path.getsize(yol) == 0:          # "burada karo yok" isareti
            return None
        try:
            return Image.open(yol).convert("RGBA")
        except Exception:
            pass
    url = url_kalip.replace("{x}", str(x)).replace("{y}", str(y)).replace("{z}", str(z))
    try:
        r = _oturum.get(url, timeout=12)
    except requests.RequestException:
        return None
    if r.status_code != 200 or not r.content:
        if bos_olabilir and r.status_code == 404 and yol:
            os.makedirs(os.path.dirname(yol), exist_ok=True)
            open(yol, "wb").close()
        return None
    try:
        img = Image.open(io.BytesIO(r.content)).convert("RGBA")
    except Exception:
        return None
    if yol:
        try:
            os.makedirs(os.path.dirname(yol), exist_ok=True)
            with open(yol, "wb") as f:
                f.write(r.content)
        except OSError:
            pass
    return img


def _request_image(self, zoom, x, y, db_cursor=None):
    try:
        img = _karo_al(self.tile_server, zoom, x, y)
        if img is None:
            return self.empty_tile_image
        if getattr(self, "overlay_tile_server", None):
            ust = _karo_al(self.overlay_tile_server, zoom, x, y, bos_olabilir=True)
            if ust is not None:
                if ust.size != img.size:
                    ust = ust.resize(img.size, Image.LANCZOS)
                img.alpha_composite(ust)
        if self.tile_size and img.size != (self.tile_size, self.tile_size):
            img = img.resize((self.tile_size, self.tile_size), Image.LANCZOS)
        if not self.running:
            return self.empty_tile_image
        foto = ImageTk.PhotoImage(img)
        self.tile_image_cache[f"{zoom}{x}{y}"] = foto
        return foto
    except Exception:
        return self.empty_tile_image


if TkinterMapView is not None:
    TkinterMapView.request_image = _request_image


def stil_uygula(harita, ad):
    s = STILLER.get(ad) or STILLER["Deniz haritası"]
    harita.set_overlay_tile_server(s["ust"])
    harita.set_tile_server(s["karo"], max_zoom=s["max"])
    return s["kaynak"]
