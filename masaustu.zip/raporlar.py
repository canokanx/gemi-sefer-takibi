# -*- coding: utf-8 -*-
"""Bogaz trafigi degisiklikleri, sabah ozeti ve musteri/armator durum raporu.

Hepsi duz metin + HTML olarak hazirlanir (HTML mail; Outlook/Gmail'de tablo olarak gorunur).
"""
import os
import json
import html as _html
import datetime as dt

BOGAZ = {"I": "İstanbul", "C": "Çanakkale"}
BOGAZ_EN = {"I": "Istanbul", "C": "Canakkale"}
YON_TRAFIK = {"KG": "Kuzey → Güney", "GK": "Güney → Kuzey"}
YON_TRAFIK_EN = {"KG": "North → South", "GK": "South → North"}
YON_LISTE = {"NS": "Kuzey → Güney", "SN": "Güney → Kuzey"}
YON_LISTE_EN = {"NS": "North → South", "SN": "South → North"}
DURUM_AD = {"acik": "AÇIK", "askida": "ASKIDA", "diger": "PLANSIZ"}
DURUM_RENK = {"acik": "#2E7D32", "askida": "#C62828", "diger": "#8A9599"}

TEAL = "#0E7C86"
_STIL_TABLO = "border-collapse:collapse;font-family:Segoe UI,Arial,sans-serif;font-size:13px"
_STIL_TH = f"background:{TEAL};color:#fff;padding:6px 10px;text-align:left;border:1px solid #0A5C63"
_STIL_TD = "padding:5px 10px;border:1px solid #D5DADB;vertical-align:top"


def e(x):
    return _html.escape("" if x is None else str(x))


def html_sayfa(baslik, govde_html, imza_html=""):
    return (f"<html><body style='font-family:Segoe UI,Arial,sans-serif;color:#1E2A2E;font-size:13px'>"
            f"<div style='background:{TEAL};color:#fff;padding:10px 14px;font-size:16px;font-weight:bold'>{e(baslik)}</div>"
            f"<div style='padding:12px 2px'>{govde_html}</div>"
            f"<div style='color:#6B7C80;font-size:12px;border-top:1px solid #D5DADB;padding-top:8px'>{imza_html}</div>"
            "</body></html>")


def html_tablo(basliklar, satirlar, renkler=None):
    h = [f"<table style='{_STIL_TABLO}'><tr>" + "".join(f"<th style='{_STIL_TH}'>{e(b)}</th>" for b in basliklar)
         + "</tr>"]
    for i, s in enumerate(satirlar):
        zemin = (renkler[i] if renkler and renkler[i] else ("#F4F8F8" if i % 2 else "#FFFFFF"))
        h.append(f"<tr style='background:{zemin}'>" + "".join(f"<td style='{_STIL_TD}'>{e(x)}</td>" for x in s)
                 + "</tr>")
    h.append("</table>")
    return "".join(h)


def metin_tablo(basliklar, satirlar):
    gen = [max(len(str(b)), *(len(str(s[i])) for s in satirlar)) if satirlar else len(str(b))
           for i, b in enumerate(basliklar)]
    cizgi = "  ".join("-" * g for g in gen)
    out = ["  ".join(str(b).ljust(g) for b, g in zip(basliklar, gen)), cizgi]
    out += ["  ".join(str(x).ljust(g) for x, g in zip(s, gen)) for s in satirlar]
    return "\n".join(out)


# ====================================================================== bogaz trafigi degisiklikleri
def _tarihli(trafik):
    """{'tarih', 'bugun', 'yarin'} -> {'18.10.2026': {...}, '19.10.2026': {...}} (sadece plan, metin haric)"""
    if not trafik or not trafik.get("tarih"):
        return {}
    bugun = dt.datetime.strptime(trafik["tarih"], "%d.%m.%Y")
    sonuc = {}
    for anahtar, gun in (("bugun", bugun), ("yarin", bugun + dt.timedelta(days=1))):
        v = trafik.get(anahtar) or {}
        sonuc[gun.strftime("%d.%m.%Y")] = {k: {y: [tuple(x[:3]) for x in (v.get(k) or {}).get(y) or []]
                                                for y in ("KG", "GK")} for k in ("I", "C")}
    return sonuc


def _dilim_metni(dilimler):
    if not dilimler:
        return "planlanmamış"
    return ", ".join(f"{b}–{s} {DURUM_AD.get(d, d)}" for b, s, d in dilimler)


def trafik_degisiklikleri(eski, yeni):
    """Iki trafik kaydi arasinda plan degisiklikleri: [{tarih, bogaz, yon, eski, yeni, tur}]
    tur: 'yayinlandi' (o gunun plani ilk kez geldi) | 'degisti'"""
    a, b = _tarihli(eski), _tarihli(yeni)
    olaylar = []
    for tarih, yeni_gun in b.items():
        if tarih not in a:
            continue                            # eski kayitta o gun hic yoktu (ilk calisma / gun donumu)
        for k in ("I", "C"):
            for y in ("KG", "GK"):
                e_, n_ = a[tarih][k][y], yeni_gun[k][y]
                if e_ == n_:
                    continue
                olaylar.append({"tarih": tarih, "bogaz": k, "yon": y, "eski": e_, "yeni": n_,
                                "tur": "yayinlandi" if not e_ else "degisti"})
    return olaylar


def trafik_mail_icerigi(olaylar, firma="", imza="— Gemi Sefer Takibi"):
    yay = [o for o in olaylar if o["tur"] == "yayinlandi"]
    deg = [o for o in olaylar if o["tur"] == "degisti"]
    if deg:
        konu = "⚓ Boğaz trafik planı değişti: " + ", ".join(sorted({f"{BOGAZ[o['bogaz']]} {YON_TRAFIK[o['yon']]}" for o in deg}))
    else:
        konu = f"⚓ Boğaz trafik planı yayınlandı ({', '.join(sorted({o['tarih'] for o in yay}))})"
    if firma:
        konu = f"[{firma}] {konu}"
    satirlar_m, satirlar_h = [], []
    for o in olaylar:
        ne = "Yeni plan" if o["tur"] == "yayinlandi" else "DEĞİŞTİ"
        satirlar_m.append(f"• {o['tarih']}  {BOGAZ[o['bogaz']]} Boğazı  {YON_TRAFIK[o['yon']]}  ({ne})\n"
                          + (f"    Önce : {_dilim_metni(o['eski'])}\n" if o["tur"] == "degisti" else "")
                          + f"    Şimdi: {_dilim_metni(o['yeni'])}")
        satirlar_h.append([o["tarih"], f"{BOGAZ[o['bogaz']]} Boğazı", YON_TRAFIK[o["yon"]], ne,
                           _dilim_metni(o["eski"]) if o["tur"] == "degisti" else "", _dilim_metni(o["yeni"])])
    govde = ("Kıyı Emniyeti Türk Boğazları trafik planında değişiklik var:\n\n" + "\n\n".join(satirlar_m)
             + f"\n\nKontrol: {dt.datetime.now():%d.%m.%Y %H:%M}\n\n{imza}")
    html = html_sayfa("Boğaz Trafik Planı", "<p>Kıyı Emniyeti Türk Boğazları trafik planında değişiklik var:</p>"
                      + html_tablo(["Tarih", "Boğaz", "Yön", "", "Önceki plan", "Güncel plan"], satirlar_h,
                                   ["#FFF4C2" if o["tur"] == "degisti" else None for o in olaylar])
                      + f"<p style='color:#6B7C80'>Kontrol: {dt.datetime.now():%d.%m.%Y %H:%M}</p>",
                      e(imza).replace("\n", "<br>"))
    return konu, govde, html


class TrafikTakip:
    """Son trafik planini diske yazar; program yeniden acilinca ayni degisiklik icin tekrar mail gitmez.
    Ayrica anlik durum gecislerini (acildi / askiya alindi) izler."""

    def __init__(self, yol):
        self.yol = yol
        self.son = None
        self.anlik = {}
        try:
            with open(yol, "r", encoding="utf-8") as f:
                self.son = json.load(f)
        except (OSError, ValueError):
            pass

    def guncelle(self, trafik):
        if not trafik or not trafik.get("bugun"):
            return []
        olaylar = trafik_degisiklikleri(self.son, trafik) if self.son else []
        self.son = trafik
        try:
            gecici = self.yol + ".tmp"
            with open(gecici, "w", encoding="utf-8") as f:
                json.dump(trafik, f, ensure_ascii=False)
            os.replace(gecici, self.yol)
        except OSError:
            pass
        return olaylar

    def anlik_kontrol(self, trafik, durum_fn, simdi=None):
        """Su anki durum degistiyse [(bogaz, yon, eski, yeni, sonra)] dondurur. Ilk cagrida bos."""
        degisen = []
        for k in ("I", "C"):
            for y in ("KG", "GK"):
                d = durum_fn(trafik, k, y, simdi)
                if d is None:
                    continue
                onceki = self.anlik.get((k, y))
                if onceki is not None and onceki != d[0]:
                    degisen.append((k, y, onceki, d[0], d[2]))
                self.anlik[(k, y)] = d[0]
        return degisen


# ====================================================================== durum raporu satirlari
SUTUN_TR = ["Gemi", "IMO", "Bayrak", "Tip", "Boğaz", "Sıra", "Durum", "Planlanan Geçiş", "Yön",
            "AIS Durumu", "Hız", "Son Konum", "AIS Varış", "AIS ETA"]
SUTUN_EN = ["Vessel", "IMO", "Flag", "Type", "Strait", "Queue", "Status", "Planned Transit", "Direction",
            "AIS Status", "Speed", "Last Position", "AIS Destination", "AIS ETA"]
DURUM_EN = {"BOĞAZDA": "IN TRANSIT", "PLAN. GEÇİŞ": "PLANNED", "GEÇİŞE HAZIR": "READY", "SP1": "SP1",
            "SP2": "SP2", "DİĞER": "OTHER"}
NAV_EN = {"Seyirde (makine)": "Under way", "Demirde": "At anchor", "Bağlı (rıhtımda)": "Moored",
          "Manevra kısıtlı": "Restricted manoeuvrability", "konum bekleniyor": "awaiting position",
          "Demirli": "At anchor"}


def rapor_satiri(s, dil="TR"):
    """s: uygulamanin topladigi sozluk -> tablo satiri (liste)"""
    en = dil == "EN"
    bogaz = (BOGAZ_EN if en else BOGAZ).get(s.get("bogaz_kod"), "") if s.get("bogaz_kod") else \
        ("Not in queue" if en else "Listede değil")
    durum = s.get("durum") or ""
    yon = (YON_LISTE_EN if en else YON_LISTE).get(s.get("yon"), "")
    ais = s.get("ais_durum") or ""
    return [s.get("ad") or "", s.get("imo") or "", s.get("bayrak") or "", s.get("tip") or "", bogaz,
            s.get("sira") or "", DURUM_EN.get(durum, durum) if en else durum, s.get("plan") or "", yon,
            NAV_EN.get(ais, ais) if en else ais, s.get("hiz") or "", s.get("son_konum") or "",
            s.get("varis") or "", s.get("eta") or ""]


def durum_raporu(satirlar, dil="TR", firma="", unvan="", not_=""):
    """satirlar: rapor_satiri girdileri (sozluk listesi). Donus: (konu, metin, html, basliklar, tablo)"""
    en = dil == "EN"
    simdi = dt.datetime.now()
    basliklar = SUTUN_EN if en else SUTUN_TR
    tablo = [rapor_satiri(s, dil) for s in satirlar]
    gemi_adlari = ", ".join(s.get("ad") or "" for s in satirlar[:3]) + (" …" if len(satirlar) > 3 else "")
    if en:
        konu = f"Vessel Status Report {simdi:%d.%m.%Y %H:%M} — {gemi_adlari}"
        giris = f"Dear Sirs,\n\nPlease find below the current status of the vessel(s) as of {simdi:%d.%m.%Y %H:%M} (local time)."
        kapanis = "Strait queue data: Turkish Coastal Safety (KEGM) VTS. AIS data: last received position.\n\nBest regards,"
    else:
        konu = f"Gemi Durum Raporu {simdi:%d.%m.%Y %H:%M} — {gemi_adlari}"
        giris = f"Sayın İlgili,\n\n{simdi:%d.%m.%Y %H:%M} itibarıyla gemi(ler)in güncel durumu aşağıdadır."
        kapanis = "Boğaz sırası: Kıyı Emniyeti GTBS. AIS: son alınan konum.\n\nSaygılarımızla,"
    if firma:
        konu = f"[{firma}] {konu}"
    imza = "\n".join(x for x in (unvan or firma,) if x)
    # duz metin: her gemi ayri blok (tablo mailde cok genis olur)
    bloklar = []
    for s in tablo:
        bloklar.append("\n".join(f"  {b:<16}: {v}" for b, v in zip(basliklar, s) if v not in ("", None)))
    metin = (giris + ("\n\n" + not_ if not_ else "") + "\n\n" + "\n\n".join(bloklar) + "\n\n" + kapanis
             + ("\n" + imza if imza else ""))
    renkler = ["#E8F5E9" if s.get("durum") == "BOĞAZDA" else None for s in satirlar]
    html = html_sayfa(("Vessel Status Report" if en else "Gemi Durum Raporu") + f" — {simdi:%d.%m.%Y %H:%M}",
                      "<p>" + e(giris).replace("\n", "<br>") + "</p>"
                      + (f"<p><b>{e(not_)}</b></p>" if not_ else "")
                      + html_tablo(basliklar, tablo, renkler)
                      + "<p>" + e(kapanis).replace("\n", "<br>") + "</p>",
                      e(imza).replace("\n", "<br>"))
    return konu, metin, html, basliklar, tablo


def excel_kaydet(yol, baslik, basliklar, tablo, firma=""):
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment
    except ImportError:
        import csv
        yol = os.path.splitext(yol)[0] + ".csv"
        with open(yol, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f, delimiter=";")
            w.writerow([baslik])
            w.writerow(basliklar)
            w.writerows(tablo)
        return yol
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Rapor"
    ws["A1"] = baslik
    ws["A1"].font = Font(bold=True, size=13, color="0A5C63")
    if firma:
        ws["A2"] = firma
        ws["A2"].font = Font(italic=True, color="6B7C80")
    ws.append([])
    ws.append(basliklar)
    r0 = ws.max_row
    for c in ws[r0]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="0E7C86")
        c.alignment = Alignment(vertical="center")
    for s in tablo:
        ws.append(list(s))
    for i, b in enumerate(basliklar, 1):
        en = max([len(str(b))] + [len(str(s[i - 1])) for s in tablo]) + 2
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = min(40, en)
    ws.freeze_panes = ws.cell(row=r0 + 1, column=1)
    wb.save(yol)
    return yol


# ====================================================================== sabah ozeti
def sabah_ozeti(trafik_satirlari, gemi_satirlari, hatirlatmalar, firma="", imza="— Gemi Sefer Takibi"):
    """trafik_satirlari: [(bogaz_kod, yon, durum, sonra, gunluk_plan_metni)]
    gemi_satirlari: rapor icin sozlukler; hatirlatmalar: vt.yaklasanlar() ciktisi"""
    simdi = dt.datetime.now()
    konu = f"☀ Günlük Özet {simdi:%d.%m.%Y} — {len(gemi_satirlari)} gemi, {len(hatirlatmalar)} hatırlatma"
    if firma:
        konu = f"[{firma}] {konu}"
    # trafik
    tm = [f"  {BOGAZ[k]:<10} {YON_TRAFIK[y]:<14} {DURUM_AD.get(d, '-'):<8} {sonra}\n      Bugün: {plan}"
          for k, y, d, sonra, plan in trafik_satirlari]
    th = html_tablo(["Boğaz", "Yön", "Şu an", "Sonraki", "Bugünün planı"],
                    [[BOGAZ[k], YON_TRAFIK[y], DURUM_AD.get(d, "-"), sonra, plan] for k, y, d, sonra, plan in trafik_satirlari])
    # gemiler
    gb = SUTUN_TR
    gt = [rapor_satiri(s) for s in gemi_satirlari]
    gm = "\n\n".join("\n".join(f"  {b:<16}: {v}" for b, v in zip(gb, s) if v) for s in gt) or "  (takipte gemi yok)"
    gh = html_tablo(gb, gt, ["#E8F5E9" if s.get("durum") == "BOĞAZDA" else None for s in gemi_satirlari]) \
        if gt else "<p>(takipte gemi yok)</p>"
    # hatirlatmalar
    hm = "\n".join(f"  {h['zaman']:%d.%m %H:%M}  {h['metin']}" + ("  (GECİKTİ)" if h["gecikti"] else "")
                   for h in hatirlatmalar) or "  (yaklaşan iş yok)"
    hh = html_tablo(["Son tarih", "İş", ""], [[f"{h['zaman']:%d.%m %H:%M}", h["metin"], "GECİKTİ" if h["gecikti"] else ""]
                                             for h in hatirlatmalar],
                    ["#FFEBEE" if h["gecikti"] else None for h in hatirlatmalar]) if hatirlatmalar else \
        "<p>(yaklaşan iş yok)</p>"
    gun = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"][simdi.weekday()]
    metin = (f"Günaydın, {simdi:%d.%m.%Y} {gun} özeti:\n\n⚓ BOĞAZ TRAFİĞİ\n" + "\n".join(tm)
             + "\n\n🚢 TAKİPTEKİ GEMİLER\n" + gm + "\n\n⏰ HATIRLATMALAR\n" + hm + f"\n\n{imza}")
    html = html_sayfa(f"Günlük Özet — {simdi:%d.%m.%Y}",
                      "<h3 style='color:#0A5C63'>⚓ Boğaz Trafiği</h3>" + th
                      + "<h3 style='color:#0A5C63'>🚢 Takipteki Gemiler</h3>" + gh
                      + "<h3 style='color:#0A5C63'>⏰ Hatırlatmalar</h3>" + hh,
                      e(imza).replace("\n", "<br>"))
    return konu, metin, html
