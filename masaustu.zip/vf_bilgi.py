# -*- coding: utf-8 -*-
"""VesselFinder gemi detay sayfasindan bilgi: IMO (ya da MMSI) -> ad, MMSI, cagri, bayrak, tip, insa yili,
boy/en, GT/DWT, su cekimi, varis/ETA, son liman, rota/hiz, son konum.

Herkese acik sayfa okunur (https://www.vesselfinder.com/vessels/details/<IMO|MMSI>); ayni gemi icin
siteyi yormamak adina sonuc 6 saat diskte saklanir. Hesap / anahtar gerekmez.
"""
import html as _html
import json
import os
import re
import threading
import time
import urllib.error
import urllib.request

ADRES = "https://www.vesselfinder.com/vessels/details/{}"
OMUR = 6 * 3600
BASLIKLAR = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/130.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9,tr;q=0.8",
}

_TD = re.compile(r'<td class="(tpc1|n3)"[^>]*>(.*?)</td>\s*<td class="(?:tpc2|v3)[^"]*"[^>]*>(.*?)</td>', re.S)


class VFHatasi(Exception):
    pass


def _metin(h):
    h = re.sub(r"<(script|style)[\s\S]*?</\1>", " ", h or "")
    h = re.sub(r"<[^>]+>", " ", h)
    return re.sub(r"\s+", " ", _html.unescape(h)).strip()


def _turkce_zaman(s):
    """'17 hours ago' -> '17 saat önce'"""
    birim = {"second": "saniye", "minute": "dakika", "min": "dakika", "hour": "saat", "day": "gün",
             "week": "hafta", "month": "ay", "year": "yıl"}
    m = re.match(r"\s*(\d+|an?|one)\s+([a-z]+?)s?\s+ago", s or "", re.I)
    if not m:
        return s
    n = "1" if m.group(1).lower() in ("a", "an", "one") else m.group(1)
    return f"{n} {birim.get(m.group(2).lower(), m.group(2))} önce"


def _sayi(s):
    m = re.search(r"\d+(?:[.,]\d+)?", s or "")
    if not m:
        return ""
    v = float(m.group().replace(",", "."))
    return f"{v:g}"


def coz(sayfa):
    """Detay sayfasi HTML'i -> bilgi sozlugu (bos alanlar yazilmaz)."""
    ham = {}
    for _, etiket, deger in _TD.findall(sayfa):
        e, d = _metin(etiket), _metin(deger)
        if e and d and d != "-" and e not in ham:
            ham[e] = d
    b = {}

    def koy(k, v):
        if v not in (None, "", "-"):
            b[k] = v

    koy("imo", ham.get("IMO number", "").strip())
    koy("ad", ham.get("Vessel Name", ""))
    koy("tip_metin", ham.get("Ship Type", ""))
    koy("bayrak_en", ham.get("Flag") or ham.get("AIS Flag", ""))
    koy("yapim", ham.get("Year of Build", ""))
    koy("boy", _sayi(ham.get("Length Overall (m)", "")))
    koy("en", _sayi(ham.get("Beam (m)", "")))
    koy("grt", _sayi(ham.get("Gross Tonnage", "")))
    koy("nrt", _sayi(ham.get("Net Tonnage", "")))
    koy("dwt", _sayi(ham.get("Deadweight (t)", "")))
    koy("draft", _sayi(ham.get("Current draught", "")) or _sayi(ham.get("Draught (m)", "")))
    koy("cagri", ham.get("Callsign", ""))
    koy("ais_tip", ham.get("AIS Type", ""))
    koy("rota_hiz", ham.get("Course / Speed", ""))
    koy("nav", ham.get("Navigation Status", ""))
    koy("konum_zamani", _turkce_zaman(ham.get("Position Received", "")))
    koy("tahmini_eta", ham.get("Predicted ETA", ""))
    im = ham.get("IMO / MMSI", "")
    if "/" in im:
        i, m = (x.strip() for x in im.split("/", 1))
        if i.isdigit() and len(i) == 7:
            b.setdefault("imo", i)
        if m.isdigit() and len(m) == 9:
            b["mmsi"] = m
    if "boy" not in b:
        lb = ham.get("Length / Beam", "")
        if "/" in lb:
            b["boy"], en = _sayi(lb.split("/")[0]), _sayi(lb.split("/")[1])
            if en:
                b.setdefault("en", en)
    if "ad" not in b:
        m = re.search(r'<h1 class="title">(.*?)</h1>', sayfa, re.S)
        if m:
            koy("ad", _metin(m.group(1)))
    # varis / ETA (limandaysa: varis limani + ATA + "ARRIVED")
    m = re.search(r'class="vi__r1 vi__sbt"\s*>(.*?)</div>\s*</div>', sayfa, re.S)
    if m:
        blok = m.group(1)
        v = re.search(r'class="_3-Yih"[^>]*>(.*?)</div>', blok, re.S) or \
            re.search(r'class="_npNa"[^>]*>(.*?)</a>', blok, re.S)
        if v and "not available" not in _metin(v.group(1)).lower():
            koy("varis", _metin(v.group(1)))
        kod = re.search(r'href="/ports/([A-Z0-9]+)"', blok)
        if kod:
            b["varis_kod"] = kod.group(1)
        e = re.search(r'class="_mcol12"[^>]*>(.*?)</span>', blok, re.S)
        if e:
            t = _metin(e.group(1))
            if t.upper().startswith("ATA"):
                koy("ata", t.split(":", 1)[1].strip() if ":" in t else t)
            else:
                koy("eta", t.replace("ETA:", "").strip())
        if re.search(r'class="_arrLb"', blok) or "ata" in b:
            b["vardi"] = True
    # son liman
    m = re.search(r'class="vi__r1 vi__stp"\s*>(.*?)</div>\s*</div>', sayfa, re.S)
    if m:
        blok = m.group(1)
        p = re.search(r'class="_npNa"[^>]*>(.*?)</a>', blok, re.S)
        if p:
            koy("son_liman", _metin(p.group(1)))
        kod = re.search(r'href="/ports/([A-Z0-9]+)"', blok)
        if kod:
            b["son_liman_kod"] = kod.group(1)
        a = re.search(r'class="_value"[^>]*>(.*?)(?:</div>|$)', blok, re.S)
        if a:
            koy("son_liman_zaman", re.sub(r"\s*\((.*?)\)\s*$", lambda x: f" ({_turkce_zaman(x.group(1))})",
                                          _metin(a.group(1))))
    # bulundugu bolge: "The current position of X is at Marmara Sea reported 14 min ago"
    m = re.search(r"current position of .*? is\s+at\s+(.*?)\s+reported", _metin(sayfa[:200000]), re.S)
    if m and len(m.group(1)) < 60:
        koy("bolge", m.group(1).strip())
    # konumun alindigi an (UTC): <td id="lastrep"> ... data-title="Oct 22, 2026 21:29 UTC"
    m = re.search(r'id="lastrep".*?data-title="([A-Za-z]{3} \d{1,2}, \d{4} \d{1,2}:\d{2}) UTC"', sayfa, re.S)
    if m:
        try:
            import calendar
            import datetime as _dt
            b["konum_t"] = calendar.timegm(_dt.datetime.strptime(m.group(1), "%b %d, %Y %H:%M").timetuple())
        except ValueError:
            pass
    # konum (ucretsiz sayfada ~1 dereceye yuvarlanmis)
    m = re.search(r"""id=["']djson["'][^>]*?data-json=(["'])(.*?)\1""", sayfa, re.S)
    if m:
        try:
            dj = json.loads(_html.unescape(m.group(2)))
            if dj.get("ship_lat") is not None and dj.get("ship_lon") is not None:
                b["lat"], b["lon"] = float(dj["ship_lat"]), float(dj["ship_lon"])
            if dj.get("mmsi") and "mmsi" not in b:
                b["mmsi"] = str(dj["mmsi"])
        except (ValueError, TypeError):
            pass
    return b


def indir(no, zaman_asimi=20):
    istek = urllib.request.Request(ADRES.format(no), headers=BASLIKLAR)
    try:
        with urllib.request.urlopen(istek, timeout=zaman_asimi) as r:
            return r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise VFHatasi("VesselFinder'da bu numarayla gemi yok")
        if e.code in (403, 429):
            raise VFHatasi("VesselFinder geçici olarak erişimi kısıtladı, sonra tekrar denenir")
        raise VFHatasi(f"VesselFinder hatası ({e.code})")
    except urllib.error.URLError as e:
        raise VFHatasi(f"VesselFinder'a ulaşılamadı ({e.reason})")


class VFBilgi:
    """Disk onbellekli VesselFinder sorgusu (thread-guvenli)."""

    def __init__(self, onbellek_yolu=None):
        self.yol = onbellek_yolu
        self.kilit = threading.Lock()
        self.veri = {}
        if onbellek_yolu and os.path.exists(onbellek_yolu):
            try:
                with open(onbellek_yolu, encoding="utf-8") as f:
                    self.veri = json.load(f)
            except (OSError, ValueError):
                self.veri = {}

    def _kaydet(self):
        if not self.yol:
            return
        try:
            gecici = self.yol + ".tmp"
            with open(gecici, "w", encoding="utf-8") as f:
                json.dump(self.veri, f, ensure_ascii=False)
            os.replace(gecici, self.yol)
        except OSError:
            pass

    def onbellek(self, imo=None, mmsi=None, omur=None):
        """Agsiz: onbellekteki bilgi (yoksa None). omur verilirse daha eskisi None."""
        with self.kilit:
            for k in (imo, mmsi):
                if k and str(k) in self.veri:
                    kayit = self.veri[str(k)]
                    if omur is None or time.time() - kayit.get("_zaman", 0) < omur:
                        return dict(kayit)
        return None

    def getir(self, imo=None, mmsi=None, zorla=False):
        """Onbellek tazeyse onu, degilse siteden okur. Hata: VFHatasi"""
        if not zorla:
            b = self.onbellek(imo, mmsi, OMUR)
            if b:
                return b
        no = imo or mmsi
        if not no:
            raise VFHatasi("IMO ya da MMSI gerekli")
        b = coz(indir(no))
        if not b.get("imo") and not b.get("mmsi"):
            raise VFHatasi("VesselFinder sayfası okunamadı")
        b["_zaman"] = time.time()
        with self.kilit:
            for k in (b.get("imo"), b.get("mmsi"), imo, mmsi):
                if k:
                    self.veri[str(k)] = b
            if len(self.veri) > 3000:                        # eski kayitlari at
                for k in sorted(self.veri, key=lambda x: self.veri[x].get("_zaman", 0))[:500]:
                    self.veri.pop(k, None)
            self._kaydet()
        return dict(b)
