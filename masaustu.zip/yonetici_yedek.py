# -*- coding: utf-8 -*-
"""Yonetici yedegi: bilgisayar degistirirken yonetici kurulumunu tek dosyayla tasimak icin.

Dosyada (.gstyedek) sunlar bulunur:
  • butun ayarlar (yonetici sifresi, GitHub kullanici/depo/token, yayin numarasi, sirket, mail ...)
    -> Windows'a bagli (DPAPI) sifreler acilip duz halde konur, yeni bilgisayarda yeniden sifrelenir
  • ekip ortak kanali (telefon <-> masaustu esitleme) ve guncelleme kaynagi
  • Android imza anahtari (android/imza). KAYBOLURSA telefonlar yeni surumu kuramaz.

Dosyanin tamami kullanicinin belirledigi yedek sifresiyle sifrelenir
(PBKDF2-HMAC-SHA256 + HMAC-SHA256 akis sifresi + HMAC dogrulama; ek kutuphane gerekmez).
"""
import base64
import datetime as dt
import hashlib
import hmac
import json
import os
import secrets
import zlib

BASLIK = b"GSTY1"
TUR = 200_000
GIZLI_ALANLAR = ("github_token", "smtp_sifre")          # bildirim.sifre_sakla ile saklananlar
YEREL_ALANLAR = ("vt_yolu",)                              # bilgisayara ozel; geri yuklemede sorulur
IMZA_DOSYALARI = ("gemisefer.jks", "sifre.txt")


class YedekHatasi(Exception):
    pass


# ------------------------------------------------------------------ sifreleme
def _anahtarlar(sifre, tuz):
    k = hashlib.pbkdf2_hmac("sha256", sifre.encode("utf-8"), tuz, TUR, dklen=64)
    return k[:32], k[32:]


def _akis(anahtar, nonce, uzunluk):
    blok, sayac = [], 0
    while sum(len(b) for b in blok) < uzunluk:
        blok.append(hmac.new(anahtar, nonce + sayac.to_bytes(8, "big"), hashlib.sha256).digest())
        sayac += 1
    return b"".join(blok)[:uzunluk]


def sifrele(veri: bytes, sifre: str) -> bytes:
    tuz, nonce = secrets.token_bytes(16), secrets.token_bytes(16)
    k_sif, k_mac = _anahtarlar(sifre, tuz)
    ham = zlib.compress(veri, 9)
    ct = bytes(a ^ b for a, b in zip(ham, _akis(k_sif, nonce, len(ham))))
    govde = BASLIK + tuz + nonce + ct
    return govde + hmac.new(k_mac, govde, hashlib.sha256).digest()


def coz(dosya: bytes, sifre: str) -> bytes:
    if not dosya.startswith(BASLIK) or len(dosya) < len(BASLIK) + 32 + 32:
        raise YedekHatasi("Bu bir Gemi Sefer Takibi yönetici yedeği değil.")
    govde, etiket = dosya[:-32], dosya[-32:]
    tuz, nonce = govde[5:21], govde[21:37]
    k_sif, k_mac = _anahtarlar(sifre, tuz)
    if not hmac.compare_digest(etiket, hmac.new(k_mac, govde, hashlib.sha256).digest()):
        raise YedekHatasi("Yedek şifresi yanlış (ya da dosya bozuk).")
    ct = govde[37:]
    return zlib.decompress(bytes(a ^ b for a, b in zip(ct, _akis(k_sif, nonce, len(ct)))))


# ------------------------------------------------------------------ yedek
def olustur(ayar, program_klasor, meta, sifre_coz, surum="", bilgisayar=""):
    """ayar: ayar sozlugu; meta: {'senkron_kanal','guncelleme_kaynagi'}; sifre_coz: bildirim.sifre_coz.
    Donus: yedek icerigi (dict, sifrelenmemis)."""
    a = dict(ayar)
    for k in GIZLI_ALANLAR:
        a[k] = sifre_coz(a.get(k, "")) if a.get(k) else ""
    imza = {}
    kl = os.path.join(program_klasor, "android", "imza")
    for ad in IMZA_DOSYALARI:
        yol = os.path.join(kl, ad)
        if os.path.isfile(yol):
            with open(yol, "rb") as f:
                imza[ad] = base64.b64encode(f.read()).decode()
    return {"tur": "gst_yonetici_yedegi", "surum": 1, "program_surum": surum,
            "tarih": dt.datetime.now().strftime("%d.%m.%Y %H:%M"), "bilgisayar": bilgisayar,
            "ayar": a, "meta": {k: v for k, v in (meta or {}).items() if v}, "imza": imza}


def kaydet(yol, icerik, sifre):
    if len(sifre) < 6:
        raise YedekHatasi("Yedek şifresi en az 6 karakter olmalı.")
    veri = sifrele(json.dumps(icerik, ensure_ascii=False).encode("utf-8"), sifre)
    gecici = yol + ".tmp"
    with open(gecici, "wb") as f:
        f.write(veri)
    os.replace(gecici, yol)


def ac(yol, sifre):
    with open(yol, "rb") as f:
        icerik = json.loads(coz(f.read(), sifre).decode("utf-8"))
    if icerik.get("tur") != "gst_yonetici_yedegi":
        raise YedekHatasi("Bu bir Gemi Sefer Takibi yönetici yedeği değil.")
    return icerik


def ayarlari_birlestir(mevcut, yedek_ayar, sifre_sakla, yerel_koru=True):
    """Yedekteki ayarlari mevcutun uzerine yazar; gizli alanlari bu bilgisayarda yeniden sifreler.
    yerel_koru: veritabani yolu gibi bilgisayara ozel alanlar mevcut haliyle kalir."""
    yeni = dict(mevcut)
    for k, v in yedek_ayar.items():
        if yerel_koru and k in YEREL_ALANLAR and mevcut.get(k):
            continue
        yeni[k] = v
    for k in GIZLI_ALANLAR:
        yeni[k] = sifre_sakla(yedek_ayar.get(k) or "")
    # yayin numarasi asla geri gitmesin
    yeni["yayin_no"] = max(int(mevcut.get("yayin_no") or 0), int(yedek_ayar.get("yayin_no") or 0))
    return yeni


def imzayi_yaz(program_klasor, imza):
    """Android imza dosyalarini yazar. Farkli bir imza zaten varsa yanina _eski olarak alinir.
    Donus: yazilan dosya adlari"""
    if not imza:
        return []
    kl = os.path.join(program_klasor, "android", "imza")
    if not os.path.isdir(os.path.join(program_klasor, "android")):
        return []
    os.makedirs(kl, exist_ok=True)
    yazilan = []
    for ad, b64 in imza.items():
        if ad not in IMZA_DOSYALARI:
            continue
        veri = base64.b64decode(b64)
        yol = os.path.join(kl, ad)
        if os.path.isfile(yol):
            with open(yol, "rb") as f:
                if f.read() == veri:
                    continue
            os.replace(yol, yol + "." + dt.datetime.now().strftime("%Y%m%d%H%M") + "_eski")
        with open(yol, "wb") as f:
            f.write(veri)
        yazilan.append(ad)
    return yazilan
