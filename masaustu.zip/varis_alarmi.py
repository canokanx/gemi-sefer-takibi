# -*- coding: utf-8 -*-
"""Varis alarmi: dunyanin herhangi bir yerindeki bir gemi, secilen noktanin cevresine (yaricap, deniz mili)
yaklasinca / girince / demirleyince-baglaninca / cikinca olay uretir. Program bu olaylari mail + bildirim yapar.

Konum kaynaklari (hangisi en yeniyse):
  • AIS (aisstream): tam konum. Kiyiya yakin, liman ve demir yerlerinde kapsama iyidir.
  • VesselFinder: ucretsiz sayfada konum ~1 dereceye yuvarlanir; sadece "yaklasik" destek olarak kullanilir.
    Asil katkisi: varis yeri, ETA ve demirde/bagli durumu.
"""
import datetime as dt
import math
import re
import time
import uuid

AYLAR = {a: i for i, a in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov",
                                     "dec"], 1)}
DEMIR_AIS = {1: "demirledi", 5: "yanaştı / bağlandı"}
TAZE_SN = 3 * 3600              # bundan eski konumla "girdi" denmez
VF_KABA_PAY_NM = 45             # VesselFinder'in yuvarlanmis (~1 derece) konumu icin pay
LIMAN_PAY_NM = 12               # VesselFinder'in "limana vardi" dedigi liman bolgeye bu kadar yakinsa bolgede say
VARSAYILAN_OLAYLAR = {"yaklasma": True, "giris": True, "durma": True, "cikis": False, "vf": True}
OLAY_ADI = {"yaklasma": "yaklaşıyor", "giris": "bölgeye girdi", "durma": "demirledi / yanaştı",
            "cikis": "bölgeden çıktı", "vf": "VesselFinder (varış yeri / ETA)"}


def yeni_alarm(k, ad, bolge_ad, lat, lon, yaricap_nm, olaylar=None, mmsi="", imo=""):
    return {"id": uuid.uuid4().hex[:10], "k": str(k), "ad": ad or str(k), "imo": imo, "mmsi": mmsi,
            "bolge_ad": bolge_ad or f"{lat:.3f}, {lon:.3f}", "lat": float(lat), "lon": float(lon),
            "yaricap": float(yaricap_nm), "olaylar": dict(VARSAYILAN_OLAYLAR, **(olaylar or {})),
            "aktif": True, "olusturma": dt.datetime.now().strftime("%d.%m.%Y %H:%M"), "durum": {}}


def mesafe_nm(lat1, lon1, lat2, lon2):
    r = 3440.065                    # dunya yaricapi (deniz mili)
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(min(1.0, math.sqrt(a)))


def yaklasma_siniri(alarm):
    r = float(alarm.get("yaricap") or 5)
    return max(r * 2, r + 10)


def _durma_metni(nav):
    """AIS kodu (int) ya da VesselFinder metni -> 'demirledi' / 'yanaştı / bağlandı' / None"""
    if isinstance(nav, int):
        return DEMIR_AIS.get(nav)
    n = str(nav or "").lower()
    if "anchor" in n or "demir" in n:
        return "demirledi"
    if "moored" in n or "bağlı" in n or "bagli" in n:
        return "yanaştı / bağlandı"
    return None


def degerlendir(alarm, konum, simdi=None):
    """konum: {lat, lon, t(epoch), kaynak, nav, sog}. alarm['durum'] guncellenir.
    Donus: [(tur, metin)] - tur: yaklasma|giris|durma|cikis (alarm['olaylar']'da kapali olanlar elenir)"""
    simdi = simdi or time.time()
    st = alarm.setdefault("durum", {})
    if not konum or konum.get("lat") is None:
        return []
    d = mesafe_nm(alarm["lat"], alarm["lon"], konum["lat"], konum["lon"])
    st.update(son_mesafe=round(d, 1), son_lat=konum["lat"], son_lon=konum["lon"], son_t=konum.get("t") or simdi,
              son_kaynak=konum.get("kaynak", ""), son_sog=konum.get("sog"))
    if konum.get("nav") is not None:
        st["son_nav"] = konum["nav"]
    if simdi - (konum.get("t") or simdi) > TAZE_SN:
        return []
    r = float(alarm.get("yaricap") or 5)
    yakin = yaklasma_siniri(alarm)
    ilk = not st.get("degerlendirildi")
    st["degerlendirildi"] = True
    olay = []
    if d <= r:
        if not st.get("iceride"):
            st["iceride"] = True
            st["yaklasti"] = True
            st["giris_t"] = simdi
            olay.append(("giris", "şu an bölgede" if ilk else "bölgeye girdi"))
        durma = _durma_metni(konum.get("nav"))
        if durma and not st.get("durdu"):
            st["durdu"] = True
            olay.append(("durma", durma))
    else:
        # kucuk salinimlarda cik-gir yapmasin; VesselFinder "bolgedeki limanda" diyorsa liman payi kadar tolerans
        cikis_siniri = (r + LIMAN_PAY_NM) if st.get("vf_icerde") else (r * 1.15 + 0.5)
        if st.get("iceride") and d > cikis_siniri:
            st["iceride"] = False
            st["durdu"] = False
            st["yaklasti"] = d <= yakin
            olay.append(("cikis", "bölgeden çıktı"))
        elif d <= yakin and not st.get("yaklasti") and not st.get("iceride"):
            st["yaklasti"] = True
            olay.append(("yaklasma", f"yaklaşıyor ({d:.0f} mil kaldı)"))
        elif d > yakin * 1.3 and not st.get("iceride"):
            st["yaklasti"] = False                              # uzaklasti: tekrar yaklasirsa yine haber ver
    return [(t, m) for t, m in olay if alarm.get("olaylar", {}).get(t, True)]


def eta_coz(metin, simdi=None):
    """VesselFinder 'Oct 17, 04:00' (UTC) -> datetime (UTC, naive) ya da None"""
    m = re.match(r"\s*([A-Za-z]{3})\w*\s+(\d{1,2}),?\s+(\d{1,2}):(\d{2})", metin or "")
    if not m or m.group(1).lower() not in AYLAR:
        return None
    simdi = simdi or dt.datetime.utcnow()
    ay, gun, sa, dk = AYLAR[m.group(1).lower()], int(m.group(2)), int(m.group(3)), int(m.group(4))
    try:
        adaylar = [dt.datetime(simdi.year + y, ay, gun, sa, dk) for y in (-1, 0, 1)]
    except ValueError:
        return None
    return min(adaylar, key=lambda x: abs((x - simdi).total_seconds()))


def vf_degerlendir(alarm, vf, simdi_utc=None):
    """VesselFinder bilgisinden olaylar. AIS gemiyi gormese de calisir:
      • gemi bolgedeki/yakinindaki limana VARDI (ARRIVED, ATA)  -> giris (+ demirde/bagli ise durma)
      • o limandan AYRILDI                                       -> cikis
      • varis yeri / ETA degisti, ETA yaklasti                    -> vf
    vf['varis_konum'] = (lat, lon): varis limaninin konumu (program bulup ekler).
    Donus: [(tur, metin)]"""
    if not vf:
        return []
    st = alarm.setdefault("durum", {})
    simdi_utc = simdi_utc or dt.datetime.utcnow()
    r = float(alarm.get("yaricap") or 5)
    olay = []
    varis, eta, ata = (vf.get("varis") or "").strip(), (vf.get("eta") or "").strip(), (vf.get("ata") or "").strip()
    ilk = not st.get("vf_kontrol")
    st["vf_kontrol"] = True

    # ---- liman varisi / ayrilisi
    lk = vf.get("varis_konum")
    limanda = bool(vf.get("vardi") and lk and mesafe_nm(alarm["lat"], alarm["lon"], lk[0], lk[1]) <= r + LIMAN_PAY_NM)
    ais_taze = st.get("son_kaynak") == "AIS" and st.get("son_mesafe") is not None \
        and time.time() - (st.get("son_t") or 0) < 3600
    ais_icerde = ais_taze and st["son_mesafe"] <= r
    if limanda and ais_taze and st["son_mesafe"] > r + LIMAN_PAY_NM:
        limanda = False                 # AIS gemiyi uzakta goruyor: VesselFinder'in bilgisi gecikmeli
    if limanda:
        if not st.get("vf_icerde"):
            st["vf_icerde"], st["vf_liman"] = True, varis
            if not st.get("iceride"):
                st["iceride"] = st["yaklasti"] = True
                olay.append(("giris", (f"şu an bölgede — {varis} limanında" if ilk else f"limana vardı: {varis}")
                             + (f" (ATA {ata})" if ata else "") + " • VesselFinder"))
        durma = _durma_metni(vf.get("nav"))
        if durma and not st.get("durdu"):
            st["durdu"] = True
            olay.append(("durma", f"{durma} ({varis}) • VesselFinder"))
    elif st.get("vf_icerde"):
        st["vf_icerde"] = False
        if st.get("iceride") and not ais_icerde:
            st["iceride"] = st["durdu"] = st["yaklasti"] = False
            atd = vf.get("son_liman_zaman") or ""
            olay.append(("cikis", f"limandan ayrıldı: {st.get('vf_liman') or vf.get('son_liman') or '-'}"
                         + (f" ({atd})" if atd else "") + f" — yeni varış: {varis or '-'} • VesselFinder"))

    # ---- varis yeri / ETA
    onceki_v, onceki_e = st.get("vf_varis") or "", st.get("vf_eta") or ""
    if onceki_v and varis and varis != onceki_v and not limanda and not any(t == "cikis" for t, _ in olay):
        olay.append(("vf", f"varış yeri değişti: {onceki_v} → {varis}"))
    elif onceki_e and eta and eta != onceki_e:
        e1, e2 = eta_coz(onceki_e, simdi_utc), eta_coz(eta, simdi_utc)
        if not (e1 and e2) or abs((e2 - e1).total_seconds()) >= 2 * 3600:
            olay.append(("vf", f"ETA değişti: {onceki_e} → {eta} (UTC)"))
    st["vf_varis"], st["vf_eta"] = varis, eta
    e = eta_coz(eta, simdi_utc)
    if e and 0 < (e - simdi_utc).total_seconds() <= 6 * 3600 and st.get("eta_uyari") != eta \
            and not st.get("iceride"):
        st["eta_uyari"] = eta
        olay.append(("vf", f"ETA'ya 6 saatten az kaldı: {eta} (UTC) — varış: {varis or '-'}"))
    # AIS ve liman bilgisi yoksa: VesselFinder demirde/bagli diyor ve (yuvarlanmis) konum bolgeye yakin
    durma = _durma_metni(vf.get("nav"))
    if durma and not limanda and vf.get("lat") is not None and not st.get("durdu"):
        d = mesafe_nm(alarm["lat"], alarm["lon"], vf["lat"], vf["lon"])
        if d <= r + VF_KABA_PAY_NM:
            st["durdu"] = True
            olay.append(("durma", f"{durma} (VesselFinder'a göre, bölgenin yakınında)"))
    return [(t, m) for t, m in olay if alarm.get("olaylar", {}).get(t, True)]


def liman_arama_adi(ad):
    """'Tuzla Anch., Turkey' -> 'Tuzla, Turkey' (yer aramasi icin)"""
    ad = re.sub(r"\b(Anch(orage)?|Anc|OPL|Roads?|Port|Pt|Terminal|Term)\b\.?", "", ad or "", flags=re.I)
    return re.sub(r"\s+,", ",", re.sub(r"\s{2,}", " ", ad)).strip(" ,")


def durum_metni(alarm, simdi=None):
    """Listede gosterilecek kisa durum"""
    st = alarm.get("durum") or {}
    if not alarm.get("aktif", True):
        return "⏸ durduruldu"
    if st.get("iceride"):
        return "✅ " + ("demirde / bağlı" if st.get("durdu") else "bölgede")
    if st.get("son_mesafe") is None:
        if st.get("vf_varis"):
            return f"🚢 yolda → {st['vf_varis']}"
        return "⏳ konum bekleniyor"
    yas = (simdi or time.time()) - (st.get("son_t") or 0)
    eski = f" ({_sure(yas)} önce)" if yas > 1800 else ""
    return ("🔜 yaklaşıyor " if st.get("yaklasti") else "") + f"{st['son_mesafe']:.0f} mil{eski}"


def _sure(sn):
    sn = int(sn)
    if sn < 3600:
        return f"{sn // 60} dk"
    if sn < 86400:
        return f"{sn // 3600} sa"
    return f"{sn // 86400} gün"


def mail_icerigi(alarm, olaylar, konum_metni, firma="", imza="", vf=None):
    """(konu, duz_metin, html)"""
    ad = alarm.get("ad") or alarm.get("k")
    ana = olaylar[0][1]
    konu = (f"[{firma}] " if firma else "") + f"📍 {ad} — {alarm['bolge_ad']}: {ana}"
    st = alarm.get("durum") or {}
    satir = [f"Gemi: {ad}" + (f"  (IMO {alarm['imo']})" if alarm.get("imo") else "")
             + (f"  MMSI {alarm['mmsi']}" if alarm.get("mmsi") else ""),
             f"Bölge: {alarm['bolge_ad']}  (yarıçap {alarm['yaricap']:g} mil)"]
    satir += [f"• {m}" for _, m in olaylar]
    if st.get("son_mesafe") is not None:
        satir.append(f"Bölge merkezine uzaklık: {st['son_mesafe']:.1f} mil")
    if konum_metni:
        satir.append(konum_metni)
    if vf and vf.get("vardi"):
        satir.append(f"VesselFinder: {vf.get('varis') or '-'} limanında (ATA {vf.get('ata') or '-'})"
                     + (f" • {vf['nav']}" if vf.get("nav") else "") + (f" • konum {vf['konum_zamani']}" if vf.get("konum_zamani") else ""))
    elif vf and (vf.get("varis") or vf.get("eta")):
        satir.append(f"Varış (AIS beyanı): {vf.get('varis') or '-'}   ETA {vf.get('eta') or '-'} (UTC)")
    if vf and vf.get("son_liman"):
        satir.append(f"Son liman: {vf['son_liman']}  {vf.get('son_liman_zaman') or ''}".rstrip())
    k = alarm.get("imo") or alarm.get("mmsi") or alarm.get("k")
    satir.append(f"VesselFinder: https://www.vesselfinder.com/vessels/details/{k}")
    duz = "\n".join(satir) + f"\n\n{dt.datetime.now():%d.%m.%Y %H:%M}\n\n{imza}"
    esc = lambda s: str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    html = ("<div style='font-family:Segoe UI,Arial,sans-serif;font-size:14px;color:#1E2A2E'>"
            f"<div style='background:#0E7C86;color:#fff;padding:10px 14px;font-size:16px;font-weight:bold'>"
            f"📍 {esc(ad)} — {esc(alarm['bolge_ad'])}</div><div style='padding:10px 14px'>"
            + "".join(f"<div style='margin:3px 0'>{esc(s)}</div>" for s in satir[:-1])
            + f"<div style='margin-top:8px'><a href='{satir[-1].split(': ', 1)[1]}'>VesselFinder'da aç</a></div>"
            + f"<div style='margin-top:14px;color:#6B7C80;font-size:12px'>{dt.datetime.now():%d.%m.%Y %H:%M}<br>"
            + esc(imza).replace("\n", "<br>") + "</div></div></div>")
    return konu, duz, html
