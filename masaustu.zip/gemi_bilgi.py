# -*- coding: utf-8 -*-
"""Gemi bilgisi yardimcilari: IMO dogrulama, MMSI'den bayrak, AIS gemi tipi,
ve yerel 'gemi rehberi' (AIS'te gorulen her geminin IMO/MMSI/ad/bayrak kaydi).

Rehber, ortak veritabanindan AYRI, bilgisayardaki veri/rehber.db dosyasinda tutulur
(OneDrive senkronunu yormamak icin). Program acik kaldikca Marmara'dan gecen her gemi
rehbere eklenir; boylece IMO yazinca ad/MMSI/bayrak aninda dolar.
"""
import os
import sqlite3
import threading
import datetime as dt

# ITU MID (MMSI'nin ilk 3 hanesi) -> bayrak (Turkce)
_MID = {
    "Arnavutluk": [201], "Andorra": [202], "Avusturya": [203], "Azor Adaları": [204], "Belçika": [205],
    "Belarus": [206], "Bulgaristan": [207], "Vatikan": [208], "Kıbrıs": [209, 210, 212], "Almanya": [211, 218],
    "Gürcistan": [213], "Moldova": [214], "Malta": [215, 229, 248, 249, 256], "Ermenistan": [216],
    "Danimarka": [219, 220], "İspanya": [224, 225], "Fransa": [226, 227, 228], "Finlandiya": [230],
    "Faroe Adaları": [231], "Birleşik Krallık": [232, 233, 234, 235], "Cebelitarık": [236],
    "Yunanistan": [237, 239, 240, 241], "Hırvatistan": [238], "Fas": [242], "Macaristan": [243],
    "Hollanda": [244, 245, 246], "İtalya": [247], "İrlanda": [250], "İzlanda": [251], "Lihtenştayn": [252],
    "Lüksemburg": [253], "Monako": [254], "Madeira": [255], "Norveç": [257, 258, 259], "Polonya": [261],
    "Karadağ": [262], "Portekiz": [263], "Romanya": [264], "İsveç": [265, 266], "Slovakya": [267],
    "San Marino": [268], "İsviçre": [269], "Çekya": [270], "Türkiye": [271], "Ukrayna": [272], "Rusya": [273],
    "Kuzey Makedonya": [274], "Letonya": [275], "Estonya": [276], "Litvanya": [277], "Slovenya": [278],
    "Sırbistan": [279], "Anguilla": [301], "Alaska": [303], "Antigua ve Barbuda": [304, 305], "Curaçao": [306],
    "Aruba": [307], "Bahamalar": [308, 309, 311], "Bermuda": [310], "Belize": [312], "Barbados": [314],
    "Kanada": [316], "Cayman Adaları": [319], "Kosta Rika": [321], "Küba": [323], "Dominika": [325],
    "Dominik Cumhuriyeti": [327], "Guadeloupe": [329], "Grenada": [330], "Grönland": [331], "Guatemala": [332],
    "Ekvador": [735], "Honduras": [334], "Haiti": [336], "ABD": [338, 366, 367, 368, 369], "Jamaika": [339],
    "St. Kitts ve Nevis": [341], "St. Lucia": [343], "Meksika": [345], "Martinik": [347], "Montserrat": [348],
    "Nikaragua": [350], "Panama": [351, 352, 353, 354, 355, 356, 357, 370, 371, 372, 373, 374],
    "Porto Riko": [358], "El Salvador": [359], "St. Pierre": [361], "Trinidad ve Tobago": [362],
    "Turks ve Caicos": [364], "St. Vincent": [375, 376, 377], "Britanya Virjin Adaları": [378],
    "ABD Virjin Adaları": [379], "Afganistan": [401], "Suudi Arabistan": [403], "Bangladeş": [405],
    "Bahreyn": [408], "Bhutan": [410], "Çin": [412, 413, 414], "Tayvan": [416], "Sri Lanka": [417],
    "Hindistan": [419], "İran": [422], "Azerbaycan": [423], "Irak": [425], "İsrail": [428],
    "Japonya": [431, 432], "Türkmenistan": [434], "Kazakistan": [436], "Özbekistan": [437], "Ürdün": [438],
    "Güney Kore": [440, 441], "Filistin": [443], "Kuzey Kore": [445], "Kuveyt": [447], "Lübnan": [450],
    "Kırgızistan": [451], "Makao": [453], "Maldivler": [455], "Moğolistan": [457], "Nepal": [459],
    "Umman": [461], "Pakistan": [463], "Katar": [466], "Suriye": [468], "BAE": [470, 471],
    "Tacikistan": [472], "Yemen": [473, 475], "Hong Kong": [477], "Bosna-Hersek": [478], "Avustralya": [503],
    "Myanmar": [506], "Brunei": [508], "Mikronezya": [510], "Palau": [511], "Yeni Zelanda": [512],
    "Kamboçya": [514, 515], "Christmas Adası": [516], "Cook Adaları": [518], "Fiji": [520],
    "Endonezya": [525], "Kiribati": [529], "Laos": [531], "Malezya": [533], "Kuzey Mariana": [536],
    "Marshall Adaları": [538], "Yeni Kaledonya": [540], "Niue": [542], "Nauru": [544],
    "Fransız Polinezyası": [546], "Filipinler": [548], "Doğu Timor": [550], "Papua Yeni Gine": [553],
    "Pitcairn": [555], "Solomon Adaları": [557], "Amerikan Samoası": [559], "Samoa": [561],
    "Singapur": [563, 564, 565, 566], "Tayland": [567], "Tonga": [570], "Tuvalu": [572], "Vietnam": [574],
    "Vanuatu": [576, 577], "Wallis ve Futuna": [578], "Güney Afrika": [601], "Angola": [603], "Cezayir": [605],
    "Burundi": [609], "Benin": [610], "Botsvana": [611], "Orta Afrika": [612], "Kamerun": [613],
    "Kongo": [615], "Komorlar": [616], "Yeşil Burun": [617], "Fildişi Sahili": [619], "Cibuti": [621],
    "Mısır": [622], "Etiyopya": [624], "Eritre": [625], "Gabon": [626], "Gana": [627], "Gambiya": [629],
    "Gine-Bissau": [630], "Ekvator Ginesi": [631], "Gine": [632], "Burkina Faso": [633], "Kenya": [634],
    "Liberya": [636, 637], "Güney Sudan": [638], "Libya": [642], "Lesotho": [644], "Mauritius": [645],
    "Madagaskar": [647], "Mali": [649], "Mozambik": [650], "Moritanya": [654], "Malavi": [655],
    "Nijer": [656], "Nijerya": [657], "Namibya": [659], "Ruanda": [661], "Sudan": [662], "Senegal": [663],
    "Seyşeller": [664], "Sierra Leone": [667], "São Tomé": [668], "Somali": [666], "Esvatini": [669],
    "Çad": [670], "Togo": [671], "Tunus": [672], "Tanzanya": [674, 677], "Uganda": [675],
    "Kongo DC": [676], "Zambiya": [678], "Zimbabve": [679], "Arjantin": [701], "Brezilya": [710],
    "Bolivya": [720], "Şili": [725], "Kolombiya": [730], "Falkland": [740], "Guyana": [750],
    "Paraguay": [755], "Peru": [760], "Surinam": [765], "Uruguay": [770], "Venezuela": [775],
}
MID_BAYRAK = {str(m): ulke for ulke, liste in _MID.items() for m in liste}


def mmsi_bayrak(mmsi):
    m = str(mmsi or "").strip()
    if len(m) != 9 or not m.isdigit():
        return ""
    return MID_BAYRAK.get(m[:3], "")


def imo_gecerli(imo):
    """IMO kontrol hanesi: ilk 6 hanenin 7,6,5,4,3,2 ile carpimlari toplaminin son hanesi = 7. hane."""
    s = str(imo or "").strip()
    if s.upper().startswith("IMO"):
        s = s[3:].strip()
    if len(s) != 7 or not s.isdigit():
        return False
    return sum(int(s[i]) * (7 - i) for i in range(6)) % 10 == int(s[6])


def ais_tip_adi(t):
    try:
        t = int(t)
    except (TypeError, ValueError):
        return ""
    if 70 <= t <= 79:
        return "Kargo"
    if 80 <= t <= 89:
        return "Tanker"
    if 60 <= t <= 69:
        return "Yolcu"
    if t in (31, 32, 52):
        return "Römorkör"
    if t == 50:
        return "Pilot"
    if t == 30:
        return "Balıkçı"
    if 40 <= t <= 49:
        return "Hızlı tekne"
    if t in (36, 37):
        return "Gezi teknesi"
    return "Diğer"


class Rehber:
    """AIS'te gorulen gemilerin yerel kaydi (thread guvenli)."""
    def __init__(self, yol):
        self.yol = yol
        self.kilit = threading.Lock()
        self._yazilan = {}
        os.makedirs(os.path.dirname(os.path.abspath(yol)), exist_ok=True)
        with self._baglan() as c:
            c.execute("CREATE TABLE IF NOT EXISTS rehber (mmsi TEXT PRIMARY KEY, imo TEXT, ad TEXT, "
                      "tip INTEGER, bayrak TEXT, cagri TEXT, son TEXT)")
            c.execute("CREATE INDEX IF NOT EXISTS rehber_imo ON rehber(imo)")
            mevcut = {r[1] for r in c.execute("PRAGMA table_info(rehber)")}
            for sutun, tur in (("boy", "REAL"), ("en", "REAL"), ("draft", "REAL"), ("varis", "TEXT"), ("eta", "TEXT")):
                if sutun not in mevcut:
                    c.execute(f"ALTER TABLE rehber ADD COLUMN {sutun} {tur}")

    def _baglan(self):
        c = sqlite3.connect(self.yol, timeout=10)
        c.row_factory = sqlite3.Row
        return c

    def kaydet(self, mmsi, imo="", ad="", tip=None, cagri="", boy=None, en=None, draft=None, varis="", eta=""):
        mmsi = str(mmsi or "")
        if len(mmsi) != 9:
            return
        imo = str(imo or "") if imo_gecerli(imo) else ""
        ad = (ad or "").strip().strip("@").strip()
        anahtar = (imo, ad, tip, boy, en, draft, varis, eta)
        if self._yazilan.get(mmsi) == anahtar:
            return
        self._yazilan[mmsi] = anahtar
        with self.kilit:
            c = self._baglan()
            try:
                c.execute("INSERT INTO rehber(mmsi,imo,ad,tip,bayrak,cagri,son,boy,en,draft,varis,eta) "
                          "VALUES(?,?,?,?,?,?,?,?,?,?,?,?) "
                          "ON CONFLICT(mmsi) DO UPDATE SET "
                          "imo=CASE WHEN excluded.imo<>'' THEN excluded.imo ELSE rehber.imo END, "
                          "ad=CASE WHEN excluded.ad<>'' THEN excluded.ad ELSE rehber.ad END, "
                          "tip=COALESCE(excluded.tip, rehber.tip), bayrak=excluded.bayrak, "
                          "cagri=CASE WHEN excluded.cagri<>'' THEN excluded.cagri ELSE rehber.cagri END, "
                          "boy=COALESCE(excluded.boy, rehber.boy), en=COALESCE(excluded.en, rehber.en), "
                          "draft=COALESCE(excluded.draft, rehber.draft), "
                          "varis=CASE WHEN excluded.varis<>'' THEN excluded.varis ELSE rehber.varis END, "
                          "eta=CASE WHEN excluded.eta<>'' THEN excluded.eta ELSE rehber.eta END, "
                          "son=excluded.son",
                          (mmsi, imo, ad, tip, mmsi_bayrak(mmsi), (cagri or "").strip(),
                           dt.datetime.now().strftime("%d.%m.%Y %H:%M"), boy, en, draft,
                           (varis or "").strip(), eta or ""))
                c.commit()
            except sqlite3.Error:
                pass
            finally:
                c.close()

    def _bul(self, sql, arg):
        with self.kilit:
            c = self._baglan()
            try:
                r = c.execute(sql, (arg,)).fetchone()
                return dict(r) if r else None
            finally:
                c.close()

    def imo_ile(self, imo):
        return self._bul("SELECT * FROM rehber WHERE imo=? ORDER BY son DESC LIMIT 1", str(imo))

    def mmsi_ile(self, mmsi):
        return self._bul("SELECT * FROM rehber WHERE mmsi=?", str(mmsi))

    def sayi(self):
        with self.kilit:
            c = self._baglan()
            try:
                return c.execute("SELECT COUNT(*) FROM rehber").fetchone()[0]
            finally:
                c.close()
