# -*- coding: utf-8 -*-
"""Bir web sayfasini (VesselFinder haritasi) PROGRAM PENCERESININ ICINE gomer.

Nasil: vf_harita.py ayri bir islemde pywebview (Edge WebView2) penceresi acar; pencere ekran
disinda, cercevesiz baslar. Bu modul o pencereyi Windows API ile bulur ve Tk cercevesinin
"cocugu" yapar (SetParent). Kullanici ayri pencere gormez; harita sekmenin icinde durur ve
cerceve buyuyup kuculdukce harita da ona uyar.
"""
import json
import os
import sys
import subprocess
import tkinter as tk

WINDOWS = os.name == "nt"
if WINDOWS:
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.WinDLL("user32", use_last_error=True)
    GWL_STYLE = -16
    WS_CHILD = 0x40000000
    WS_POPUP = 0x80000000
    WS_CAPTION = 0x00C00000
    WS_THICKFRAME = 0x00040000
    WS_SYSMENU = 0x00080000
    WS_MINIMIZEBOX = 0x00020000
    WS_MAXIMIZEBOX = 0x00010000
    WS_VISIBLE = 0x10000000
    SW_SHOW = 5
    EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    user32.GetWindowLongW.restype = ctypes.c_long
    user32.SetWindowLongW.restype = ctypes.c_long
    user32.SetParent.restype = wintypes.HWND
    user32.SetParent.argtypes = [wintypes.HWND, wintypes.HWND]
    user32.MoveWindow.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.BOOL]


def _pencere_bul(pid, baslik_basi):
    """Verilen islemin, basligi baslik_basi ile baslayan ust duzey penceresini bul."""
    bulunan = []

    def geri(hwnd, _):
        p = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(p))
        if p.value == pid:
            uz = user32.GetWindowTextLengthW(hwnd)
            buf = ctypes.create_unicode_buffer(uz + 1)
            user32.GetWindowTextW(hwnd, buf, uz + 1)
            if buf.value.startswith(baslik_basi):
                bulunan.append(hwnd)
                return False
        return True
    user32.EnumWindows(EnumWindowsProc(geri), 0)
    return bulunan[0] if bulunan else None


class GomuluWeb:
    BASLIK = "Gemi Sefer Takibi — VesselFinder"

    def __init__(self, cerceve, python_yolu, betik, durum=None):
        self.cerceve = cerceve            # tk.Frame: haritanin gomulecegi alan
        self.python = python_yolu
        self.betik = betik
        self.durum = durum or (lambda m: None)
        self.islem = None
        self.hwnd = None
        self._deneme = 0
        self.mesaj = tk.Label(cerceve, text="", bg="#F4F8F8", fg="#6B7C80", font=("Segoe UI", 11))
        self.mesaj.place(relx=0.5, rely=0.45, anchor="center")
        cerceve.bind("<Configure>", lambda e: self._boyutla())

    def ac(self, parametre):
        self.kapat()
        if not WINDOWS:
            self.mesaj.config(text="VesselFinder haritası sadece Windows'ta gösterilebilir.")
            return
        self.mesaj.config(text="VesselFinder haritası yükleniyor…")
        p = dict(parametre)
        p["gomulu"] = True
        p["ana_pid"] = os.getpid()
        try:
            self.islem = subprocess.Popen([self.python, self.betik, json.dumps(p, ensure_ascii=False)],
                                          cwd=os.path.dirname(self.betik))
        except Exception as e:
            self.mesaj.config(text=f"Harita açılamadı: {e}")
            return
        self._deneme = 0
        self.cerceve.after(250, self._yakala)

    def _yakala(self):
        """WebView penceresi olusunca onu cercevenin icine al."""
        if self.islem is None:
            return
        if self.islem.poll() is not None:
            self.mesaj.config(text="VesselFinder haritası açılamadı (pywebview kurulu olmayabilir).")
            self.islem = None
            return
        hwnd = _pencere_bul(self.islem.pid, self.BASLIK)
        if not hwnd:
            self._deneme += 1
            if self._deneme > 120:          # ~30 sn
                self.mesaj.config(text="VesselFinder haritası zaman aşımına uğradı.")
                self.kapat()
                return
            self.cerceve.after(250, self._yakala)
            return
        stil = user32.GetWindowLongW(hwnd, GWL_STYLE)
        stil &= ~(WS_POPUP | WS_CAPTION | WS_THICKFRAME | WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX)
        stil |= WS_CHILD | WS_VISIBLE
        user32.SetWindowLongW(hwnd, GWL_STYLE, ctypes.c_long(stil & 0xFFFFFFFF).value)
        user32.SetParent(hwnd, self.cerceve.winfo_id())
        self.hwnd = hwnd
        self.mesaj.config(text="")
        self._boyutla()
        user32.ShowWindow(hwnd, SW_SHOW)
        # WebView2 ilk boyutlamayi bazen kaciriyor: kisa araliklarla bir kac kez daha boyutla
        for gecikme in (300, 900, 2000):
            self.cerceve.after(gecikme, self._boyutla)

    def _boyutla(self):
        if WINDOWS and self.hwnd:
            w, h = max(50, self.cerceve.winfo_width()), max(50, self.cerceve.winfo_height())
            user32.MoveWindow(self.hwnd, 0, 0, w, h, True)

    def kapat(self):
        self.hwnd = None
        if self.islem is not None and self.islem.poll() is None:
            try:
                self.islem.terminate()
            except Exception:
                pass
        self.islem = None
