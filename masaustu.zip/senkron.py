# -*- coding: utf-8 -*-
"""Telefon <-> masaustu takip listesi esitleme.

Telefonda bir gemi takibe alininca (ya da birakilinca) telefon kucuk bir mesaj gonderir; masaustu
program acikken dakikada bir bu mesajlari okur, gemiyi kendi takip listesine ekler ve statusu
degisince mail atar. Masaustunde yapilan degisiklik de ayni yolla telefonlara gider.

Arada ucretsiz ntfy.sh bildirim servisi kullanilir (hesap gerekmez). Mesajlar tahmin edilemeyen
gizli bir kanal adina gider ve 12 saat saklanir. Sadece gemi adi ve IMO/MMSI gider.
"""
import json
import secrets
import urllib.parse
import urllib.request

SUNUCU = "https://ntfy.sh"


def yeni_kanal():
    return "gst-" + secrets.token_hex(16)


def kanal_al(vt):
    """Ekibin ortak kanali (ortak veritabaninda). Yoksa olusturur."""
    k = vt.meta_al("senkron_kanal")
    if not k:
        k = yeni_kanal()
        vt.meta_yaz("senkron_kanal", k)
    return k


def gonder(kanal, veri, zaman_asimi=20):
    istek = urllib.request.Request(f"{SUNUCU}/{kanal}", data=json.dumps(veri, ensure_ascii=False).encode("utf-8"),
                                   method="POST", headers={"User-Agent": "GemiSeferTakibi", "Cache": "yes"})
    with urllib.request.urlopen(istek, timeout=zaman_asimi) as r:
        return json.loads(r.read().decode("utf-8") or "{}")


def cek(kanal, since="12h", zaman_asimi=20):
    """Kanaldaki mesajlar: [(mesaj_id, veri_dict)] (eskiden yeniye)."""
    url = f"{SUNUCU}/{kanal}/json?poll=1&since={urllib.parse.quote(str(since or '12h'))}"
    istek = urllib.request.Request(url, headers={"User-Agent": "GemiSeferTakibi"})
    with urllib.request.urlopen(istek, timeout=zaman_asimi) as r:
        govde = r.read().decode("utf-8")
    return coz(govde)


def coz(ndjson):
    sonuc = []
    for satir in ndjson.splitlines():
        satir = satir.strip()
        if not satir:
            continue
        try:
            m = json.loads(satir)
        except ValueError:
            continue
        if m.get("event") != "message":
            continue
        try:
            veri = json.loads(m.get("message") or "{}")
        except ValueError:
            continue
        if isinstance(veri, dict) and veri.get("tur") in ("takip", "liste"):
            sonuc.append((m.get("id"), veri))
    return sonuc


def uygula(takip_listesi, olaylar, benim_cihaz):
    """takip_listesi: [{'k','ad'}]. Donus: (yeni_liste, eklenenler, cikarilanlar)"""
    liste = [dict(t) for t in takip_listesi if t.get("k")]
    var = {t["k"] for t in liste}
    eklenen, cikan = [], []
    for _, v in olaylar:
        if v.get("cihaz") == benim_cihaz:
            continue
        if v.get("tur") == "takip":
            k, ad = str(v.get("k") or ""), v.get("ad") or ""
            if not k:
                continue
            if v.get("islem") == "ekle" and k not in var:
                liste.append({"k": k, "ad": ad})
                var.add(k)
                eklenen.append(ad or k)
            elif v.get("islem") == "cikar" and k in var:
                liste = [t for t in liste if t["k"] != k]
                var.discard(k)
                cikan.append(ad or k)
        elif v.get("tur") == "liste":
            for t in v.get("liste") or []:
                k = str(t.get("k") or "")
                if k and k not in var:
                    liste.append({"k": k, "ad": t.get("ad") or ""})
                    var.add(k)
                    eklenen.append(t.get("ad") or k)
    return liste, eklenen, cikan
