# -*- coding: utf-8 -*-
"""Windows kisayol (.lnk) dosyasini PowerShell/COM KULLANMADAN, dogrudan dosya bicimiyle yazar
(Microsoft [MS-SHLLINK] bicimi). Turkce karakterli yollar (CanOkanAktaş) Unicode olarak saklanir.

Kullanim:
  python lnk_olustur.py CIKTI.lnk HEDEF.exe "ARGUMANLAR" CALISMA_KLASORU IKON.ico ["ACIKLAMA"]
"""
import struct
import sys

CLSID = bytes.fromhex("0114020000000000C000000000000046")
HAS_LINK_INFO, HAS_NAME, HAS_WORKING_DIR, HAS_ARGUMENTS, HAS_ICON, IS_UNICODE = 0x2, 0x4, 0x10, 0x20, 0x40, 0x80


def _metin(s):
    """StringData: karakter sayisi (2 bayt) + UTF-16LE (sonda sifir yok)."""
    b = s.encode("utf-16-le")
    return struct.pack("<H", len(b) // 2) + b


def _link_info(hedef):
    ansi = hedef.encode("cp1254", "replace") + b"\0"
    uni = hedef.encode("utf-16-le") + b"\0\0"
    volume = struct.pack("<IIII", 0x11, 3, 0, 0x10) + b"\0"      # sabit disk, etiket bos
    bas = 0x24
    vol_off = bas
    yol_off = vol_off + len(volume)
    ek_off = yol_off + len(ansi)
    yol_u_off = ek_off + 1
    ek_u_off = yol_u_off + len(uni)
    toplam = ek_u_off + 2
    baslik = struct.pack("<IIIIIIIII", toplam, bas, 1, vol_off, yol_off, 0, ek_off, yol_u_off, ek_u_off)
    return baslik + volume + ansi + b"\0" + uni + b"\0\0"


def lnk_yaz(cikti, hedef, argumanlar="", klasor="", ikon="", aciklama=""):
    bayrak = HAS_LINK_INFO | IS_UNICODE
    veri = b""
    if aciklama:
        bayrak |= HAS_NAME
        veri += _metin(aciklama)
    if klasor:
        bayrak |= HAS_WORKING_DIR
        veri += _metin(klasor)
    if argumanlar:
        bayrak |= HAS_ARGUMENTS
        veri += _metin(argumanlar)
    if ikon:
        bayrak |= HAS_ICON
        veri += _metin(ikon)
    baslik = struct.pack("<I16sII8s8s8sIiIHHII", 0x4C, CLSID, bayrak, 0x20,
                         b"\0" * 8, b"\0" * 8, b"\0" * 8, 0, 0, 1, 0, 0, 0, 0)
    assert len(baslik) == 0x4C
    with open(cikti, "wb") as f:
        f.write(baslik + _link_info(hedef) + veri + b"\0\0\0\0")


if __name__ == "__main__":
    a = sys.argv[1:]
    lnk_yaz(a[0], a[1], a[2] if len(a) > 2 else "", a[3] if len(a) > 3 else "",
            a[4] if len(a) > 4 else "", a[5] if len(a) > 5 else "")
