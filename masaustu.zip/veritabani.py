# -*- coding: utf-8 -*-
"""Gemi Sefer Takibi - veritabani katmani (SQLite).

Veritabani dosyasi ortak bir klasorde (OneDrive / ag klasoru) durabilir.
Ag klasorlerinde WAL calismadigi icin klasik journal + uzun busy_timeout kullanilir.
Her islem kendi kisa baglantisini acip kapatir; boylece kilit uzun sure tutulmaz.

Surum 2: Seferler kaldirildi. Hatirlatmalar dogrudan gemiye baglidir.
Eski 'seferler'/'belgeler' tablolari silinmez; icindeki belgeler bir kere
'hatirlatmalar' tablosuna tasinir.
"""
import os
import sqlite3
import datetime as dt

from gemi_bilgi import imo_gecerli

TARIH_FMT = "%d.%m.%Y %H:%M"

# (belge adi, hangi tarihe gore, saat farki)
STANDART_BELGELER = [
    ("Pre-Arrival / Geliş Bildirimi (LTP)", "eta", -24),
    ("Mürettebat & Yolcu Listesi", "eta", -24),
    ("Gümrük Giriş Beyanı", "eta", -12),
    ("NOR (Notice of Readiness)", "eta", 0),
    ("Liman Başkanlığı Giriş İzni", "eta", 0),
    ("SOF (Statement of Facts)", "etd", 0),
    ("Ayrılış Bildirimi (LTP)", "etd", -6),
    ("Liman Çıkış Belgesi", "etd", 0),
]

SEMA = """
CREATE TABLE IF NOT EXISTS gemiler (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ad TEXT NOT NULL,
    imo TEXT, mmsi TEXT, bayrak TEXT, tip TEXT, dwt TEXT, notlar TEXT
);
CREATE TABLE IF NOT EXISTS hatirlatmalar (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    gemi_id INTEGER NOT NULL,
    ad TEXT NOT NULL, son_tarih TEXT, tamam INTEGER DEFAULT 0,
    dosya TEXT, notlar TEXT, guncelleyen TEXT, guncelleme TEXT
);
CREATE TABLE IF NOT EXISTS ais_konum (
    mmsi TEXT PRIMARY KEY,
    gemi_adi TEXT, lat REAL, lon REAL, sog REAL, cog REAL,
    nav_durum INTEGER, zaman TEXT
);
CREATE TABLE IF NOT EXISTS kayit_gunlugu (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    zaman TEXT, kim TEXT, islem TEXT
);
CREATE TABLE IF NOT EXISTS meta (anahtar TEXT PRIMARY KEY, deger TEXT);
CREATE TABLE IF NOT EXISTS kurulumlar (bilgisayar TEXT PRIMARY KEY, kullanici TEXT, surum TEXT, zaman TEXT);
"""


# ---------------------------------------------------------------- tarih yardimcilari
def simdi_str():
    return dt.datetime.now().strftime(TARIH_FMT)


def tarih_coz(metin):
    """'18.10.2026 14:30', '18.10.2026', '18.10 14:30', '18/10/26' gibi girisleri cozer.
    Bos ise None, hataliysa ValueError."""
    if metin is None:
        return None
    m = str(metin).strip()
    if not m:
        return None
    m = m.replace("/", ".").replace("-", ".").replace("  ", " ")
    yil = dt.datetime.now().year
    for fmt in ("%d.%m.%Y %H:%M", "%d.%m.%Y %H.%M", "%d.%m.%y %H:%M", "%d.%m.%Y",
                "%d.%m.%y", "%d.%m.%Y %H%M"):
        try:
            return dt.datetime.strptime(m, fmt)
        except ValueError:
            pass
    for fmt in ("%d.%m %H:%M", "%d.%m"):
        try:
            t = dt.datetime.strptime(m, fmt)
            return t.replace(year=yil)
        except ValueError:
            pass
    raise ValueError(f"Tarih anlaşılamadı: '{metin}'  (örnek: 18.10.2026 14:30)")


def tarih_normal(metin):
    t = tarih_coz(metin)
    return t.strftime(TARIH_FMT) if t else ""


# ---------------------------------------------------------------- Turkce harf yardimcilari
_TR_UST = str.maketrans({"i": "İ", "ı": "I"})
_TR_ALT = str.maketrans({"İ": "i", "I": "ı"})


def tr_upper(s):
    return (s or "").translate(_TR_UST).upper()


def tr_lower(s):
    return (s or "").translate(_TR_ALT).lower()


_TR_HARFLER = set("ıİğĞşŞçÇöÖüÜ")


def gemi_adi_buyuk(s):
    """Gemi adlari cogu zaman yabancidir (IRONHULL ONE). Turkce harf varsa Turkce kurala,
    yoksa standart kurala gore buyutur; boylece 'ironhull' -> 'İRONHULL' olmaz."""
    s = (s or "").strip()
    return tr_upper(s) if any(h in _TR_HARFLER for h in s) else s.upper()


# ---------------------------------------------------------------- veritabani
class GemiZatenVar(ValueError):
    def __init__(self, gemi):
        self.gemi = gemi
        super().__init__(f"{gemi['ad']} zaten kayıtlı.")


class Veritabani:
    def __init__(self, yol, kullanici="?"):
        self.yol = yol
        self.kullanici = kullanici or "?"
        klasor = os.path.dirname(os.path.abspath(yol))
        os.makedirs(klasor, exist_ok=True)
        with self._baglan() as c:
            c.executescript(SEMA)
        for adim in (self._eski_belgeleri_tasi, self._ais_hdg_sutunu, self._gemi_sutunlari,
                     self.tekrar_eden_gemileri_birlestir):
            try:
                adim()
            except sqlite3.Error:
                pass

    def _baglan(self):
        c = sqlite3.connect(self.yol, timeout=15)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA busy_timeout = 15000")
        c.execute("PRAGMA journal_mode = DELETE")
        return c

    def _calistir(self, sql, args=()):
        c = self._baglan()
        try:
            cur = c.execute(sql, args)
            c.commit()
            return cur.lastrowid
        finally:
            c.close()

    def _sorgu(self, sql, args=()):
        c = self._baglan()
        try:
            return [dict(r) for r in c.execute(sql, args).fetchall()]
        finally:
            c.close()

    # ---- gecis (surum 1 -> 2)
    def _meta(self, anahtar, deger=None):
        if deger is None:
            r = self._sorgu("SELECT deger FROM meta WHERE anahtar=?", (anahtar,))
            return r[0]["deger"] if r else None
        self._calistir("INSERT OR REPLACE INTO meta(anahtar,deger) VALUES(?,?)", (anahtar, deger))

    # ---- ortak ayarlar (ekip) ve kurulum listesi
    def meta_al(self, anahtar):
        return self._meta(anahtar)

    def meta_yaz(self, anahtar, deger):
        self._meta(anahtar, deger)

    def kurulum_bildir(self, bilgisayar, kullanici, surum):
        self._calistir("INSERT OR REPLACE INTO kurulumlar(bilgisayar,kullanici,surum,zaman) VALUES(?,?,?,?)",
                       (bilgisayar, kullanici, surum, simdi_str()))

    def kurulumlar(self):
        return self._sorgu("SELECT * FROM kurulumlar ORDER BY zaman DESC")

    def _tablo_var(self, ad):
        return bool(self._sorgu("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (ad,)))

    def _eski_belgeleri_tasi(self):
        if self._meta("belgeler_tasindi"):
            return
        if self._tablo_var("belgeler") and self._tablo_var("seferler"):
            self._calistir(
                "INSERT INTO hatirlatmalar(gemi_id,ad,son_tarih,tamam,dosya,notlar,guncelleyen,guncelleme) "
                "SELECT s.gemi_id,b.ad,b.son_tarih,b.tamam,b.dosya,b.notlar,b.guncelleyen,b.guncelleme "
                "FROM belgeler b JOIN seferler s ON s.id=b.sefer_id")
        self._meta("belgeler_tasindi", simdi_str())

    def _gemi_sutunlari(self):
        mevcut = {r["name"] for r in self._sorgu("PRAGMA table_info(gemiler)")}
        for sutun in ("cagri", "boy", "en", "draft", "grt", "yapim"):
            if sutun not in mevcut:
                self._calistir(f"ALTER TABLE gemiler ADD COLUMN {sutun} TEXT")

    def _ais_hdg_sutunu(self):
        sutunlar = {r["name"] for r in self._sorgu("PRAGMA table_info(ais_konum)")}
        if "hdg" not in sutunlar:
            self._calistir("ALTER TABLE ais_konum ADD COLUMN hdg REAL")

    # ---- gunluk
    def gunluk(self, islem):
        self._calistir("INSERT INTO kayit_gunlugu(zaman,kim,islem) VALUES(?,?,?)",
                       (simdi_str(), self.kullanici, islem))

    def son_degisiklik(self):
        r = self._sorgu("SELECT MAX(id) AS m FROM kayit_gunlugu")
        return r[0]["m"] or 0

    def gunluk_listesi(self, adet=200):
        return self._sorgu("SELECT * FROM kayit_gunlugu ORDER BY id DESC LIMIT ?", (adet,))

    # ---- gemiler
    def gemiler(self):
        return self._sorgu("SELECT g.*, a.lat, a.lon, a.sog, a.cog, a.hdg, a.nav_durum, a.zaman AS ais_zaman, "
                           "(SELECT COUNT(*) FROM hatirlatmalar h WHERE h.gemi_id=g.id AND h.tamam=0) AS acik "
                           "FROM gemiler g LEFT JOIN ais_konum a ON a.mmsi=g.mmsi "
                           "ORDER BY g.ad COLLATE NOCASE")

    def gemi(self, gid):
        r = self._sorgu("SELECT * FROM gemiler WHERE id=?", (gid,))
        return r[0] if r else None

    @staticmethod
    def _ayni_mi(a, b):
        imo_a, imo_b = (a.get("imo") or "").strip(), (b.get("imo") or "").strip()
        mm_a, mm_b = (a.get("mmsi") or "").strip(), (b.get("mmsi") or "").strip()
        if imo_a and imo_b:
            return imo_a == imo_b
        if mm_a and mm_b:
            return mm_a == mm_b
        return (a.get("ad") or "").strip() == (b.get("ad") or "").strip() != ""

    def ayni_gemi_bul(self, ad, imo, mmsi, haric=None):
        yeni = {"ad": ad, "imo": imo, "mmsi": mmsi}
        for g in self._sorgu("SELECT * FROM gemiler"):
            if g["id"] != haric and self._ayni_mi(yeni, g):
                return g
        return None

    def gemi_kaydet(self, veri, gid=None):
        alanlar = ["ad", "imo", "mmsi", "bayrak", "tip", "dwt", "notlar", "cagri", "boy", "en", "draft", "grt", "yapim"]
        degerler = [(str(veri.get(a) or "")).strip() for a in alanlar]
        degerler[0] = gemi_adi_buyuk(degerler[0])
        imo, mmsi = degerler[1], degerler[2]
        if imo.upper().startswith("IMO"):
            imo = degerler[1] = imo[3:].strip()
        if not degerler[0] and imo:
            degerler[0] = f"IMO {imo}"          # ad AIS'ten bulununca degisir
        if not degerler[0]:
            raise ValueError("Gemi adı ya da IMO yazın.")
        if mmsi and (not mmsi.isdigit() or len(mmsi) != 9):
            raise ValueError("MMSI 9 haneli bir sayı olmalı.")
        if imo and (not imo.isdigit() or len(imo) != 7):
            raise ValueError("IMO 7 haneli bir sayı olmalı.")
        if imo and not imo_gecerli(imo):
            raise ValueError(f"IMO {imo} hatalı görünüyor (son hane kontrolü tutmuyor). Lütfen kontrol edin.")
        ayni = self.ayni_gemi_bul(degerler[0], imo, mmsi, haric=gid)
        if ayni:
            raise GemiZatenVar(ayni)
        if gid:
            self._calistir(f"UPDATE gemiler SET {', '.join(a + '=?' for a in alanlar)} WHERE id=?",
                           degerler + [gid])
            self.gunluk(f"Gemi güncellendi: {degerler[0]}")
            return gid
        yeni = self._calistir(f"INSERT INTO gemiler({','.join(alanlar)}) VALUES({','.join('?' * len(alanlar))})",
                              degerler)
        self.gunluk(f"Gemi eklendi: {degerler[0]}")
        return yeni

    def gemi_bilgi_doldur(self, gid, mmsi="", ad="", bayrak="", tip="", **ek):
        """AIS'ten bulunan bilgileri gemideki BOS alanlara yazar (ad 'IMO 1234567' ise degistirir)."""
        g = self.gemi(gid)
        if not g:
            return
        degis = {}
        if mmsi and not (g.get("mmsi") or "").strip():
            degis["mmsi"] = mmsi
        ad = gemi_adi_buyuk(ad)
        if ad and (not g.get("ad") or g["ad"].startswith("IMO ")):
            degis["ad"] = ad
        if bayrak and not (g.get("bayrak") or "").strip():
            degis["bayrak"] = bayrak
        if tip and not (g.get("tip") or "").strip():
            degis["tip"] = tip
        for k in ("cagri", "boy", "en", "draft", "dwt", "grt", "yapim"):
            v = ek.get(k)
            if v not in (None, "") and k in g and not str(g.get(k) or "").strip():
                degis[k] = str(v)
        if not degis:
            return
        self._calistir(f"UPDATE gemiler SET {', '.join(k + '=?' for k in degis)} WHERE id=?",
                       list(degis.values()) + [gid])
        self.gunluk(f"Gemi bilgisi dolduruldu: {degis.get('ad', g['ad'])} ({', '.join(degis)})")

    def gemi_imo_ile(self, imo):
        r = self._sorgu("SELECT * FROM gemiler WHERE imo=?", (str(imo),))
        return r[0] if r else None

    def tekrar_eden_gemileri_birlestir(self):
        """Ayni gemi iki kez kaydedildiyse (ayni IMO/MMSI ya da ayni ad) tek kayitta birlestirir."""
        gemiler = sorted(self._sorgu("SELECT * FROM gemiler"), key=lambda g: g["id"])
        silinen = set()
        sayi = 0
        alanlar = ["imo", "mmsi", "bayrak", "tip", "dwt", "notlar", "cagri", "boy", "en", "draft", "grt", "yapim"]
        eski_seferler = self._tablo_var("seferler")
        for i, ana in enumerate(gemiler):
            if ana["id"] in silinen:
                continue
            for diger in gemiler[i + 1:]:
                if diger["id"] in silinen or not self._ayni_mi(ana, diger):
                    continue
                for a in alanlar:
                    if not (ana.get(a) or "").strip() and (diger.get(a) or "").strip():
                        ana[a] = diger[a]
                self._calistir(f"UPDATE gemiler SET {', '.join(a + '=?' for a in alanlar)} WHERE id=?",
                               [ana.get(a) or "" for a in alanlar] + [ana["id"]])
                self._calistir("UPDATE hatirlatmalar SET gemi_id=? WHERE gemi_id=?", (ana["id"], diger["id"]))
                if eski_seferler:
                    self._calistir("UPDATE seferler SET gemi_id=? WHERE gemi_id=?", (ana["id"], diger["id"]))
                self._calistir("DELETE FROM gemiler WHERE id=?", (diger["id"],))
                silinen.add(diger["id"])
                sayi += 1
                self.gunluk(f"Çift kayıt birleştirildi: {ana['ad']}")
        return sayi

    def gemi_sil(self, gid):
        g = self.gemi(gid)
        self._calistir("DELETE FROM hatirlatmalar WHERE gemi_id=?", (gid,))
        self._calistir("DELETE FROM gemiler WHERE id=?", (gid,))
        self.gunluk(f"Gemi silindi: {g['ad'] if g else gid}")

    # ---- hatirlatmalar
    def hatirlatma_listesi(self, gid=None, sadece_acik=False):
        sql = ("SELECT h.*, g.ad AS gemi_adi FROM hatirlatmalar h "
               "JOIN gemiler g ON g.id=h.gemi_id WHERE 1=1 ")
        args = []
        if gid:
            sql += "AND h.gemi_id=? "
            args.append(gid)
        if sadece_acik:
            sql += "AND h.tamam=0 "
        rows = self._sorgu(sql, args)

        def anahtar(r):
            try:
                t = tarih_coz(r["son_tarih"])
            except ValueError:
                t = None
            return (r["tamam"], t or dt.datetime.max)
        return sorted(rows, key=anahtar)

    def hatirlatma(self, hid):
        r = self._sorgu("SELECT * FROM hatirlatmalar WHERE id=?", (hid,))
        return r[0] if r else None

    def hatirlatma_kaydet(self, veri, hid=None):
        ad = (veri.get("ad") or "").strip()
        if not ad:
            raise ValueError("Hatırlatma / belge adı boş olamaz.")
        if not veri.get("gemi_id"):
            raise ValueError("Gemi seçilmedi.")
        son = tarih_normal(veri.get("son_tarih"))
        args = [int(veri["gemi_id"]), ad, son, int(bool(veri.get("tamam"))), (veri.get("dosya") or "").strip(),
                (veri.get("notlar") or "").strip(), self.kullanici, simdi_str()]
        if hid:
            self._calistir("UPDATE hatirlatmalar SET gemi_id=?, ad=?, son_tarih=?, tamam=?, dosya=?, notlar=?, "
                           "guncelleyen=?, guncelleme=? WHERE id=?", args + [hid])
            self.gunluk(f"Hatırlatma güncellendi: {ad}")
            return hid
        yeni = self._calistir("INSERT INTO hatirlatmalar(gemi_id,ad,son_tarih,tamam,dosya,notlar,guncelleyen,guncelleme) "
                              "VALUES(?,?,?,?,?,?,?,?)", args)
        self.gunluk(f"Hatırlatma eklendi: {ad}")
        return yeni

    def hatirlatma_tamam(self, hid, tamam=True):
        self._calistir("UPDATE hatirlatmalar SET tamam=?, guncelleyen=?, guncelleme=? WHERE id=?",
                       (int(tamam), self.kullanici, simdi_str(), hid))
        h = self.hatirlatma(hid)
        self.gunluk(f"Hatırlatma {'tamamlandı' if tamam else 'yeniden açıldı'}: {h['ad'] if h else hid}")

    def hatirlatma_sil(self, hid):
        h = self.hatirlatma(hid)
        self._calistir("DELETE FROM hatirlatmalar WHERE id=?", (hid,))
        self.gunluk(f"Hatırlatma silindi: {h['ad'] if h else hid}")

    def standart_belgeleri_ekle(self, gid, eta="", etd=""):
        g = self.gemi(gid)
        if not g:
            return 0
        tarihler = {"eta": tarih_coz(eta) if eta else None, "etd": tarih_coz(etd) if etd else None}
        mevcut = {h["ad"] for h in self.hatirlatma_listesi(gid, sadece_acik=True)}
        eklenen = 0
        for ad, kaynak, saat in STANDART_BELGELER:
            if ad in mevcut:
                continue
            temel = tarihler[kaynak]
            son = (temel + dt.timedelta(hours=saat)).strftime(TARIH_FMT) if temel else ""
            self._calistir("INSERT INTO hatirlatmalar(gemi_id,ad,son_tarih,tamam,guncelleyen,guncelleme) "
                           "VALUES(?,?,?,0,?,?)", (gid, ad, son, self.kullanici, simdi_str()))
            eklenen += 1
        if eklenen:
            self.gunluk(f"Standart belgeler eklendi ({eklenen}): {g['ad']}")
        return eklenen

    def yaklasanlar(self, saat_ileri=24):
        """Gecikmis + yaklasan acik hatirlatmalar."""
        simdi = dt.datetime.now()
        sinir = simdi + dt.timedelta(hours=saat_ileri)
        sonuc = []
        for h in self.hatirlatma_listesi(sadece_acik=True):
            try:
                t = tarih_coz(h["son_tarih"])
            except ValueError:
                continue
            if t and t <= sinir:
                sonuc.append({"anahtar": f"h{h['id']}-{h['son_tarih']}", "zaman": t, "gecikti": t < simdi,
                              "metin": f"{h['gemi_adi']} — {h['ad']}", "id": h["id"]})
        return sorted(sonuc, key=lambda x: x["zaman"])

    # ---- AIS
    def takip_mmsileri(self):
        """MMSI'si girili butun gemiler izlenir."""
        r = self._sorgu("SELECT mmsi, ad FROM gemiler WHERE mmsi<>'' AND mmsi IS NOT NULL")
        return {x["mmsi"]: x["ad"] for x in r}

    def mmsisiz_gemiler(self):
        return self._sorgu("SELECT id, ad, imo FROM gemiler WHERE mmsi IS NULL OR mmsi='' ORDER BY ad")

    def ais_kaydet(self, mmsi, ad, lat, lon, sog, cog, nav, zaman, hdg=None):
        self._calistir("INSERT INTO ais_konum(mmsi,gemi_adi,lat,lon,sog,cog,nav_durum,zaman,hdg) "
                       "VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(mmsi) DO UPDATE SET "
                       "gemi_adi=excluded.gemi_adi, lat=excluded.lat, lon=excluded.lon, sog=excluded.sog, "
                       "cog=excluded.cog, nav_durum=excluded.nav_durum, zaman=excluded.zaman, hdg=excluded.hdg",
                       (mmsi, ad, lat, lon, sog, cog, nav, zaman, hdg))

    def ais_konum_al(self, mmsi):
        r = self._sorgu("SELECT * FROM ais_konum WHERE mmsi=?", (str(mmsi),))
        return r[0] if r else None

    def ais_konumlar(self):
        return self._sorgu("SELECT a.*, g.ad AS kayitli_ad, g.imo, g.id AS gemi_id FROM ais_konum a "
                           "JOIN gemiler g ON g.mmsi=a.mmsi")
