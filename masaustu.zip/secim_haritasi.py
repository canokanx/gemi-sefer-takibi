# -*- coding: utf-8 -*-
"""Programin icinde kucuk bir harita: noktaya tikla, yaricapi ciz (varis alarmi icin).

Ek kutuphane gerekmez (Tk Canvas + Pillow + requests). Karolar OpenStreetMap + OpenSeaMap deniz isaretleri;
diskte onbellege alinir (harita_katman). Yer arama: OpenStreetMap Nominatim.
Surukle = kaydir, tekerlek / +- = yakinlastir, tikla = nokta sec.
"""
import math
import queue
import threading
import tkinter as tk
from tkinter import ttk

import requests
from PIL import Image, ImageTk

import harita_katman

KARO = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
UST = "https://tiles.openseamap.org/seamark/{z}/{x}/{y}.png"
UA = {"User-Agent": "GemiSeferTakibi/2.0 (IRONHULL Marine Services desktop app)"}
MIN_Z, MAX_Z = 2, 17


def dunya_px(lat, lon, z):
    n = 256 * (2 ** z)
    lat = max(-85.0511, min(85.0511, lat))
    x = (lon + 180.0) / 360.0 * n
    s = math.sin(math.radians(lat))
    y = (0.5 - math.log((1 + s) / (1 - s)) / (4 * math.pi)) * n
    return x, y


def px_dunya(x, y, z):
    n = 256 * (2 ** z)
    lon = x / n * 360.0 - 180.0
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * y / n))))
    return lat, lon


def yer_ara(metin, adet=6):
    """Nominatim: [(ad, lat, lon)]"""
    r = requests.get("https://nominatim.openstreetmap.org/search",
                     params={"q": metin, "format": "json", "limit": adet, "accept-language": "tr,en"},
                     headers=UA, timeout=15)
    r.raise_for_status()
    return [(x.get("display_name", ""), float(x["lat"]), float(x["lon"])) for x in r.json()]


class SecimHaritasi(tk.Frame):
    def __init__(self, ebeveyn, lat=40.9, lon=28.9, z=7, yaricap_nm=5.0, nokta=None, degisti=None,
                 genislik=560, yukseklik=420):
        super().__init__(ebeveyn, bg="#AAD3DF")
        self.z = z
        self.cx, self.cy = dunya_px(lat, lon, z)
        self.nokta = nokta                     # (lat, lon)
        self.yaricap = float(yaricap_nm)
        self.gemi = None                       # (lat, lon, etiket)
        self.degisti = degisti
        self.c = tk.Canvas(self, width=genislik, height=yukseklik, bg="#AAD3DF", highlightthickness=0,
                           cursor="crosshair")
        self.c.pack(fill="both", expand=True)
        self.resimler = {}                     # (z, x, y) -> PhotoImage
        self.istenen = set()
        self.is_kuyrugu = queue.LifoQueue()
        self.sonuc = queue.Queue()
        self._surukle = None
        for _ in range(4):
            threading.Thread(target=self._isci, daemon=True).start()
        dg = tk.Frame(self, bg="white")
        dg.place(relx=1.0, x=-8, y=8, anchor="ne")
        for t, d in (("+", 1), ("−", -1)):
            tk.Button(dg, text=t, width=2, relief="flat", bg="white", font=("Segoe UI", 11, "bold"),
                      command=lambda d=d: self.yakinlas(d)).pack()
        tk.Label(self, text="© OpenStreetMap katkıcıları • OpenSeaMap", bg="white", fg="#555",
                 font=("Segoe UI", 7)).place(relx=1.0, rely=1.0, anchor="se")
        self.c.bind("<Configure>", lambda e: self.ciz())
        self.c.bind("<ButtonPress-1>", self._bas)
        self.c.bind("<B1-Motion>", self._suruk)
        self.c.bind("<ButtonRelease-1>", self._birak)
        self.c.bind("<MouseWheel>", lambda e: self.yakinlas(1 if e.delta > 0 else -1, e.x, e.y))
        self.c.bind("<Button-4>", lambda e: self.yakinlas(1, e.x, e.y))
        self.c.bind("<Button-5>", lambda e: self.yakinlas(-1, e.x, e.y))
        self.after(60, self._sonuclari_al)

    # ------------------------------------------------------------ karolar
    def _isci(self):
        while True:
            z, x, y = self.is_kuyrugu.get()
            try:
                alt = harita_katman._karo_al(KARO, z, x, y)
                if alt is None:
                    continue
                if z >= 8:
                    ust = harita_katman._karo_al(UST, z, x, y, bos_olabilir=True)
                    if ust is not None:
                        alt = Image.alpha_composite(alt, ust)
                self.sonuc.put(((z, x, y), alt))
            except Exception:
                pass
            finally:
                self.istenen.discard((z, x, y))

    def _sonuclari_al(self):
        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return
        yeni = False
        try:
            while True:
                anahtar, img = self.sonuc.get_nowait()
                self.resimler[anahtar] = ImageTk.PhotoImage(img)
                yeni = True
        except queue.Empty:
            pass
        if yeni:
            self.ciz()
        self.after(80, self._sonuclari_al)

    # ------------------------------------------------------------ cizim
    def ekran(self, lat, lon):
        x, y = dunya_px(lat, lon, self.z)
        return x - self.cx + self.c.winfo_width() / 2, y - self.cy + self.c.winfo_height() / 2

    def konum(self, ex, ey):
        return px_dunya(self.cx + ex - self.c.winfo_width() / 2, self.cy + ey - self.c.winfo_height() / 2, self.z)

    def ciz(self):
        c = self.c
        g, h = max(c.winfo_width(), 2), max(c.winfo_height(), 2)
        c.delete("all")
        sol, ust = self.cx - g / 2, self.cy - h / 2
        n = 2 ** self.z
        for tx in range(int(sol // 256), int((sol + g) // 256) + 1):
            for ty in range(int(ust // 256), int((ust + h) // 256) + 1):
                if not 0 <= ty < n:
                    continue
                kx = tx % n
                anahtar = (self.z, kx, ty)
                img = self.resimler.get(anahtar)
                if img is not None:
                    c.create_image(tx * 256 - sol, ty * 256 - ust, image=img, anchor="nw")
                elif anahtar not in self.istenen:
                    self.istenen.add(anahtar)
                    self.is_kuyrugu.put(anahtar)
        if len(self.resimler) > 400:                  # bellek: baska zoom seviyelerini at
            for k in [k for k in self.resimler if k[0] != self.z][:200]:
                del self.resimler[k]
        if self.gemi:
            x, y = self.ekran(self.gemi[0], self.gemi[1])
            c.create_polygon(x, y - 9, x + 6, y + 6, x - 6, y + 6, fill="#1565C0", outline="white", width=1.5)
            c.create_text(x + 9, y - 4, text=self.gemi[2], anchor="w", fill="#0D47A1",
                          font=("Segoe UI", 8, "bold"))
        if self.nokta:
            x, y = self.ekran(*self.nokta)
            mpp = 156543.03392 * math.cos(math.radians(self.nokta[0])) / (2 ** self.z)
            r = self.yaricap * 1852 / mpp
            r2 = max(self.yaricap * 2, self.yaricap + 10) * 1852 / mpp
            c.create_oval(x - r2, y - r2, x + r2, y + r2, outline="#F2704F", dash=(4, 4), width=1.5)
            c.create_oval(x - r, y - r, x + r, y + r, outline="#C62828", width=2, stipple="gray25", fill="#F2704F")
            c.create_oval(x - 4, y - 4, x + 4, y + 4, fill="#C62828", outline="white", width=1.5)

    # ------------------------------------------------------------ etkilesim
    def _bas(self, e):
        self._surukle = (e.x, e.y, self.cx, self.cy, False)

    def _suruk(self, e):
        if not self._surukle:
            return
        x0, y0, cx0, cy0, _ = self._surukle
        if abs(e.x - x0) + abs(e.y - y0) > 4:
            self._surukle = (x0, y0, cx0, cy0, True)
            self.cx, self.cy = cx0 - (e.x - x0), cy0 - (e.y - y0)
            self.ciz()

    def _birak(self, e):
        if self._surukle and not self._surukle[4]:
            self.nokta_sec(*self.konum(e.x, e.y))
        self._surukle = None

    def yakinlas(self, d, ex=None, ey=None):
        yeni = max(MIN_Z, min(MAX_Z, self.z + d))
        if yeni == self.z:
            return
        g, h = self.c.winfo_width(), self.c.winfo_height()
        ex = g / 2 if ex is None else ex
        ey = h / 2 if ey is None else ey
        lat, lon = self.konum(ex, ey)
        self.z = yeni
        x, y = dunya_px(lat, lon, yeni)
        self.cx, self.cy = x - (ex - g / 2), y - (ey - h / 2)
        self.ciz()

    def git(self, lat, lon, z=None):
        if z is not None:
            self.z = max(MIN_Z, min(MAX_Z, z))
        self.cx, self.cy = dunya_px(lat, lon, self.z)
        self.ciz()

    def nokta_sec(self, lat, lon, bildir=True):
        self.nokta = (lat, lon)
        self.ciz()
        if bildir and self.degisti:
            self.degisti(lat, lon)

    def yaricap_ayarla(self, nm):
        try:
            self.yaricap = max(0.2, float(str(nm).replace(",", ".")))
        except ValueError:
            return
        self.ciz()

    def gemi_goster(self, lat, lon, etiket):
        self.gemi = (lat, lon, etiket) if lat is not None else None
        self.ciz()

    def yaricapa_sigdir(self):
        """Secili daire ekrana sigacak sekilde yakinlastir."""
        if not self.nokta:
            return
        g = max(self.c.winfo_width(), 300)
        for z in range(MAX_Z, MIN_Z - 1, -1):
            mpp = 156543.03392 * math.cos(math.radians(self.nokta[0])) / (2 ** z)
            if 2 * max(self.yaricap * 2, self.yaricap + 10) * 1852 / mpp < g * 0.9:
                self.git(self.nokta[0], self.nokta[1], z)
                return
