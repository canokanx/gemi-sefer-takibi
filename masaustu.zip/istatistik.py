# -*- coding: utf-8 -*-
"""Bogaz bekleme suresi istatistigi.

Kiyi Emniyeti listesi 5 dakikada bir alindiginda her gemi icin gozlem kaydedilir:
  ilk gorulme (listeye girdigi an), BOGAZDA durumuna gectigi an, listeden ciktigi an.
Bekleme suresi  = BOGAZDA - ilk gorulme
Gecis suresi    = listeden cikis - BOGAZDA
Program kapaliyken gecen sure bilinemez: o aralikta listeye giren gemiler 'belirsiz' isaretlenir
ve ortalamaya katilmaz. Ilk calistirmada listede zaten olan gemiler de katilmaz.
"""
import sqlite3
import statistics
import datetime as dt

BOSLUK_SN = 15 * 60          # iki gozlem arasi bundan uzunsa "program kapaliydi" sayilir
BOY_SINIF = [(0, 150, "< 150 m"), (150, 200, "150–200 m"), (200, 250, "200–250 m"), (250, 9999, "≥ 250 m")]
ZB = "%Y-%m-%d %H:%M:%S"


def _boy(x):
    try:
        return float(str(x).replace(",", "."))
    except (TypeError, ValueError):
        return None


def boy_sinifi(boy):
    b = _boy(boy)
    if b is None:
        return "?"
    for alt, ust, ad in BOY_SINIF:
        if alt <= b < ust:
            return ad
    return "?"


class Istatistik:
    def __init__(self, yol):
        self.yol = yol
        with self._baglan() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS gozlem(
                anahtar TEXT PRIMARY KEY, bogaz TEXT, yon TEXT, imo TEXT, ad TEXT, tip TEXT, boy TEXT,
                ilk TEXT, bogazda TEXT, son TEXT, cikis TEXT, durum TEXT, belirsiz INTEGER DEFAULT 0)""")
            c.execute("CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT)")
            c.execute("CREATE INDEX IF NOT EXISTS g_ilk ON gozlem(ilk)")

    def _baglan(self):
        c = sqlite3.connect(self.yol, timeout=10)
        c.row_factory = sqlite3.Row
        return c

    # ------------------------------------------------------------ kayit
    def gozlem_ekle(self, veri, simdi=None):
        """veri: BogazSirasi.veri ({'I': [...], 'C': [...]}). Basarili bir liste alindiginda cagrilir."""
        if not (veri.get("I") or veri.get("C")):
            return
        simdi = simdi or dt.datetime.now()
        z = simdi.strftime(ZB)
        with self._baglan() as c:
            r = c.execute("SELECT v FROM meta WHERE k='son_gozlem'").fetchone()
            onceki = dt.datetime.strptime(r["v"], ZB) if r else None
            belirsiz = 1 if (onceki is None or (simdi - onceki).total_seconds() > BOSLUK_SN) else 0
            gorulen = set()
            for kod in ("I", "C"):
                for s in veri.get(kod) or []:
                    anahtar = f"{kod}:{s.get('seq') or (s.get('imo') or '') + ':' + (s.get('ad') or '')}"
                    gorulen.add(anahtar)
                    eski = c.execute("SELECT * FROM gozlem WHERE anahtar=?", (anahtar,)).fetchone()
                    bogazda = s.get("durum") == "BOĞAZDA"
                    if eski is None:
                        c.execute("INSERT INTO gozlem(anahtar,bogaz,yon,imo,ad,tip,boy,ilk,bogazda,son,durum,belirsiz) "
                                  "VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                                  (anahtar, kod, s.get("yon") or "", s.get("imo") or "", s.get("ad") or "",
                                   s.get("tip") or "", s.get("boy") or "", z, z if bogazda else None, z,
                                   s.get("durum") or "", belirsiz))
                    else:
                        bz = eski["bogazda"] or (z if bogazda else None)
                        bz_belirsiz = eski["belirsiz"]
                        if bogazda and not eski["bogazda"] and belirsiz:
                            bz_belirsiz = 1          # BOGAZDA'ya gecis program kapaliyken olmus olabilir
                        c.execute("UPDATE gozlem SET son=?, bogazda=?, durum=?, yon=COALESCE(NULLIF(?,''),yon), "
                                  "cikis=NULL, belirsiz=? WHERE anahtar=?",
                                  (z, bz, s.get("durum") or "", s.get("yon") or "", bz_belirsiz, anahtar))
            # listeden cikanlar (program kapaliyken ciktiysa cikis zamani belirsiz)
            for x in c.execute("SELECT anahtar FROM gozlem WHERE cikis IS NULL").fetchall():
                if x["anahtar"] not in gorulen:
                    c.execute("UPDATE gozlem SET cikis=son" + (", belirsiz=1" if belirsiz else "") + " WHERE anahtar=?",
                              (x["anahtar"],))
            c.execute("INSERT OR REPLACE INTO meta(k,v) VALUES('son_gozlem',?)", (z,))
            c.execute("INSERT OR IGNORE INTO meta(k,v) VALUES('ilk_gozlem',?)", (z,))
            # 120 gunden eski kayitlari temizle
            c.execute("DELETE FROM gozlem WHERE ilk < ?", ((simdi - dt.timedelta(days=120)).strftime(ZB),))

    # ------------------------------------------------------------ hesap
    def _sureler(self, gun, simdi=None):
        simdi = simdi or dt.datetime.now()
        bas = (simdi - dt.timedelta(days=gun)).strftime(ZB)
        with self._baglan() as c:
            return [dict(r) for r in c.execute("SELECT * FROM gozlem WHERE ilk >= ?", (bas,)).fetchall()]

    @staticmethod
    def _dk(a, b):
        return (dt.datetime.strptime(b, ZB) - dt.datetime.strptime(a, ZB)).total_seconds() / 60

    def ozet(self, gun=7, simdi=None):
        """{'gruplar': [{bogaz, yon, sayi, bekleme_ort, bekleme_med, bekleme_max, gecis_ort}],
            'boy': [{bogaz, yon, sinif, sayi, bekleme_ort}], 'saatlik': {bogaz: [24 sayi]},
            'toplam': n, 'baslangic': 'dd.mm.YYYY HH:MM'}"""
        kayit = self._sureler(gun, simdi)
        gruplar, boy, saatlik = {}, {}, {"I": [0] * 24, "C": [0] * 24}
        for k in kayit:
            if k["bogazda"]:
                saatlik[k["bogaz"]][int(k["bogazda"][11:13])] += 1
            if k["belirsiz"] or not k["bogazda"]:
                continue
            bek = self._dk(k["ilk"], k["bogazda"])
            if bek < 0:
                continue
            g = gruplar.setdefault((k["bogaz"], k["yon"] or ""), {"bek": [], "gec": []})
            g["bek"].append(bek)
            if k["cikis"]:
                gs = self._dk(k["bogazda"], k["cikis"])
                if 0 <= gs < 24 * 60:
                    g["gec"].append(gs)
            boy.setdefault((k["bogaz"], k["yon"] or "", boy_sinifi(k["boy"])), []).append(bek)
        with self._baglan() as c:
            r = c.execute("SELECT v FROM meta WHERE k='ilk_gozlem'").fetchone()
        sonuc = {"gruplar": [], "boy": [], "saatlik": saatlik, "toplam": len(kayit),
                 "baslangic": dt.datetime.strptime(r["v"], ZB).strftime("%d.%m.%Y %H:%M") if r else ""}
        for (b, y), g in sorted(gruplar.items()):
            sonuc["gruplar"].append({"bogaz": b, "yon": y, "sayi": len(g["bek"]),
                                     "bekleme_ort": statistics.mean(g["bek"]), "bekleme_med": statistics.median(g["bek"]),
                                     "bekleme_max": max(g["bek"]),
                                     "gecis_ort": statistics.mean(g["gec"]) if g["gec"] else None})
        sira = {ad: i for i, (_, _, ad) in enumerate(BOY_SINIF)}
        for (b, y, sinif), v in sorted(boy.items(), key=lambda x: (x[0][0], x[0][1], sira.get(x[0][2], 9))):
            sonuc["boy"].append({"bogaz": b, "yon": y, "sinif": sinif, "sayi": len(v), "bekleme_ort": statistics.mean(v)})
        return sonuc

    def tahmini_bekleme(self, bogaz, yon, boy=None, gun=14):
        """Bu bogaz/yon (ve boy sinifi) icin medyan bekleme (dk) ya da None"""
        kayit = self._sureler(gun)
        sinif = boy_sinifi(boy) if boy else None
        v = [self._dk(k["ilk"], k["bogazda"]) for k in kayit
             if not k["belirsiz"] and k["bogazda"] and k["bogaz"] == bogaz and (k["yon"] or "") == (yon or "")
             and (sinif is None or boy_sinifi(k["boy"]) == sinif)]
        v = [x for x in v if x >= 0]
        return statistics.median(v) if len(v) >= 3 else None


def sure_metni(dk):
    if dk is None:
        return "—"
    dk = int(round(dk))
    if dk < 60:
        return f"{dk} dk"
    s, d = divmod(dk, 60)
    if s < 48:
        return f"{s} sa {d:02d} dk"
    g, s = divmod(s, 24)
    return f"{g} gün {s} sa"
