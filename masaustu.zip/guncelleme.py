# -*- coding: utf-8 -*-
"""Otomatik guncelleme (masaustu + Android).

Yonetici "Guncelleme Yayinla" deyince yayin klasorune (ekibin ortak Google Drive / OneDrive / ag klasoru)
su dosyalar yazilir:
  surum.json            -> surumler ve baglantilar (programlar ve telefonlar bunu okur)
  masaustu.zip          -> masaustu programin dosyalari
  GemiSeferTakibi.apk   -> Android uygulamasi
  index.html            -> Android arayuzu (APK degismeden telefona gider)

Dosyalar YERINDE uzerine yazilir (silip yeniden olusturulmaz); boylece Google Drive'daki paylasim
baglantilari degismez.

Ekipteki masaustu programlar guncelleme kaynagini (yayin klasoru ya da surum.json baglantisi) ortak
veritabanindan okur, yeni surum gorunce indirip kurar ve kendini yeniden baslatir.
"""
import io
import json
import os
import re
import shutil
import tempfile
import zipfile
import datetime as dt
import urllib.request
import urllib.error

PAKET_UZANTI = (".py", ".pyw", ".txt")
PAKET_KLASOR = ("kaynak",)
HARIC = ("android", "kurulum", "veri", "_yedek", "__pycache__")


def surum_tuple(s):
    return tuple(int(x) for x in re.findall(r"\d+", str(s or "0"))) or (0,)


def daha_yeni(a, b):
    """a, b'den yeni mi?"""
    return surum_tuple(a) > surum_tuple(b)


def drive_dogrudan(url):
    """Google Drive / Dropbox paylasim baglantisini dogrudan indirme baglantisina cevirir."""
    url = (url or "").strip()
    m = re.search(r"drive\.google\.com/(?:file/d/|open\?id=|uc\?(?:[^#]*&)?id=)([A-Za-z0-9_-]{10,})", url)
    if m:
        return f"https://drive.google.com/uc?export=download&id={m.group(1)}"
    if "dropbox.com" in url:
        return url.replace("dl=0", "dl=1")
    return url


# ====================================================================== yayinlama (yonetici)
def masaustu_paketi(program_klasor):
    """Program dosyalarini zip olarak (bayt) dondurur."""
    b = io.BytesIO()
    with zipfile.ZipFile(b, "w", zipfile.ZIP_DEFLATED) as z:
        for ad in sorted(os.listdir(program_klasor)):
            yol = os.path.join(program_klasor, ad)
            if os.path.isfile(yol) and ad.endswith(PAKET_UZANTI) and not ad.startswith(("test", "_")) \
                    and ad != "yuklu_surum.txt":
                z.write(yol, ad)
        for k in PAKET_KLASOR:
            kok = os.path.join(program_klasor, k)
            for d, _, fs in os.walk(kok):
                for f in fs:
                    tam = os.path.join(d, f)
                    z.write(tam, os.path.relpath(tam, program_klasor).replace("\\", "/"))
    return b.getvalue()


def _yerinde_yaz(yol, veri):
    """Dosyayi silmeden uzerine yazar (Drive/OneDrive paylasim baglantisi ayni kalsin)."""
    with open(yol, "r+b" if os.path.exists(yol) else "wb") as f:
        f.seek(0)
        f.write(veri)
        f.truncate()


def paket_hazirla(program_klasor, surum, notlar="", baglantilar=None):
    """Yayinlanacak dosyalar: {ad: bayt}, surum bilgisi (dict).
    baglantilar: {'apk', 'web', 'masaustu'} -> surum.json'a yazilacak indirme baglantilari"""
    baglantilar = baglantilar or {}
    dosyalar = {"masaustu.zip": masaustu_paketi(program_klasor)}
    bilgi = {"masaustu_surum": surum, "masaustu_dosya": "masaustu.zip", "notlar": notlar,
             "tarih": dt.datetime.now().strftime("%d.%m.%Y %H:%M")}
    if baglantilar.get("masaustu"):
        bilgi["masaustu_url"] = drive_dogrudan(baglantilar["masaustu"])
    android = os.path.join(program_klasor, "android")
    sb = os.path.join(android, "surum_bilgi.json")
    if os.path.exists(sb):
        a = json.load(open(sb, encoding="utf-8"))
        apk = os.path.join(android, "GemiSeferTakibi.apk")
        web = os.path.join(android, "web", "index.html")
        if os.path.exists(apk):
            dosyalar["GemiSeferTakibi.apk"] = open(apk, "rb").read()
            bilgi.update(apk_surum=int(a.get("apk_surum", 1)), apk_ad=str(a.get("apk_ad", "")),
                         apk_url=drive_dogrudan(baglantilar.get("apk", "")))
        if os.path.exists(web):
            dosyalar["index.html"] = open(web, "rb").read()
            bilgi.update(web_surum=int(a.get("web_surum", 1)), web_url=drive_dogrudan(baglantilar.get("web", "")))
    dosyalar["surum.json"] = json.dumps(bilgi, ensure_ascii=False, indent=2).encode("utf-8")
    return dosyalar, bilgi


def yayinla(program_klasor, yayin_klasoru, surum, notlar="", baglantilar=None):
    """Ortak klasore yayin. Donus: (yazilan dosyalar, bilgi)"""
    dosyalar, bilgi = paket_hazirla(program_klasor, surum, notlar, baglantilar)
    os.makedirs(yayin_klasoru, exist_ok=True)
    sira = [d for d in dosyalar if d != "surum.json"] + ["surum.json"]   # surum.json en son
    for ad in sira:
        _yerinde_yaz(os.path.join(yayin_klasoru, ad), dosyalar[ad])
    return ["surum.json"] + sira[:-1], bilgi


# ====================================================================== GitHub ile yayin
GITHUB_API = "https://api.github.com"


def github_raw(sahip, depo, dosya, dal="main"):
    return f"https://raw.githubusercontent.com/{sahip}/{depo}/{dal}/{dosya}"


def _github(yontem, yol, token, govde=None):
    veri = json.dumps(govde).encode("utf-8") if govde is not None else None
    istek = urllib.request.Request(GITHUB_API + yol, data=veri, method=yontem, headers={
        "Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "GemiSeferTakibi"})
    try:
        with urllib.request.urlopen(istek, timeout=120) as r:
            icerik = r.read()
            return r.status, (json.loads(icerik) if icerik else {})
    except urllib.error.HTTPError as e:
        try:
            ayrinti = json.loads(e.read() or b"{}")
        except ValueError:
            ayrinti = {}
        return e.code, ayrinti


def github_test(sahip, depo, token):
    """Donus: (tamam, mesaj). Depo yoksa olusturur (herkese acik)."""
    kod, kul = _github("GET", "/user", token)
    if kod == 401:
        return False, "Token geçersiz ya da süresi dolmuş."
    if kod != 200:
        return False, f"GitHub'a bağlanılamadı (HTTP {kod})."
    if kul.get("login", "").lower() != sahip.lower():
        return False, f"Token '{kul.get('login')}' hesabına ait; kullanıcı adı '{sahip}' yazılmış."
    kod, d = _github("GET", f"/repos/{sahip}/{depo}", token)
    if kod == 404:
        kod, d = _github("POST", "/user/repos", token, {
            "name": depo, "private": False, "auto_init": True,
            "description": "Gemi Sefer Takibi güncelleme dosyaları (otomatik)"})
        if kod not in (200, 201):
            return False, f"Depo oluşturulamadı: {d.get('message', kod)} (token'da 'public_repo' izni olmalı)"
        return True, f"'{depo}' deposu oluşturuldu."
    if kod != 200:
        return False, f"Depoya erişilemedi: {d.get('message', kod)}"
    if d.get("private"):
        return False, "Depo GİZLİ. Telefonların indirebilmesi için depo herkese açık (public) olmalı."
    return True, f"Bağlantı tamam: github.com/{sahip}/{depo}"


def github_yayinla(program_klasor, sahip, depo, token, surum, notlar="", dal="main"):
    """Dosyalari GitHub deposuna yukler. Baglantilar otomatik: raw.githubusercontent.com"""
    import base64
    tamam, mesaj = github_test(sahip, depo, token)
    if not tamam:
        raise RuntimeError(mesaj)
    baglanti = {"apk": github_raw(sahip, depo, "GemiSeferTakibi.apk", dal),
                "web": github_raw(sahip, depo, "index.html", dal),
                "masaustu": github_raw(sahip, depo, "masaustu.zip", dal)}
    dosyalar, bilgi = paket_hazirla(program_klasor, surum, notlar, baglanti)
    sira = [d for d in dosyalar if d != "surum.json"] + ["surum.json"]   # surum.json en son
    for ad in sira:
        kod, mevcut = _github("GET", f"/repos/{sahip}/{depo}/contents/{ad}?ref={dal}", token)
        govde = {"message": f"Gemi Sefer Takibi {surum}: {ad}", "branch": dal,
                 "content": base64.b64encode(dosyalar[ad]).decode("ascii")}
        if kod == 200 and isinstance(mevcut, dict) and mevcut.get("sha"):
            govde["sha"] = mevcut["sha"]
        kod, d = _github("PUT", f"/repos/{sahip}/{depo}/contents/{ad}", token, govde)
        if kod not in (200, 201):
            raise RuntimeError(f"{ad} yüklenemedi: {d.get('message', kod)}")
    return sira, bilgi, github_raw(sahip, depo, "surum.json", dal)


# ====================================================================== istemci (ekipteki programlar)
def _oku(kaynak, dosya=None, zaman_asimi=30):
    """kaynak: yayin klasoru yolu ya da surum.json URL'si. dosya: klasordeki dosya adi (None = surum.json)."""
    kaynak = (kaynak or "").strip()
    if not kaynak:
        raise ValueError("Güncelleme kaynağı yok")
    if kaynak.lower().startswith(("http://", "https://")):
        url = drive_dogrudan(kaynak) if dosya is None else dosya
        if "raw.githubusercontent.com" in url:
            url += ("&" if "?" in url else "?") + "t=" + dt.datetime.now().strftime("%Y%m%d%H%M")
        istek = urllib.request.Request(url, headers={"User-Agent": "GemiSeferTakibi"})
        with urllib.request.urlopen(istek, timeout=zaman_asimi) as r:
            return r.read()
    with open(os.path.join(kaynak, dosya or "surum.json"), "rb") as f:
        return f.read()


def kontrol_et(kaynak):
    """surum.json icerigi (dict)"""
    return json.loads(_oku(kaynak).decode("utf-8-sig"))


def yuklu_surum(program_klasor, varsayilan):
    try:
        with open(os.path.join(program_klasor, "yuklu_surum.txt"), encoding="utf-8") as f:
            s = f.read().strip()
            return s if not daha_yeni(varsayilan, s) else varsayilan
    except OSError:
        return varsayilan


def indir_ve_kur(kaynak, bilgi, program_klasor):
    """Yeni masaustu surumunu indirip program klasorune kurar. Eski dosyalar _yedek/<surum> altina alinir."""
    if kaynak.lower().startswith(("http://", "https://")):
        url = bilgi.get("masaustu_url")
        if not url:
            raise ValueError("surum.json'da masaüstü paketi bağlantısı yok")
        veri = _oku(kaynak, drive_dogrudan(url), zaman_asimi=120)
    else:
        veri = _oku(kaynak, bilgi.get("masaustu_dosya") or "masaustu.zip")
    z = zipfile.ZipFile(io.BytesIO(veri))
    adlar = z.namelist()
    if "GemiSeferTakibi.pyw" not in adlar:
        raise ValueError("Paket bozuk (GemiSeferTakibi.pyw yok)")
    gecici = tempfile.mkdtemp(prefix="gst_guncelleme_")
    try:
        z.extractall(gecici)
        # derleme kontrolu: bozuk dosya kurulmasin
        import py_compile
        for ad in adlar:
            if ad.endswith((".py", ".pyw")):
                py_compile.compile(os.path.join(gecici, ad), doraise=True,
                                   cfile=os.path.join(gecici, "__kontrol__.pyc"))
        surum = str(bilgi.get("masaustu_surum") or "")
        yedek = os.path.join(program_klasor, "_yedek", re.sub(r"[^\w.]", "_", yuklu_surum(program_klasor, "0")))
        os.makedirs(yedek, exist_ok=True)
        for ad in adlar:
            if ad.endswith("/") or ad.split("/")[0] in HARIC:
                continue
            hedef = os.path.join(program_klasor, ad)
            if os.path.exists(hedef):
                y = os.path.join(yedek, ad)
                os.makedirs(os.path.dirname(y), exist_ok=True)
                shutil.copy2(hedef, y)
            os.makedirs(os.path.dirname(hedef), exist_ok=True)
            shutil.copy2(os.path.join(gecici, ad), hedef)
        with open(os.path.join(program_klasor, "yuklu_surum.txt"), "w", encoding="utf-8") as f:
            f.write(surum)
        return surum
    finally:
        shutil.rmtree(gecici, ignore_errors=True)


# ====================================================================== telefon kurulum kodu
def telefon_kodu(surum_json_baglantisi, firma="", takip=None):
    import base64
    veri = {"u": drive_dogrudan(surum_json_baglantisi), "f": firma, "t": takip or []}
    return "GST1:" + base64.b64encode(json.dumps(veri, ensure_ascii=False).encode("utf-8")).decode("ascii")
